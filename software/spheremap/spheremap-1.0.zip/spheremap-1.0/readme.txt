spheremap version 1.0
=====================


INTRODUCTION
============

"spheremap" is implemented to demonstrate the spherical mapping schemes, 
including cubemap, HEALPix and isocube. The demo uses two texture filtering 
modes, nearest/bilinear.

The original HEALPix spherical mapping is presented in the paper,

  Krzysztof M. Gorski, Eric Hivon and Benjamin D. Wandelt,
  "Analysis Issues for Large CMB Data Sets," in Proceedings of 
  the MPA/ESO Cosmology Conference, Evolution of Large-Scale 
  Structure, eds. A.J. Banday, R.S. Sheth and L. Da Costa, 
  PrintPartners Ipskamp, NL, pp. 37-42, 1998 (also astro-ph/9812350).

Our implementation of HEALPIx mapping is found in:

  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
  "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
  Shader X4: Advanced Rendering Techniques, 
  Charles River Media, 2006, pp. 221-233.

The implementation of isocube mapping is based on our paper,

  Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung,
  "Isocube: Exploiting the Cubemap Hardware",
  IEEE Transaction on Visualization and Computer Graphics, to appear.


COMPILATION
===========

The project is implemented on Microsoft Windows platform, with OpenGL 
and nVidia's Cg libraries. Two project files for MSVC 6.0 and .NET 2003, 
respectively, are enclosed for compilation. We assume the machine is
equipped with nVidia GeforceFX series GPU. Our program has been tested
on nVidia's GeForceFX 6800. 


DESCRIPTION OF FOLDERS
======================

Project spheremap 1.0 consists of the following folder structure.

- bin/      demo binary executes
- data/
  - cmmap/  cubical environment maps
  - hpmap/  HEALPix environment maps
  - icmap/  isocube environment maps
- lib/
  - cgsdk/  nVidia Cg library
  - glew/   GLEW library
  - glut/   GLUT library
- src/      project source files


REQUIRED LIBRARIES
==================

- OpenGL
- GLUT
- GLEW
- CG


USER MANUAL
===========

For the user manual, simply run the program and right-click the mouse 
to select between different options. In addition, more help information
can be obtained by pressing "h".


COPYRIGHT
=========

Please carefully read the license agreement in LICENSE.txt before using the
software.


CONTACT INFORMATION
===================

For more information, query, or comments, 
send email to: ttwong@acm.org
