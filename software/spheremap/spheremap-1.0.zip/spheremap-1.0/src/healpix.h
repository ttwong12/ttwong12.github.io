/*
 * healpix.h
 *
 * Function declarations for healpix.cpp 
 * For implementation reference, please refer to:
 *
 * -  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
 *    "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
 *    Shader X4: Advanced Rendering Techniques, 
 *    Charles River Media, 2006, pp. 221-233.
 *
 * Copyright (c) 2007  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung
 *
 *
 * References:  
 * -  Liang Wan and Tien-Tsin Wong, "Sphere Maps with the Near-Equal
 *    Solid-Angle Property," Game Developers Conference (GDC) 2007, 
 *    San Francisco, USA, March 2007.
 *
 * -  Liang Wan, Tien-Tsin Wong and Chi-Sing Leung, 
 *    "Isocube: Exploiting the Cubemap Hardware", 
 *    IEEE Transactions on Visualization and Computer Graphics, to appear.
 *
 * -  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
 *    "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
 *    Shader X4: Advanced Rendering Techniques, 
 *    Charles River Media, 2006, pp. 221-233.
 *
 *
 * License agreement:
 *    While using this software, you are agreed with all agreements 
 *    listed in LICENSE.txt.
 */

#ifndef _MYHEALPIX_H
#define _MYHEALPIX_H

#include "GL/glew.h"
#include "spheremap.h"

// Read in the HELAPix layout
GLuint createFaceTex();

void SetTexParameter(GLenum target, GLuint* tex);

// Create single HEALPix environment map
GLuint createSingleEnvmap(int nside, AliaseMode aliaseMode);

#endif