/*
 *
 * ppm.cpp
 * 
 * It implements functions to read/write PPM-format images.
 *
 * Copyright (c) 2007  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung
 *
 *
 * References:  
 * -  Liang Wan and Tien-Tsin Wong, "Sphere Maps with the Near-Equal
 *    Solid-Angle Property," Game Developers Conference (GDC) 2007, 
 *    San Francisco, USA, March 2007.
 *
 * -  Liang Wan, Tien-Tsin Wong and Chi-Sing Leung, 
 *    "Isocube: Exploiting the Cubemap Hardware", 
 *    IEEE Transactions on Visualization and Computer Graphics, to appear.
 *
 * -  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
 *    "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
 *    Shader X4: Advanced Rendering Techniques, 
 *    Charles River Media, 2006, pp. 221-233.
 *
 *
 * License agreement:
 *    While using this software, you are agreed with all agreements 
 *    listed in LICENSE.txt.
 */

#include <stdio.h>
#include <string.h>

#include "ppm.h"

// 
// Read a PPM image. 
// Parameter option defines the orientation of the input image.
//
void read_ppm(const char *file, unsigned char* img, int option)
{
	FILE *fp = fopen(file,"rb");
  if ( fp == NULL )
  {
    printf("Environment image doesn't exist!\n");
    return;
  }
	char buff[128];
  int w, h;
  int i,j, temp;

	fgets(buff, 128, fp);
	while(buff[0] == '#') fgets(buff, 128, fp);
	if(strncmp(buff, "P6", 2))
	{ fclose(fp); return; }

	fgets(buff, 128, fp);
	while(buff[0] == '#') fgets(buff, 128, fp);
	sscanf(buff, "%d %d", &w, &h);
    
	fgets(buff, 128, fp);
	while(buff[0] == '#') fgets(buff, 128, fp);

	switch (option)
	{
	case 0:    
		fread(img, h*w*3, 1, fp);
		break;
	case 90: // rotate 90 degree clockwisely
    for ( j=0; j<w; j++ )
      for ( i=h-1; i>=0; i-- )
        fread(img+(i*w+j)*3, 3, 1, fp);
    temp=w; w=h; h=temp;
		break;
	case 180: // rotate 180 degree clockwisely
    for ( i=h-1; i>=0; i--)
			for ( j=w-1; j>=0; j--)
				fread(img+(i*w+j)*3, 3, 1, fp);    
		break;
	case 270: // rotate 270 degree clockwisely
    for ( j=w-1; j>=0; j--)
		  for ( i=0; i<h; i++)			
				fread(img+(i*w+j)*3, 3, 1, fp);    
    temp=w; w=h; h=temp;
		break;
	case -180: // turn upside down
    for ( i=h-1; i>=0; i-- )
			for ( j=0; j<w; j++ )
				fread(img+(i*w+j)*3, 3, 1, fp);    
		break;
  case -90: // trun leftside right
    for ( i=0; i<h; i++ )
			for ( j=w-1; j>=0; j-- )
				fread(img+(i*w+j)*3, 3, 1, fp);    
    break;
  default:
    break;
	}
  fclose(fp);
}

//
// Read width/height info from a PPM image
//
void get_ppm_size(const char *filename, int& w, int& h)
{
  char buff[128];
  FILE *fp = fopen(filename,"rb");
  if ( fp == NULL ) return;  

  fgets(buff, 128, fp);
  while(buff[0] == '#') fgets(buff, 128, fp);
  if(strncmp(buff, "P6", 2))
    { fclose(fp); return; }

  fgets(buff, 128, fp);
  while(buff[0] == '#') fgets(buff, 128, fp);
        
  sscanf(buff, "%d %d", &w, &h);
        
  fclose(fp);
}

// 
// Write a rgb image in the ppm format. 
// Parameter option defines the orientation of the output image.
//
void write_ppm(const char*filename, unsigned char*img, int w, int h, int option)
{
  int i,j;
  if (img == NULL) return;
	FILE *fp = fopen(filename,"wb");
  
	fprintf(fp, "P6\n");	
	switch (option)
	{
	case 0:
    fprintf(fp, "%d %d\n255\n", w, h);
		fwrite(img, h*w*3, 1, fp);
		break;
	case 90: // rotate 90 degree clockwisely
    fprintf(fp, "%d %d\n255\n", h, w);
    for ( j=0; j<w; j++ )
      for ( i=h-1; i>=0; i-- )
        fwrite(img+(i*w+j)*3, 3, 1, fp);
		break;
	case 180: // rotate 180 degree clockwisely
    fprintf(fp, "%d %d\n255\n", w, h);
		for ( i=h-1; i>=0; i--)
			for ( j=w-1; j>=0; j--)
				fwrite(img+(i*w+j)*3, 3, 1, fp);    
		break;
	case 270: // rotate 270 degree clockwisely
    fprintf(fp, "%d %d\n255\n", h, w);
    for ( j=w-1; j>=0; j--)
		  for ( i=0; i<h; i++)			
				fwrite(img+(i*w+j)*3, 3, 1, fp);    
		break;
	case -180: // turn upside down
    fprintf(fp, "%d %d\n255\n", w, h);
		for ( i=h-1; i>=0; i-- )
			for ( j=0; j<w; j++ )
				fwrite(img+(i*w+j)*3, 3, 1, fp);    
		break;
  case -90: // trun leftside right
    fprintf(fp, "%d %d\n255\n", w, h);
		for ( i=0; i<h; i++ )
			for ( j=w-1; j>=0; j-- )
				fwrite(img+(i*w+j)*3, 3, 1, fp);    
    break;
  default:
    break;
	}
	fclose(fp);
}