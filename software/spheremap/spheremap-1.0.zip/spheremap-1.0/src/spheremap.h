/*
 *
 * spheremap.h
 *    It defined global data structures and image paths.
 *
 * Copyright (c) 2004-2007  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung
 *
 *
 * Reference:
 *    Liang Wan, and Tien-Tsin Wong, Sphere maps with the near-equal
 * solid-angle property, Game Developers Conference (GDC) 2007
 *
 *
 * License agreement:
 *    Please read LICENSE.txt carefully before using this software. 
 * All rights reserved.
 *
 *
 * Credit:
 *    This C++ class uses GLEW for OpenGL Extensions.
 */


#ifndef _SPHEREMAP_H
#define _SPHEREMAP_H

enum ObjectMode {M_TEAPOT, M_TORUS, M_SPHERE};
enum AliaseMode {M_NEAREST, M_BILINEAR};
enum MapMode {M_CUBEMAP, M_HEALPIX, M_ISOCUBE};
enum {M_OBJECT, M_CAMERA}; 

// To be called in menus.cpp
void keyboard(unsigned char c, int x, int y);

#define CMENV "../data/cmmap/"
#define HPENV "../data/hpmap/"
#define ICENV "../data/icmap/"

#endif