/*
 * isocube.cpp
 *
 * Implementation of isocube mapping, functions to load isocube maps 
 * and handling edges to the maps. For detail implementation, please 
 * refer to the following paper:
 *
 * -  Liang Wan, Tien-Tsin Wong and Chi-Sing Leung, 
 *    "Isocube: Exploiting the Cubemap Hardware", 
 *    IEEE Transactions on Visualization and Computer Graphics, to appear.
 *
 *
 * Copyright (c) 2007  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung
 *
 *
 * References:  
 * -  Liang Wan and Tien-Tsin Wong, "Sphere Maps with the Near-Equal
 *    Solid-Angle Property," Game Developers Conference (GDC) 2007, 
 *    San Francisco, USA, March 2007.
 *
 * -  Liang Wan, Tien-Tsin Wong and Chi-Sing Leung, 
 *    "Isocube: Exploiting the Cubemap Hardware", 
 *    IEEE Transactions on Visualization and Computer Graphics, to appear.
 *
 * -  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
 *    "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
 *    Shader X4: Advanced Rendering Techniques, 
 *    Charles River Media, 2006, pp. 221-233.
 *
 *
 * License agreement:
 *    While using this software, you are agreed with all agreements 
 *    listed in LICENSE.txt.
 */

#include <stdio.h>
#include <math.h>
#include <string.h>

#include "isocube.h"
#include "spheremap.h"
#include "ppm.h"

// Global variables
extern AliaseMode g_aliase;  // Aliase mode
extern char **filenames;     // File list of environment maps
extern int g_envindex;       // Current environment map index

//
// Creat lookup table of sign symbols for Isocube
//
GLuint createSignTex()
{
  GLuint texid;
  GLenum target = GL_TEXTURE_RECTANGLE_NV;

  glGenTextures(1, &texid);
  glBindTexture(target, texid);
  
  glTexParameterf(target, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameterf(target, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameterf(target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameterf(target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);  

  float signs[] = {   
     1,  0,  0,  2,  // ntt = 0
     2, -2,  1,  0,  //       1
    -1,  0,  4, -2,  //       2
    -6,  2, -1,  0   //       3
  };

  glTexImage2D(target, 0, GL_FLOAT_RGBA32_NV, 4, 1, 0, GL_RGBA, GL_FLOAT, signs);  

  return texid;
}

//
// Map [0,255] to [0,1]
// 
void setrgba2(float *res, unsigned char *texture)
{
  *res = *texture / 255.f;
  *(res+1) = *(texture+1) / 255.f;
  *(res+2) = *(texture+2) / 255.f;
  *(res+3) = 1.f;
}


//
// Create cubemap/isocube texture 
//
GLuint createCubemap(float nside, MapMode mapMode, AliaseMode aliaseMode)
{
  // Get the image widht/height
  int w, h; 
  w = (int)nside;
  char filename[256], buff[1024];
  if ( mapMode == M_ISOCUBE )
    sprintf(filename,"%s%s/%s%s",ICENV, filenames[g_envindex], filenames[g_envindex],".%s.ppm");  
  else 
    sprintf(filename,"%s%s/%s%s",CMENV, filenames[g_envindex], filenames[g_envindex],".%s.ppm");  

  sprintf(buff, filename, "xp");
  get_ppm_size(buff, w, h);
  if (w!=nside)
  {
    printf("Wrong size of cube-map images!\n");
    return 0;
  }
  
  // Set texturing parameters for cubical environment mapping
  GLenum target = GL_TEXTURE_CUBE_MAP_ARB;
  GLuint texid;
  glGenTextures(1, &texid);
  glBindTexture(target, texid);
  
  if (aliaseMode == M_NEAREST)
    glTexParameterf(target, GL_TEXTURE_MIN_FILTER, GL_NEAREST); 
  else if (aliaseMode == M_BILINEAR)
    glTexParameterf(target, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  else
    glTexParameterf(target, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); 
  if (aliaseMode == M_NEAREST)
    glTexParameterf(target, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  else
    glTexParameterf(target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  // Load each cube face into the texture object
  unsigned char *img = new unsigned char [w*h*3];
  read_ppm(buff, img, -90); //xn, 
  glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, img);
    
  sprintf(buff, filename, "xn");
  read_ppm(buff, img, -90); //xp, 
  glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_X_ARB, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, img);
      
  sprintf(buff, filename, "yp");
  read_ppm(buff, img, -90); // yp, 
  glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Y_ARB, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, img);
    
  sprintf(buff, filename, "yn");
  read_ppm(buff, img, -90); // yn, 
  glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y_ARB, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, img);
      
  sprintf(buff, filename, "zp");
  read_ppm(buff, img, -90); // zp, 
  glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Z_ARB, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, img);
    
  sprintf(buff, filename, "zn");
  read_ppm(buff, img, -90); // zn, 
  glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z_ARB, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, img);
    
  glTexParameteri(target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); 
  glTexParameteri(target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(target, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
  glEnable(target);
  
  delete [] img;
  return texid;
}

