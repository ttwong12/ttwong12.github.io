/*
 * menus.cpp 
 *
 * This source file implements menu control.
 *
 * Copyright (c) 2007  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung
 *
 *
 * References:  
 * -  Liang Wan and Tien-Tsin Wong, "Sphere Maps with the Near-Equal
 *    Solid-Angle Property," Game Developers Conference (GDC) 2007, 
 *    San Francisco, USA, March 2007.
 *
 * -  Liang Wan, Tien-Tsin Wong and Chi-Sing Leung, 
 *    "Isocube: Exploiting the Cubemap Hardware", 
 *    IEEE Transactions on Visualization and Computer Graphics, to appear.
 *
 * -  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
 *    "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
 *    Shader X4: Advanced Rendering Techniques, 
 *    Charles River Media, 2006, pp. 221-233.
 *
 *
 * License agreement:
 *    While using this software, you are agreed with all agreements 
 *    listed in LICENSE.txt.
 */

#include <stdio.h>
#include "glut.h"

#include "spheremap.h"
#include "menus.h"

// Global variables
extern enum ObjectMode g_object;
extern enum MapMode g_map;
extern bool g_mapupdate;
extern enum AliaseMode g_aliase;
extern bool g_aliaseupdate;
extern bool g_config;

//
// Switch between different objects 
//
void ObjMenu(int entry)
{
  switch(entry)
  {
  case M_TEAPOT:
      g_object = M_TEAPOT;
    break;
  case M_TORUS:
      g_object = M_TORUS;
    break;
  case M_SPHERE:
      g_object = M_SPHERE;
    break;
  default:
    break;
  }
  glutPostRedisplay();
}

//
// Switch between two filtering modes:
//   1. NEAREST
//   2. BILINEAR
//
void AliaseMenu(int entry)
{
  g_aliaseupdate = true;
  g_config = true;
  switch(entry)
  {
  case M_NEAREST:
    g_aliase = M_NEAREST;
    break;
  case M_BILINEAR:
    g_aliase = M_BILINEAR;
    break;
  default:
    g_aliaseupdate = false;
    break;
  }
  char str[1024];
  settitle(g_map, entry, str);
  glutSetWindowTitle(str);
  
  glutPostRedisplay();
}

//
// Switch between "HEALPix", "Cube", and "Isocube" maps
//
void MapMenu(int entry)
{
  g_mapupdate = true;
  g_config = true;
  switch(entry)
  {
  case M_HEALPIX:
    g_map = M_HEALPIX;
    break;
  case M_CUBEMAP:
    g_map = M_CUBEMAP;
    break;
  case M_ISOCUBE:
    g_map = M_ISOCUBE;
    break;
  default:
    g_mapupdate = false;
    break;
  }
  char str[1024];
  settitle(entry, g_aliase, str);
  glutSetWindowTitle(str);
  
  glutPostRedisplay();
}


//
// Trigger object or camera rotation control
//
void MainMenu(int entry)
{
  switch(entry)
  {
  case M_OBJECT:
    keyboard('o', 0, 0);
    break;
  case M_CAMERA:
    keyboard('a', 0, 0);
    break;
  default:
    break;
  }
  glutPostRedisplay();
}
  
//
// Create the Menu
//
void MenuCreate()
{
  int objmenu, aliasmenu, mapmenu;
  objmenu = glutCreateMenu(ObjMenu);
    glutAddMenuEntry("Teapot", M_TEAPOT);
    glutAddMenuEntry("Torus", M_TORUS);
    glutAddMenuEntry("Sphere", M_SPHERE); 

  mapmenu = glutCreateMenu(MapMenu);    
    glutAddMenuEntry("Cubemap", M_CUBEMAP);
    glutAddMenuEntry("HEALPix", M_HEALPIX);  
    glutAddMenuEntry("Isocube", M_ISOCUBE);

  aliasmenu = glutCreateMenu(AliaseMenu);
    glutAddMenuEntry("Nearest", M_NEAREST);
    glutAddMenuEntry("Bilinear", M_BILINEAR);    
    
  glutCreateMenu(MainMenu);
    glutAddSubMenu("Object", objmenu);
    glutAddSubMenu("Map", mapmenu);
    glutAddSubMenu("Interpolation", aliasmenu);
    
    glutAddMenuEntry("Rotate camera", M_CAMERA);
    glutAddMenuEntry("Rotate object", M_OBJECT);
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

//
// Print out the rendering configuration
//
void print_config(int map, int aliase, int nside)
{
  switch(map)
  {
  case M_HEALPIX:
    switch (aliase)
    {
    case M_NEAREST:
      printf("HEALPix, nearest, Pixel count = %d", int(nside/1.414214)*int(nside/1.414214)*12);
      break;
    case M_BILINEAR:
      printf("HEALPix, bilinear, Pixel count = %d", int(nside/1.414214)*int(nside/1.414214)*12);
      break;
    default:
      break;
    }
    break;  
  case M_ISOCUBE:
    switch (aliase)
    {
    case M_NEAREST:
      printf("Isocube, nearest, Pixel count = %d", nside*nside*6);
      break;
    case M_BILINEAR:
      printf("Isocube, bilinear, Pixel count = %d", nside*nside*6);
      break;
    default:
      break;
    }
    break;
  case M_CUBEMAP:
    switch (aliase)
    {
    case M_NEAREST:
      printf("Cubemap, nearest, Pixel count = %d", nside*nside*6);
      break;
    case M_BILINEAR:
      printf("Cubemap, bilinear, Pixel count = %d", nside*nside*6);
      break;
    default:
      break;
    }
    break;  
  default:    
    break;
  }  
}


//
// Set the main window title
//
void settitle(int map, int aliase, char str[])
{
  switch(map)
  {
  case M_HEALPIX:
    switch (aliase)
    {
    case M_NEAREST:
      sprintf(str, "HEALPix Envmapping -- Nearest");
      break;
    case M_BILINEAR:
      sprintf(str, "HEALPix Envmapping -- Bilinear");
      break;
    default:
      break;
    }
    break;  
  case M_ISOCUBE:
    switch (aliase)
    {
    case M_NEAREST:
      sprintf(str, "Isocube Envmapping -- Nearest");
      break;
    case M_BILINEAR:
      sprintf(str, "Isocube Envmapping -- Bilinear");
      break;
    default:
      break;
    }
    break;
  case M_CUBEMAP:
    switch (aliase)
    {
    case M_NEAREST:
      sprintf(str, "Cubemap Envmapping -- Nearest");
      break;
    case M_BILINEAR:
      sprintf(str, "Cubemap Envmapping -- Bilinear");
      break;
    default:
      break;
    }
    break;  
  default:
    break;
  }
}