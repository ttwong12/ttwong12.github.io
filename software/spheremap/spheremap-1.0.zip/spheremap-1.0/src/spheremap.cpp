/*
 * spheremap.cpp
 *
 * Main body of the demo program. 
 *
 * This software is implemented to demonstrate the usability of 
 * spherical maps with the near-equal solid-angle property. The maps 
 * have been presented in GDC 2007. Environment mapping is used as
 * the application.
 *
 * The current version of the software contains 3 maps:
 * 1) HEALPix map
 * 2) isocube map
 * 3) cubemap (standard hardware implementation) 
 *
 * Copyright (c) 2007  The Chinese University of Hong Kong
 *
 *
 * Developed by: 
 *    Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung
 *
 *
 * References:  
 * -  Liang Wan and Tien-Tsin Wong, "Sphere Maps with the Near-Equal
 *    Solid-Angle Property," Game Developers Conference (GDC) 2007, 
 *    San Francisco, USA, March 2007.
 *
 * -  Liang Wan, Tien-Tsin Wong and Chi-Sing Leung, 
 *    "Isocube: Exploiting the Cubemap Hardware", 
 *    IEEE Transactions on Visualization and Computer Graphics, to appear.
 *
 * -  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
 *    "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
 *    Shader X4: Advanced Rendering Techniques, 
 *    Charles River Media, 2006, pp. 221-233.
 *
 *
 * License agreement:
 *    While using this software, you are agreed with all agreements 
 *    listed in LICENSE.txt.
 *
 * Credit:
 *    This C++ class uses GLEW for OpenGL Extensions.
 */


#if defined(WIN32)
#include <windows.h>
#endif

#include <stdio.h>
#include <math.h>
#include "GL/glew.h"
#include "GL/wglew.h"
#include "Cg/cg.h"
#include "Cg/cgGL.h"
#include "ppm.h"
#include "glh/glh_glut.h"
using namespace glh;

#include "spheremap.h"
#include "menus.h"
#include "healpix.h"
#include "isocube.h"

//********************* Mode paramters ********************************* 
enum MapMode  g_map = M_HEALPIX;
bool g_mapupdate = false;
enum ObjectMode g_object = M_TEAPOT;
enum AliaseMode g_aliase = M_BILINEAR;
bool g_aliaseupdate = false;

//************** File list of environment maps *************************** 
char **filenames;
int g_envindex=0;
int m_envCount;
bool g_envupdate = false;

//************** Camera, object rotation parameters ***************************
glut_simple_mouse_interactor camera, object, objrot;
glut_perspective_reshaper reshaper;
glut_callbacks cb;
float m_fov = 60.f;//80.f; // Initial FOV angle

//*********************** Cg Parameters **************************************
CGcontext shaderContext;
// Vertex program variables
CGprofile vertexProfile;
CGprogram share_vp;
CGparameter modelViewProjParam, modelParam;

//*********************** HEALPIX / ISOCUBE / CUBEMAP ****************************
// Fragment program variables
CGprofile fragmentProfile;
CGprogram reflect_fp;     // compute HEALPix texture coordinates for current scence
CGprogram env_fp;         // display environment background
CGparameter nside_param;
CGparameter eyePos_param;

GLuint face2tilelookup;   // index array to locate a HEALPix base face in the HEALPix map
GLuint *heal_tex;         // texture pointer containing environment map
int miplevels = 1;        // the actual depth of mipmap levels used
int m_nside;              // the base face size of HEALPix map
GLuint sign_tex;          // sign symbol for Isocube spherical map

//*********************** Rendering parameters ***********************************
bool g_config = true;
int g_W = 640, g_H = 640;
int downY;
bool middleButton;

void init_opengl();
void display();
void reshape(int w, int h);
void mouse(int button, int state, int x, int y);
void motion(int x, int y);
void special(int key, int x, int y);
void printconfig();
void printoutmsg();

int main(int argc, char **argv)
{
  glutInit( &argc, argv );
  glutInitDisplayMode( GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB );
  glutInitWindowSize( g_W, g_H );
  glutInitWindowPosition( 128, 40 );
  char str[1024];
  settitle(g_map, g_aliase, str);
  glutCreateWindow( str );
  
  // Initialize glew library.
  GLenum err = glewInit();
  if (GLEW_OK != err)
  {
    fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
    exit(-1);
  }

  // Turn off vertical synchronization between the display and the program.
  PFNWGLSWAPINTERVALEXTPROC pFunc = NULL;
  if ((pFunc = (PFNWGLSWAPINTERVALEXTPROC) wglGetProcAddress("wglSwapIntervalEXT")) != NULL)
    pFunc(0);
  
  // Read in the list of environment maps.
  FILE *fp = fopen("envlist.txt", "r");
  if ( fp == NULL )
  {
    printf("The list of environment maps doesn't exist!\n");
    return 1;
  }
  fscanf(fp, "%d\n", &m_nside);
  fscanf(fp, "%d\n", &m_envCount);
  filenames = new char* [m_envCount];
  for ( int i=0; i<m_envCount; i++)
  {
    filenames[i] = new char [1024];
    fscanf(fp, "%s\n", filenames[i]);
  }
  fclose(fp);

  // Initialize rendering parameters.
  init_opengl();

  // Set perspective reshaper, camera and object interactor.
  glut_helpers_initialize();
  cb.mouse_function = mouse;
  cb.motion_function = motion;

  reshaper.fovy = m_fov;
  reshaper.zFar = 50;
  reshaper.zNear = 1.0;
  reshaper.aspect = float(g_W)/float(g_H);  

  camera.dolly.dolly[2] = -5.0;
  camera.configure_buttons(1);
  camera.set_camera_mode(true);

  objrot.trackball.r = rotationf(vec3f(1,0,0), -1.570796);
  objrot.configure_buttons(1);
  
  camera.disable();
  object.disable();
  objrot.enable();

  glut_add_interactor(&cb);
  glut_add_interactor(&camera);
  glut_add_interactor(&objrot);
  glut_add_interactor(&reshaper);
  //-- end of interactor setting

  glutKeyboardFunc(keyboard);  
  glutSpecialFunc(special);  
  glutMouseFunc(mouse);
  glutDisplayFunc(display);
  MenuCreate();
  printoutmsg();

  glutMainLoop();
  return 0;
}

//
// Destroy CG program.
//
void cleanExit(int exitval)
{
  if (share_vp) cgDestroyProgram(share_vp); 
  if (reflect_fp) cgDestroyProgram(reflect_fp);
  if (env_fp) cgDestroyProgram(env_fp);
  if (shaderContext) cgDestroyContext(shaderContext);  
  exit(exitval);
}


//
// Report CG compiling errors.
//
void cgErrorCallback(void)
{
  CGerror LastError = cgGetError();
  
  if(LastError)
  {
    const char *Listing = cgGetLastListing(shaderContext);
    printf("\n---------------------------------------------------\n");
    printf("%s\n\n", cgGetErrorString(LastError));
    printf("%s\n", Listing);
    printf("---------------------------------------------------\n");
    printf("Cg error, exiting...\n");
    cleanExit(0);
  }
}


//
// Load the vertex shader.
//
void LoadVertexShader()
{  
  share_vp = cgCreateProgramFromFile(shaderContext, 
    CG_SOURCE, "shader/vertex.cg", vertexProfile, "main", NULL);     
  cgGLLoadProgram(share_vp);
  
  modelViewProjParam = cgGetNamedParameter(share_vp, "ModelViewProj");    
  modelParam = cgGetNamedParameter(share_vp, "model");
}


//
// Load the reflection shader
//
CGprogram LoadRefFrag()
{
  char cgfile[256];
  if (g_map == M_ISOCUBE || g_map == M_CUBEMAP)
    sprintf(cgfile, "shader/isocube_env_fp.cg");
  else
    sprintf(cgfile, "shader/healpix_env_fp.cg");

  CGprogram frag = cgCreateProgramFromFile(shaderContext, 
    CG_SOURCE, cgfile, fragmentProfile, "main", NULL); 
  cgGLLoadProgram(frag);

  if (g_map == M_HEALPIX)
  {
    nside_param = cgGetNamedParameter(frag, "ns");
    cgGLSetParameter1f(nside_param, int(m_nside/1.414214));   
  }
  return frag;
}

//
// Load the reflection shader
//
void LoadReflectShader()
{
  FILE *fp = fopen("shader/global.cg", "w");
  fprintf(fp, "#define _REFLECT\n");
  if (g_map == M_ISOCUBE )
    fprintf(fp, "#define _ISOCUBE\n");
  fclose(fp);
  if (reflect_fp) cgDestroyProgram(reflect_fp);    
  reflect_fp = LoadRefFrag();
  eyePos_param = cgGetNamedParameter(reflect_fp, "eyepos"); 
}


//
// Load the background shader
//
void LoadEnvShader()
{
  FILE *fp = fopen("shader/global.cg", "w");
  fprintf(fp, "#define _ENV\n");
  if (g_map == M_HEALPIX )
    fprintf(fp, "#define _NEAREST_LINEAR\n");
  if (g_map == M_ISOCUBE )
    fprintf(fp, "#define _ISOCUBE\n");    
  fclose(fp);
  if (env_fp) cgDestroyProgram(env_fp);
  env_fp = LoadRefFrag();
}

//
// Load environment map
//
void createEnvmap()
{
  if (heal_tex != NULL)
  {
    glDeleteTextures(miplevels, heal_tex);
    delete [] heal_tex;    
    heal_tex = NULL;
  }
  
  switch (g_map)
  {
  case M_HEALPIX:
    miplevels = 1;
    heal_tex = new GLuint;
    *heal_tex = createSingleEnvmap(int(m_nside/1.414214), g_aliase);      
    break;
  case M_CUBEMAP:
  case M_ISOCUBE:       
    miplevels = 1;
    heal_tex = new GLuint;
    *heal_tex = createCubemap(m_nside, g_map, g_aliase);
    break;
  default:
    break;
  }
}

//
// Initialize OpenGL
//
void init_opengl()
{
  glClearColor(0.f, 0.f, 0.f, 1.0);
  
  // Initialize CG profiles
  vertexProfile = cgGLGetLatestProfile(CG_GL_VERTEX);
  fragmentProfile = cgGLGetLatestProfile(CG_GL_FRAGMENT);
  cgSetErrorCallback(cgErrorCallback);
  shaderContext = cgCreateContext();

  // Create textures
  face2tilelookup = createFaceTex();
  sign_tex = createSignTex();
  createEnvmap();

  // Load CG programs
  LoadVertexShader();
  LoadReflectShader();
  LoadEnvShader();
}


//
// Draw basic objects
//
void draw_obj()
{
  switch (g_object) {
  case M_TEAPOT:
    glutSolidTeapot(1.0);
    break;
  case M_TORUS:
    glutSolidTorus(0.6, 2.0, 35, 35);
    break;
  case M_SPHERE:
    glutSolidSphere(2.0, 20, 20);    
    break;
  default:
    break;
  }
}

//
// The common part to draw the background
//
void backgroundbeg()
{
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
  reshaper.apply();
  glMatrixMode(GL_MODELVIEW);
  glEnable(GL_DEPTH_TEST); 
  glLoadIdentity(); 
  camera.apply_transform();
  
  // Update object rotation handle (obj_q')
  // objrot_q * cam_q * obj_q = cam_q * obj_q';  
  rotationf obj_q = object.trackball.r;
  rotationf cam_q = camera.trackball.r;
  rotationf objrot_q = objrot.trackball.r;
  obj_q = cam_q.inverse() * objrot_q * cam_q * obj_q;
  object.trackball.r = obj_q;
  objrot.trackball.r = rotationf(0, 0, 0, 1);  
  
  // Draw background    
  object.trackball.apply_transform(); 
  
  cgGLEnableProfile(vertexProfile);    
  cgGLBindProgram(share_vp);
  cgGLSetStateMatrixParameter(modelViewProjParam, CG_GL_MODELVIEW_PROJECTION_MATRIX, CG_GL_MATRIX_IDENTITY);
  cgGLSetMatrixParameterfc(modelParam, object.trackball.get_transform().get_value());  

  cgGLEnableProfile(fragmentProfile);
  cgGLBindProgram(env_fp);
}


// The comon part to draw the front object
void frontbeg()
{
  // Draw the front object
  glMatrixMode(GL_PROJECTION);
  object.pan.apply_transform();
  glMatrixMode(GL_MODELVIEW);
  glScalef(.9,.9,.9);
  if ( g_object == M_TEAPOT )
    glTranslatef(0.0, 0.0, -1.5);    
  
  cgGLBindProgram( reflect_fp );  
  cgGLSetStateMatrixParameter(modelViewProjParam, CG_GL_MODELVIEW_PROJECTION_MATRIX, CG_GL_MATRIX_IDENTITY);

  // Find the eye position in the world space
  matrix4f view = camera.get_inverse_transform();
  vec4f eye = view.get_column(3);
  //assert(eye.v[3]!=GLH_ZERO);
  cgGLSetParameter3f(eyePos_param, eye.v[0]/eye.v[3], eye.v[1]/eye.v[3],eye.v[2]/eye.v[3]);  
}


// End CG program
void shaderend()
{
  cgGLDisableProfile(fragmentProfile);    
  cgGLDisableProfile(vertexProfile);
}


//
// Display function for NEAREST/BILINEAR HEALPix environment mapping
//
void healpixDisplay()
{
  // draw background 
  backgroundbeg();  
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, face2tilelookup);    
  glActiveTextureARB(GL_TEXTURE1_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, *heal_tex);
  glutSolidSphere(15, 35, 35);    
  
  // draw object
  frontbeg();  
  draw_obj();

  // end CG program
  shaderend();
}

//
// Display function for Isocube/Cubemap environment mapping
//
void cubeDisplay()
{
  // draw background 
  backgroundbeg();
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_CUBE_MAP_ARB, *heal_tex);
  glActiveTextureARB(GL_TEXTURE1_ARB);  
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, sign_tex);
  glutSolidSphere(15, 35, 35);    

  // draw object
  frontbeg();

  draw_obj();  
  shaderend();
}

//
// Display function
//
void display()
{
  printconfig();
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

  // Update the textures when switch to another environment map
  if (g_envupdate == true)
  {
    createEnvmap();
    g_envupdate = false;
  }

  // Update when switch to another environment mapping mode
  if (g_mapupdate == true)
  {
    createEnvmap();    
    LoadReflectShader();
    LoadEnvShader();
    g_mapupdate = false;
  }

  // Update when switch to another filtering mode 
  if (g_aliaseupdate == true)
  { 
    createEnvmap();
    LoadReflectShader();
    LoadEnvShader();
    g_aliaseupdate = false;
  }  

  // Display
  switch (g_map)
  {
  case M_HEALPIX:
    healpixDisplay();
    break;
  case M_CUBEMAP:
  case M_ISOCUBE:  
    cubeDisplay();    
    break;
  }

  glutSwapBuffers();
}


void keyboard(unsigned char c, int x, int y)
{
  char str[1024];
  int temp;

  switch (c) {
  case 27:
    exit(0);
    break;

  // Turn on object rotation control
  case 'o': 
  case 'O':
    camera.disable();
    objrot.trackball.r = rotationf(vec3f(0, 1, 0), 0.0);
    objrot.enable();
    break;

  // Turn on camera rotation control
  case 'a': 
  case 'A':
    camera.enable();
    objrot.trackball.r = rotationf(vec3f(0, 1, 0), 0.0);
    objrot.disable();
    break;

  // Switch between rendering objects
  case 's': 
  case 'S':
    temp = (int)g_object;
    g_object = (enum ObjectMode)(++temp);
    if (g_object > M_SPHERE) 
      g_object = M_TEAPOT;
    glutPostRedisplay();
    break;

  // Turn to the next environment map
  case 'd':
  case 'D':
    g_envindex ++;
    if ( g_envindex >= m_envCount )
      g_envindex = 0;
    g_envupdate = true;    
    glutPostRedisplay();
    break;  

  // Turn to the previous environment map
  case 'E':
  case 'e':
    g_envindex --;
    if ( g_envindex < 0 )
      g_envindex = m_envCount-1;
    g_envupdate = true;    
    glutPostRedisplay();
    break;

  // Print help information
  case 'h':
  case 'H':
    printoutmsg();
    break;

  // Switch to the next mapping mode
  case 'M':
  case 'm':
    g_map = MapMode(g_map + 1);
    if (g_map > M_ISOCUBE)
      g_map = MapMode(0);
    g_mapupdate = true;
    g_config = true;    
    settitle(g_map, g_aliase, str);
    glutSetWindowTitle(str);
    printconfig();
    glutPostRedisplay();
    break;

  // Switch to the previous mapping mode
  case 'N':
  case 'n':
    g_map = MapMode(g_map - 1);
    if (g_map < M_CUBEMAP)
      g_map = MapMode(2);
    g_mapupdate = true;
    g_config = true;
    settitle(g_map, g_aliase, str);
    glutSetWindowTitle(str);
    printconfig();
    glutPostRedisplay();
    break;
 
  default:
    break;
  }
}


void reshape(int w, int h)
{
  glViewport(0, 0, w, h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(m_fov, float(w)/float(h), 1.0, 50.0);  
  
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  g_W = w;
  g_H = h;
}


void mouse(int button, int state, int x, int y)
{
  bool paramcontrol = false;
  downY = y;
  middleButton = ((button == GLUT_MIDDLE_BUTTON) &&  (state == GLUT_DOWN));
  
  if (camera.enabled ) { 
    camera.mouse(button, state, x, y);
  }
  if ( objrot.enabled ) {
    objrot.mouse(button, state, x, y);    
  }
  glutPostRedisplay();
}


void motion(int x, int y)
{
  // Use middle mouse button to control zoom-in / zoom-out
  if ( middleButton )
  {
    m_fov += (float)(y - downY) /10.0;
    reshaper.fovy = m_fov;
    reshaper.apply();
  }
  downY = y; 
  glutPostRedisplay();
}


void special(int key, int x, int y)
{
  // Pan the object with respect to the view point
  switch( key )
  {
  case GLUT_KEY_LEFT:
      object.pan.pan[0] -= 0.1;
    break;
  case GLUT_KEY_RIGHT:
      object.pan.pan[0] += 0.1;
    break;
  case GLUT_KEY_UP:
      object.pan.pan[1] += 0.1;
    break;
  case GLUT_KEY_DOWN:
      object.pan.pan[1] -= 0.1;
    break;
  case GLUT_KEY_PAGE_DOWN:
      reshaper.fovy -= 3;
      reshaper.apply();
      break;
  case GLUT_KEY_PAGE_UP:
      reshaper.fovy += 3;
      reshaper.apply();
      break;
  default:
    break;
  }
  glutPostRedisplay();
}


//
// Print the rendering configuration 
//
void printconfig()
{
  if (g_config == true)
  {
    print_config(g_map, g_aliase, m_nside);    
    printf(", Envmap = %s\n", filenames[g_envindex]);
    g_config = false;
  }
}


//
// Print the help information
//
void printoutmsg()
{
  printf("Help for Spheremap:\n"
    "   'O' or 'o'  --- Rotate object \n"
    "   'A' or 'a'  --- Rotate camera \n"
    "   'M' or 'm'  --- Next spherical sampling method\n"
    "   'N' or 'n'  --- Previous spherical sampling method\n"    
    "   'D' or 'd'  --- Next environment\n"
    "   'E' or 'e'  --- Previous environment\n"
    "   'S' or 's'  --- Switch among objects\n"    
    "   'H' or 'h'  --- Print help information\n"
    );
}