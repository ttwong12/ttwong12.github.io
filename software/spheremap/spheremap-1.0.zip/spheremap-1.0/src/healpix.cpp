/*
 * healpix.cpp
 *
 * Implementation of HEALPix mapping, functions to load HEALPix 
 * maps, and handling edges to the maps.
 * For implementation reference, please refer to:
 *
 * -  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
 *    "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
 *    Shader X4: Advanced Rendering Techniques, 
 *    Charles River Media, 2006, pp. 221-233.
 *
 * Copyright (c) 2007  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung
 *
 *
 * References:  
 * -  Liang Wan and Tien-Tsin Wong, "Sphere Maps with the Near-Equal
 *    Solid-Angle Property," Game Developers Conference (GDC) 2007, 
 *    San Francisco, USA, March 2007.
 *
 * -  Liang Wan, Tien-Tsin Wong and Chi-Sing Leung, 
 *    "Isocube: Exploiting the Cubemap Hardware", 
 *    IEEE Transactions on Visualization and Computer Graphics, to appear.
 *
 * -  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
 *    "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
 *    Shader X4: Advanced Rendering Techniques, 
 *    Charles River Media, 2006, pp. 221-233.
 *
 *
 * License agreement:
 *    While using this software, you are agreed with all agreements 
 *    listed in LICENSE.txt.
 */

#include <stdio.h>
#include <math.h>
#include <string.h>

#include "healpix.h"
#include "spheremap.h"
#include "ppm.h"

// Global variables
extern AliaseMode g_aliase;  // Aliase mode
extern char **filenames;     // File list of environment maps
extern int g_envindex;       // Current environment map index

// The neighbor tile index for one tile in HEALPix map 
static int map[12][4] = {{3,5,4,1}, {0,6,5,2}, {1,7,6,3}, {2,4,7,0}, 
{3,8,11,0}, {0,9,8,1}, {1,10,9,2}, {2,11,10,3},
{4,9,11,5}, {5,10,8,6}, {6,11,9,7}, {7,8,10,4}};

// The actual face number of one tile in HEALPix map
static int tilenum2face[12] = {
  0, 11, 4,     5,  1, 8,
  9,  6, 2,     3, 10, 7
};

// The tile index of one base face in HEALPix map
static int face2tile[12] = {
  0, 4, 8,   9, 2, 3,
  7,11, 5,   6,10, 1
};  


//
// Create a texture object and set the texturing parameters.
// 
// By default, the filtering mode is set to be GL_NEREAST for both min and max
// cases, the warp modes set as CLAMP_TO_EDGE.
void SetTexParameter(GLenum target, GLuint* tex)
{
  glGenTextures(1, tex);
  glBindTexture(target, *tex);
  
  glTexParameterf(target, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameterf(target, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameterf(target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameterf(target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}


//
// GLuint createFaceTex()
//
// Create an index array to locate one HEALPix "face" into the HEALPix map.
// Its corresponding patch is indicated by the variable "tile".
// One array element a contains 4 components {xyzw}:
//   a.x      the row index of tile 
//   a.y      the column index of tile
//   a.z/w    the texture coordinate offsets
//
GLuint createFaceTex()
{
  GLuint texid;  
  float facenum2tile[12*4];
  int tile, pos = 0; 

  for ( int i=0; i<12; i++ )
  {
    tile = face2tile[i];
    facenum2tile[pos++] = (float)(tile%3);
    facenum2tile[pos++] = (float)(tile/3);
    facenum2tile[pos++] = (float)(tile%3)*2+1;
    facenum2tile[pos++] = (float)(tile/3)*2+1;
  }  

  SetTexParameter(GL_TEXTURE_RECTANGLE_NV, &texid);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGBA32_NV, 12, 1, 0, GL_RGBA, GL_FLOAT, facenum2tile);
  return texid;
}

//
// Map [0,255] to [0,1]
// 
void setrgba(float *res, unsigned char *texture)
{
  *res = *texture / 255.f;
  *(res+1) = *(texture+1) / 255.f;
  *(res+2) = *(texture+2) / 255.f;
  *(res+3) = 1.f;
}

//
// void addhpedge()
//
// Add boundary edges to each base face in the HEALPix map.
//
// INPUT:
//    img    the original 24-bit image with 8-bit per channel
//    nside  the length of each original base face
//    dim    = nside+2;
// 
// OUTPUT:
//    pimg  the resulting image with 32-bit per channel and padded with alpha channel
//
void addhpedge(float*pimg, unsigned char *img, int nside, int dim)
{
  int col = 3; // the HEALPix map contains 4 rows by 3 columns.
  int refface, pixindex, refindex, reftile;
  for (int tile = 0; tile < 12; tile ++ )
  {
    int face = tilenum2face[tile];
    int offset = (tile/3) * (dim * dim * col) + (tile%3) * dim;
    // fill the four boundaries
    for ( int j=1; j<dim-1; j++ )
    {
      // top boundary
      refface = map[face][0];
      reftile = face2tile[refface];
      pixindex = ( offset+j ) * 4;
      refindex = ( (reftile/3)*nside*nside*col + (reftile%3)*nside )*3;
      if ( face < 4 )
        refindex += ((nside-j)*nside*col + nside-1)*3; 
      else 
        refindex += ((nside-1)*nside*col + j-1)*3;
      setrgba(&pimg[pixindex], &img[refindex]);
      
      // bottom boundary
      refface = map[face][1];
      reftile = face2tile[refface];
      pixindex = (offset + (dim-1)*dim*col + j)*4;
      refindex = ( (reftile/3)*nside*nside*col + (reftile%3)*nside )*3;
      if ( face < 8 )
        refindex += (j-1)*3;
      else
        refindex += ((nside-j)*nside*col)*3; 
      setrgba(&pimg[pixindex], &img[refindex]);
    }
    
    for (int i=1; i<dim-1; i++)
    {
      // left boundary
      refface = map[face][2];
      reftile = face2tile[refface];
      pixindex = (offset + i*dim*col)*4;
      refindex = ( (reftile/3)*nside*nside*col + (reftile%3)*nside )*3;
      if ( face < 8 )
        refindex += ( (i-1)*nside*col + nside-1)*3;
      else
        refindex += ( (nside-1)*nside*col + (nside-i) )*3; 
      setrgba(&pimg[pixindex], &img[refindex]);
      
      // right boundary
      refface = map[face][3];
      reftile = face2tile[refface];
      pixindex = (offset + i*dim*col + dim-1)*4;
      refindex = ( (reftile/3)*nside*nside*col + (reftile%3)*nside )*3;
      if ( face < 4 )
        refindex += (nside-i)*3; 
      else 
        refindex += ((i-1)*nside*col)*3;
      setrgba(&pimg[pixindex], &img[refindex]);
    }

    // fill the central face    
    for (i=1; i<dim-1; i++)
      for (int j=1; j<dim-1; j++)
      {
        refindex = ( (tile/3)*nside*nside*col + (tile%3)*nside )*3;
        pixindex = (offset + i*dim*col + j)*4;
        refindex += ((i-1)*nside*col + j-1)*3;
        setrgba(&pimg[pixindex], &img[refindex]);        
      }

    // tricks to fill the corners
    memcpy(&pimg[offset*4], &pimg[(offset+dim*col+1)*4], sizeof(float)*4);
    memcpy(&pimg[(offset+dim-1)*4], &pimg[(offset+dim*col+dim-2)*4], sizeof(float)*4);
    memcpy(&pimg[(offset+(dim-1)*dim*col)*4], &pimg[(offset+(dim-2)*col+1)*4], sizeof(float)*4);
    memcpy(&pimg[(offset+(dim-1)*dim*col+dim-1)*4], &pimg[(offset+(dim-2)*dim*col+dim-2)*4], sizeof(float)*4);
  }// end tile
}


//
// Load one HEALPix map as the texture.
// This function supports NEAREST & BILINEAR filtering modes.
//
GLuint createSingleEnvmap(int nside, AliaseMode aliaseMode)
{
  GLuint texid;
  glGenTextures(1, &texid);
  GLenum target = GL_TEXTURE_RECTANGLE_NV;   
  glBindTexture(target, texid);
  if (aliaseMode == M_NEAREST)
  {
    glTexParameterf(target, GL_TEXTURE_MIN_FILTER, GL_NEAREST); 
    glTexParameterf(target, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  }
  else if (aliaseMode == M_BILINEAR)
  {
    glTexParameterf(target, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 
    glTexParameterf(target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  }
  else
  {
    printf("Aliase mode is GL_NEAREST or GL_LINEAR\n");
    return 0;
  }
  glTexParameterf(target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameterf(target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  
  // Get the image widht and height 
  int w, h;
  w = h = 0;
  char filename[256];
  sprintf(filename,"%s/%s/%s.%d.ppm",HPENV, filenames[g_envindex],filenames[g_envindex],(int)nside);
  get_ppm_size(filename, w, h);
  if ( w==0 || h==0 )
  {
    printf("The texture doesn't exist!\n");
    return 0;
  }

  // Read in the image and add boundaries for each base tile
  unsigned char *img = new unsigned char [w*h*3];
  read_ppm(filename, img, 0);
  int dim = nside + 2;
  float *pimg = new float [dim*dim*4*12];
  addhpedge(pimg, img, nside, dim);

  // Load the image to a texture object
  glTexImage2D(target, 0, GL_RGBA, dim*3, dim*4, 0, GL_RGBA, GL_FLOAT, pimg);  
  delete [] img;
  delete [] pimg;
  glEnable(target);

  return texid;
}