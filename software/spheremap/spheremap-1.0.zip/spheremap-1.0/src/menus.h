/*
 * menus.h 
 *
 * Function declarations for menus.cpp
 *
 * Copyright (c) 2007  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung
 *
 *
 * References:  
 * -  Liang Wan and Tien-Tsin Wong, "Sphere Maps with the Near-Equal
 *    Solid-Angle Property," Game Developers Conference (GDC) 2007, 
 *    San Francisco, USA, March 2007.
 *
 * -  Liang Wan, Tien-Tsin Wong and Chi-Sing Leung, 
 *    "Isocube: Exploiting the Cubemap Hardware", 
 *    IEEE Transactions on Visualization and Computer Graphics, to appear.
 *
 * -  Tien-Tsin Wong, Liang Wan, Chi-Sing Leung and Ping-Man Lam,
 *    "Real-Time Environment Mapping with Equal Solid-Angle Spherical Quad-Map",
 *    Shader X4: Advanced Rendering Techniques, 
 *    Charles River Media, 2006, pp. 221-233.
 *
 *
 * License agreement:
 *    While using this software, you are agreed with all agreements 
 *    listed in LICENSE.txt.
 */

#ifndef _MENUS_H
#define _MENUS_H

void MenuCreate();
void settitle(int map, int aliase, char str[]);
void print_config(int map, int aliase, int nside);

#endif // _MENUS_H