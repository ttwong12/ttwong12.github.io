#ifndef __INTERFACE_H
#define __INTERFACE_H

#include "vortex.h"

void asc1(volume *v, float threshold, char *outfile);
void asc2(volume *v, float threshold, char *outfile);
void asc4(volume *v, float threshold, char *outfile);
void asc8(volume *v, float threshold, char *outfile);

#endif

