//
// util.h
//
//
// LICENCE AGREEMENT:
// 
// This agreement also includes all clauses in LICENCE.txt
//
// Copyright (c) 2005, The Chinese University of Hong Kong
//
// If you publish work based on this software (binary or source code) 
// or its derivative, you agree to cite the following references in your
// publication:
//
//   Ka-Ling Fok, Tien-Tsin Wong and Man-Leung Wong, Evolutionary Computing on 
//   Consumer-Level Graphics Hardware, IEEE Intelligent Systems, to appear.
//   (http://www.cse.cuhk.edu.hk/~ttwong/download/papers/ecgpu/ecgpu.html)
// 
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted for commercial and non-commercial 
// research and academic use, provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice and
// the file LICENCE.txt, this list of conditions and the following disclaimer.
// Each individual file must retain its own copyright notice.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, 
// this list of conditions, the following disclaimer and the list of contributors 
// in the documentation and/or other materials provided with the distribution.
//
// 3. Modification of the program or portion of it is allowed provided that the 
// modified files carry prominent notices stating where and when they have been 
// changed. 
//
#ifndef _UTIL_H_
#define _UTIL_H_

void    shaderDrawQuad(int width, int height);
void    ErrExit(char *reason);
void    shader_set_tex_para(void);
double  myTime();
float   gaussian();
float   uni_rand(float range);
#endif