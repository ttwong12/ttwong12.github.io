// 
// ep.cpp
//
// Evolutionary programming (EP) module
//
// This module contains BOTH software and hardware implementation of EP.
// It is implemented for our paper: 
//
//     Ka-Ling Fok, Tien-Tsin Wong and Man-Leung Wong, ``Evolutionary Computing 
//     on Consumer-Level Graphics Hardware,'' IEEE Intelligent Systems,
//     to appear.
//
// Hardware requirement:
//   for the best performance, fragment shader profile NV_FP40 or higher is needed.
//   Hence, Geforce 6 series is needed.
//
// Algorithm of EP:
// 1. Initialize a population, a population contains POPULAION SIZE (G_nPSize) of chromosomes.
//    In this implementation, each chromosome has a size of 32, i.e. each chromosome contains 
//    32 variables.
// 2. Perform fitness evaluation, i.e. the objective function. In this implementation, 
//    the objective is to MINIMIZE the objective function.
// 3. We produce new population by performing mutation using Cauchy Mutation stated in 
//    the paper.
// 4. Then we perform tournaments on the union of mutated population (new population) and 
//    the parent population to generate the next generation,  i.e. totally size of 2 * G_nPSize
//    chromosome. Each tournament round picks up a random opponent, the chromosome wins 
//    if its objective value is smaller than that of opponent. The total rounds of of tournament 
//    is controlled by variable TOUR_SIZE.
// 5. The G_nPsize chromosomes having the winning value higher than the median winning value is selected as the new generation
// 6. Go to Step 2 until maximum number of generation (G_nTmax) is reached
//
// Detail EP algorithm is refered to the paper: 
// 
//    Xin Yao and Yong Liu, ``Fast Evolutionary Programming,'' Advances in evolutionary 
//    computing: theory and applications archive, 2003, pp. 45-94.
//  
  
//
// LICENCE AGREEMENT:
// 
// This agreement also includes all clauses in LICENCE.txt
//
// Copyright (c) 2005, The Chinese University of Hong Kong
//
// If you publish work based on this software (binary or source code) 
// or its derivative, you agree to cite the following references in your
// publication:
//
//   Ka-Ling Fok, Tien-Tsin Wong and Man-Leung Wong, Evolutionary Computing on 
//   Consumer-Level Graphics Hardware, IEEE Intelligent Systems, to appear.
//   (http://www.cse.cuhk.edu.hk/~ttwong/download/papers/ecgpu/ecgpu.html)
// 
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted for commercial and non-commercial 
// research and academic use, provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice and
// the file LICENCE.txt, this list of conditions and the following disclaimer.
// Each individual file must retain its own copyright notice.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, 
// this list of conditions, the following disclaimer and the list of contributors 
// in the documentation and/or other materials provided with the distribution.
//
// 3. Modification of the program or portion of it is allowed provided that the 
// modified files carry prominent notices stating where and when they have been 
// changed. 
//


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <gl/glew.h>
#include <gl/glut.h>
#include <gl/gl.h>
#include <cg/cg.h>
#include <cg/cgGL.h>
#include "normsinv.h"
#include "RenderTexture.h"
#include "util.h"


#define   F1       // define which function to optimize
#define	  M_PI      3.14159265358979323846    // PI definition
#define	  TOUR_SIZE 10                        // tournament size of 

#ifdef    F1
  #define   RANGE        100.0f		
  #define   SHADER_FILE  "./shader/f1.cg"
#elif defined(F2)
  #define   RANGE        100.0f		
  #define   SHADER_FILE  "./shader/f2.cg"
#elif defined(F3)
  #define   RANGE         30.0f		
  #define   SHADER_FILE  "./shader/f3.cg"
#elif defined(F4)
  #define   RANGE        500.0f	
  #define   SHADER_FILE  "./shader/f4.cg"
#elif defined(F5)
  #define   RANGE          5.12f
  #define   SHADER_FILE  "./shader/f5.cg"
#endif




//=====Global Variable=========================
// Global variable naming convension
// G_   : meaning it as a globale variable
// n    : integer
// f    : float
// p    : pointer
// rt   : render to texture
// tex  : OpenGL texture variable
// so variable G_fpPx means Px is a variable that is Global, and float type pointer

int       G_nPSize;    //Total size of the Population, it should be divied into P_SIZE_X * P_SIZE_Y
int       P_SIZE_X;    //For harware implementation, the width of the texture should be set, and P_SIZE_X is the width
int       P_SIZE_Y;    //The height of the texture containing the population
int       G_nTmax;     //maximum generation for the EC profess
int       G_nGLmain;    //main open GL handeler
int       GPU_RANDOM;   // a GPU_RANDOM switch
float     *G_fpPx;      //float pointer of Population x part, it is used to contain the acutal value of population of each generation
                        //since the organization of chromosme is specially designed for GPU, so, to get or retrieve the 
                        //chromosome, special function (get_chromosome,set_chromosome) is needed.
                        //for actual organization of the chromosme, please refer : ?

float     *G_fpPn;      //float pointer of Population n part, except the x part, each chromosome is followed by an n (eta) for its
                        //mutation process, it is based on the cauchy mutation, and n (eta) is actually the variable controlling the
                        //mutation rate
float     *G_fpFitP;    //float pointer of fitness value, the fitness value associated with each variable after fitness calculation
float     *G_fpFitNewp; //float pointer of new generation's fitness, it is the fitness value asssociated with the mutated parent (new population)
float     *G_fpPnewx;   //New generation's x part, it contains the acutal variable values of the newly mutated population
float     *G_fpPnewn;   //new generation's n part, the eta associated with the choromosomes
int       *G_npWin1;    //winning array for the original population, this is used for couting how many winning time the chromosome is
int       *G_npWin2;    //winning array for the newly mutated population
float     *G_fpOrderedList; //indirect map, this is the list that will pass into GPU to tell which chromosome is
                            //pick up as the new generation, this variable is generated after the tournamnet function and reording function
float     *temp;            
float     *temp32;

GLuint    G_texPx;      //the openGL texture which contains the actually value of the chromosomes, i.e. it is associated to variable G_fpPx
GLuint    G_texPn;      //the openGL texture which contains the control variable of the chromosomes, it is associated to variable G_fpPn
GLuint    G_texTemp;
GLuint    G_texTemp32;


char      outValueName[200];  //temp varaible containing the output value file name
char      outTimeName[200];   //temp varaible containing the output time file name
char      outOtherName[200];  //temp varaible containing the other statisitics' file name
FILE      *outfile;
FILE      *timefile;
FILE      *otherfile;


//======Render to Texture==============
RenderTexture   *G_rtFitP;     //render to texture controler, this is the p-buffer used as texture for containing the fitness value calulated
RenderTexture   *G_rtFitPnew;  //p-buffer used as texture for containing the fitness value calulated of newly mutated population
RenderTexture   *G_rtPnewn;    //p-buffer for the values of newly mutated chromosomes
RenderTexture   *G_rtPnewx;    //p-buffer for the control variables of newly mutated chromosomes
RenderTexture   *G_rtPn0;      //p-buffer for the value of orginal popualtion, since one pass of the rendering will use the result of previous pass, 
                               //so two p-buffer is used, and each rendering pass, the buffer will swap.
RenderTexture   *G_rtPx0;      //p-buffer for the control variable of orginal population, since one pass of the rendering will use the result of previous pass, 
                               //so two p-buffer is used, and each rendering pass, the buffer will swap.
RenderTexture   *G_rtPn1;
RenderTexture   *G_rtPx1;


RenderTexture   *G_rtRandomFull[2];
RenderTexture   *G_rtRandomFull1[2];
RenderTexture   *G_rtRandom[2];
RenderTexture   *G_rtRandom1[2];


//======CG related parameters===========
CGcontext       CG_ShaderContext;   //standard shader context needed for using fragment shader
CGprofile       CG_fragmentProfile; //fragment profile, containing which fragment profile is used

// the fitness calculation function
CGprogram       CG_f;               //this is the fitness calcuation shader
CGparameter     CG_f_texPx;         //the most important texture pass into the shader, this contains the 
                                    //actual values of chromosomes
CGparameter     CG_f_POP_SIZE_X;    //the shader need exactly to know what the size of the texture, this is the width of the texture
CGparameter     CG_f_POP_SIZE_Y;    //the height of texture (CG_f_texPx) used in the shader

// generate new part of n
CGprogram       CG_newn;            //generate new n (eta) shader
CGparameter     CG_newn_texPn;      //the shader need to receives the orginal n (eta), and this variable is to stored the oringal eta
CGparameter     CG_newn_texR;       //tex R is a texture containing random variable
CGparameter     CG_newn_texGaus;    //texGaus is also a texture containing random variable, it is uniform random variable when it pass in, and shader
                                    //will respond to transform it from uniform random to gaussian random
CGparameter     CG_newn_P_SIZE_X;   //the width of the n texture
CGparameter     CG_newn_P_SIZE_Y;   //the height of the n texutre
CGparameter     CG_newn_searchRange; //after the eta is mutated, it need to clamp into serach range, and this variable contains the range parameter

// generate new part of x
CGprogram       CG_newx;            //generate the new x shader, the new x actually the chromosome
CGparameter     CG_newx_texPx;      //the pervious generation of population texture
CGparameter     CG_newx_texPn;      //the pervious generation of eta (n) texture
CGparameter     CG_newx_texRand;    //a texture containing random variable
CGparameter     CG_newx_texRand2;   //another texture coontaining random variable
CGparameter     CG_newx_searchRange; //the search range, which controls the range of the values of the variables (chromosomes)

// reorder the PX, Pn
CGprogram       CG_reorder;           //reodering shader, after peformed tournament, the shader is respond to pick up the new generation of chromosomes
CGparameter     CG_reorder_texP1;     //the texture containing original chromosomes
CGparameter     CG_reorder_texP2;     //the texutre containing newly mutated chromosomes
CGparameter     CG_reorder_texOrderList;  //the texture containing which chromosome that should be used as the new generation
CGparameter     CG_reorder_P_SIZE_X;    //the width of the chromosome textures
CGparameter     CG_reorder_P_SIZE_Y;    //the height of the chromosome textures

// simply for display
CGprogram       CG_display;             //the dummy display, draw the chromosome to the screen
CGparameter     CG_display_texDisplay;  //the texture containing the chromosome
CGparameter     CG_display_texWidth;
CGparameter     CG_display_texHeight;
CGparameter     CG_display_lboundary;
CGparameter     CG_display_uboundary;


// random
CGprogram       CG_random;
CGparameter     CG_random_texInput;


//Error Exit routine
void errexit(char *reason)
{
  printf("%s\n",reason);
  exit(-1);
}




//
// fitness
// 
// function to calculate the objective value of the chromosome
//
// INPUT:
//   chromosome,   the specific chromosome needed to evaluate, the chromosome is retrive by calling get_chromosome function
//
// OUTPUT:
//   a float value containing the objective value calculated
//
// function to optimize
//   f1:  sum(i= 1 to 32){xi * xi};
//   f2:  sum(i=1 to 32) {sum(j=1 to i) xj}^2
//   f3:  sum(i=1 to 31){x(i+1) -xi^2 + (xi-1)^2}
//   f4:  sum(i=1 to 32){-xi*sin(sqrt{|xi|})}
//   f5:  sum(i=1 to 32){xi^2 - 10 * cos(2*pi*xi + 10)}
#ifdef F1
//==================f1============================================================
//
// f1:
//       32
//     +----
//      \     X_i * X_i
//      /       
//     +----
//      i=1
//
float fitness(float* chromosome)
{
  float result;
  int   i;
  result = 0;
  for (i=0; i < 32; i++)
    result += (float) (chromosome[i]*chromosome[i]);
  return result;
}

#elif defined(F2)

//================== f2 ===========================================================
//
// f2:
//       32   /   i           \ 2
//     +----  | +----         |
//      \     |  \      X_j   |
//      /     |  /            |
//     +----  | +----         |
//      i=1   \   j=1         /
//
float fitness(float* chromosome)
{
  float result;
  int   i;
  int   j;
  float temp_res;

  result = 0;
  for (i=0; i < 32; i++)
  {
    temp_res = 0;
    for (j=0 ; j <= i ; j++)
      temp_res += (float) chromosome[j];
    result += temp_res * temp_res;
  }
  return result;
}

#elif defined(F3)

//================== f3 ===========================================================
// 
//     31
//   +-----                 2             2
//    \     X        -    X   +    (X - 1)
//    /      (i+1)         i         i
//   +-----
//     i=1
//
float fitness(float* chromosome)
{
  float result;
  int   i;
  result = 0;
  for (i=0; i < 31; i++)
  {
    result += (float) 100 * ((chromosome[i+1] - chromosome[i] * chromosome[i]) * (chromosome[i+1] - chromosome[i] * chromosome[i])) +
              (float) (chromosome[i] - 1) * (chromosome[i] -1);
  }
  return result;
}

#elif defined(F4)

//============================== f4 =====================================================
// 
//     32
//   +-----         
//    \     X    * sin (sqrt(|x |))   
//    /      i                 i
//   +-----
//     i=1
//
float fitness(float* chromosome)
{
  float result;
  int   i;
  result = 0;
  for (i=0; i < 32; i++)
    result += -chromosome[i]*sin(sqrt(abs(chromosome[i])));
  return result;
}

#elif defined(F5)

//================== f5 ============================================================
// 
//     32
//   +-----         
//    \     X  * X  - 10 * cos (2 * PI * X + 10)   
//    /      i     i                      i
//   +-----
//     i=1
//
float fitness(float* chromosome)
{
  float result;
  int   i;
  result = 0;
  for (i=0; i < 32; i++)
    result += (float) (chromosome[i]*chromosome[i] - 10 * cos(2 * M_PI * chromosome[i]) + 10);
  return result;
}
#endif




//
// get_chromosome
//
// It retrieves all genes of a chromosome "index" originally stored in a tiled form in 
// texture. These genes are then packed into an 1D array.
// Given an index [0, Population size-1], this function returns the requested chromosome.
//
// INPUT:
//   chromosome_array: the 1D array containing all the chromosomes
//   index: index of the specific chromosome needed
//
// OUTPUT:
//  result: the chromosome needed, assumed its memory is allocated by the caller.
//          Size is 32.
//
void get_chromosome(float *chromosome_array, int index, float *result)
{
  int   i;
  int   x,y;
  x = index % P_SIZE_X;
  y = index / P_SIZE_X;
  for (i=0; i < 4; i++)
    result[i] = chromosome_array[y*16*P_SIZE_X + 4*x + i];
  for (i=4; i < 8; i++)
    result[i] = chromosome_array[y*16*P_SIZE_X + 4*x + 4*P_SIZE_X + i-4];
  for (i=8; i < 12; i++)
    result[i] = chromosome_array[y*16*P_SIZE_X + 4*x + 8*P_SIZE_X + i-8];
  for (i=12; i < 16; i++)
    result[i] = chromosome_array[y*16*P_SIZE_X + 4*x + 12*P_SIZE_X + i-12];
  for (i=16; i < 20; i++)
    result[i] = chromosome_array[(y+P_SIZE_Y)*16*P_SIZE_X + 4*x + i-16];
  for (i=20; i < 24; i++)
    result[i] = chromosome_array[(y+P_SIZE_Y)*16*P_SIZE_X + 4*x + 4*P_SIZE_X + i-20];
  for (i=24; i < 28; i++)
    result[i] = chromosome_array[(y+P_SIZE_Y)*16*P_SIZE_X + 4*x + 8*P_SIZE_X + i-24];
  for (i=28; i < 32; i++)
    result[i] = chromosome_array[(y+P_SIZE_Y)*16*P_SIZE_X + 4*x + 12*P_SIZE_X + i-28];
  //for (i=0; i < 32; i++)
  //  printf("x[%d] : %f\n",i,result[i]);
  return;
}



//
// set_chromosome
//
// Given an 1D array storing a chromosome, it copy the gene values to the tiled-format 
// texture.
//
// INPUT:
//   chromosome_array: the 1D array containing all the chromosomes
//   index:            index of the specific chromosome being set
//   chromosome:       the chromosome needed to stored in the chromosome_array
//                     size of chromosome is 32.
// OUTPUT:
//  chromosome_array:  the specific chromosome will be written to the chromosome_array, and chromosome_array is modified in this function
//
void set_chromosome(float* chromosome_array, int index, float *chromosome)
{
  int   i;
  int   x,y;
  x = index % P_SIZE_X;
  y = index / P_SIZE_X;
  for (i=0; i < 4; i++)
    chromosome_array[y*16*P_SIZE_X + 4*x + i] = chromosome[i];
  for (i=4; i < 8; i++)
    chromosome_array[y*16*P_SIZE_X + 4*x + 4*P_SIZE_X + i-4] = chromosome[i];
  for (i=8; i < 12; i++)
    chromosome_array[y*16*P_SIZE_X + 4*x + 8*P_SIZE_X + i-8] = chromosome[i];
  for (i=12; i < 16; i++)
    chromosome_array[y*16*P_SIZE_X + 4*x + 12*P_SIZE_X + i-12] = chromosome[i];
  for (i=16; i < 20; i++)
    chromosome_array[(y+P_SIZE_Y)*16*P_SIZE_X + 4*x + i-16] = chromosome[i];
  for (i=20; i < 24; i++)
    chromosome_array[(y+P_SIZE_Y)*16*P_SIZE_X + 4*x + 4*P_SIZE_X + i-20] = chromosome[i];
  for (i=24; i < 28; i++)
    chromosome_array[(y+P_SIZE_Y)*16*P_SIZE_X + 4*x + 8*P_SIZE_X + i-24] = chromosome[i];
  for (i=28; i < 32; i++)
    chromosome_array[(y+P_SIZE_Y)*16*P_SIZE_X + 4*x + 12*P_SIZE_X + i-28] = chromosome[i];
  //for (i=0; i < 32; i++)
  //  printf("x[%d] : %f\n",i,result[i]);
  return;
}



//
// new_x
//
//  Software implementation. To generate the mutated chromosome (x part) from the 
//  original chromosome and it's eta part. The mutation is based on the cauchy mutation.
//
// INPUT:
//  s_chromo_x:  source input of the chromosome
//  s_chromo_n:  source input of the chromosome's eta part
//  index:       it will serve as index to get random value from random buffer
//  arrayRand:   an array of random variable needed for the mutation
//
//  OUTPUT:
//  t_chromomo_x: the mutated chromosome
//
void new_x(float *t_chromo_x, float *s_chromo_x, float *s_chromo_n, int index, float *arrayRand)
{
  int   i;
  float C;  // a random variable
  float myRand[32];

  get_chromosome(arrayRand,index,myRand); // first get the random value from the random buffer
  for (i=0; i < 32; i++)
  {
    //C = rand()/(float)RAND_MAX; //0 - 1
    C = myRand[i];
    C = C - 0.5f;
    C = (float) tan(C *M_PI); 
    t_chromo_x[i] = s_chromo_x[i] + s_chromo_n[i] * C; // mutated by cauchy mutation
    if (t_chromo_x[i] > RANGE) // clamp into range
      t_chromo_x[i] = RANGE;
    if (t_chromo_x[i] < -RANGE)
      t_chromo_x[i] = -RANGE;
  }
}



//
// new_n
//
// Software implementation. Given the index of original eta, generate the new eta 
// according to cauchy muataion.
//
// INPUT:
//  s_chromo_n : the source (orginal) eta to be mutated, it is the chromosome fetched by get_chromosome (done by caller)
//  index      : the index stating which chromosome is being mutated 
//  arrayR     : a float array containing gaussian random variable
//  arrayGaus  : another float array containing gaussian random variable
//
// OUPUT:
//  t_chromo_n  : the mutated eta
//
// Assumption:
//  all the array are malloced and freed by the caller
//
void new_n(float * t_chromo_n, int index, float* s_chromo_n, float* arrayR, float* arrayGaus)
{
  int   i;
  float R;
  const float a = 0.125f;
  const float b = 0.2973f;
  float myGaus[32];

  R = arrayR[index];
  get_chromosome(arrayGaus,index,myGaus);  // get the random variable
  for (i=0; i < 32; i++)
  {
    t_chromo_n[i] = (float) (s_chromo_n[i] * exp(a*R + b*myGaus[i]));
    if (t_chromo_n[i] > RANGE)
      t_chromo_n[i] = RANGE;
    if (t_chromo_n[i] < -RANGE)
      t_chromo_n[i] = -RANGE;
  }
}


//
// cal_fitness
//
//  a function that calculates the whole population's objective value, it will get the chromosome
//  one by one, and then calclulate it's objective value by calling "FITNESS" function, and then it will 
//  write out the fitness value to target array
//
// INPUT:
//   chromosome_array : the source array containing the whole population of chromosomes
//
// OUTPUT:
//  target_fp : the target array the whole population's fitness value
//
// ASSUME:
//  target_fp is malloced and freed by the caller
//
void cal_fitness(float* chromosome_array, float* target_fp)
{
  int   i;
  float chromosome[32];

  for (i=0; i < G_nPSize; i++)
  {
    get_chromosome(chromosome_array,i,chromosome);
    target_fp[i] = fitness(chromosome);
  }
}




//
// min_f
//
// given an fitness value array, return the minimum with the minIndex associated to it
//
// INPUT:
//  source_fp : the array containing all the fitness value of the chromosomes
//
// OUTPUT:
//  minIndex  : the index of chromosome having the smallest fitness value
//
float min_f(float *source_fp, int *minIndex)
{
  int   i;
  float minValue;
  minValue  = source_fp[0];
  *minIndex = 0;
  for (i=1 ; i < G_nPSize ; i++)
  {
    if (source_fp[i] < minValue)
    {
      minValue  = source_fp[i];
      *minIndex = i;
    }
  }
  return minValue;
}




//
// new_generation_x
//
// produces a new generation of chromosomes.
//
// INPUT: 
//    arrayRand : an array containing random number, in this function, 
//    we need uniform random variables.
// 
// OUTPUT:
//    G_fpPnewx: the newly generated population will be written to here
//
// REFER:
//    G_fpPx: the original population of chromosome
//    G_fpPn: the original population chromosome's control variable
//
void new_generation_x(float *arrayRand)
{
  int   i;
  float oldx[32];
  float oldn[32];
  float newx[32];
  
  for (i=0; i < G_nPSize; i++)
  {
    get_chromosome(G_fpPx,i,oldx);
    get_chromosome(G_fpPn,i,oldn);
    new_x(newx,oldx,oldn,i,arrayRand);
    set_chromosome(G_fpPnewx,i,newx);
  }
}



//
// new_generation_n
//
// produces a new generation of chromosome's control variable.
//
// INPUT: 
//    arrayR   : an array containing guassian random numbers
//    arrayGaus: an array containing guassian random numbers
// 
// OUTPUT:
//    G_fpPnewn: the newly generated control variables will be written to here
//
// REFER:
//    G_fpPn   : the original population chromosome's control variables
//
void new_generation_n(float *arrayR, float *arrayGaus)
{
  int   i;
  float oldn[32];
  float newn[32];
  
  for (i=0; i < G_nPSize; i++)
  {
    get_chromosome(G_fpPn,i,oldn);
    new_n(newn,i,oldn,arrayR,arrayGaus);
    set_chromosome(G_fpPnewn,i,newn);  
  }
}



//
// init
//
// initialization, memory allocation done here, must be first called before all other function
//
// INPUT:
//    NO
//
//  OUPUT:
//    G_nPSize
//    G_fpPx
//    G_fpPn
//    G_fpFitP
//    G_fpPnewx
//    G_fpPnewn
//    G_fpFitNewp
//    G_npWin1
//    G_npWin2

void init()
{
  long  myTime;
  myTime = time(&myTime);
  srand(myTime);
  G_nPSize = P_SIZE_X * P_SIZE_Y;
  G_fpPx = (float*) malloc(sizeof(float) * G_nPSize * 32);
  G_fpPn = (float*) malloc(sizeof(float) * G_nPSize * 32);
  G_fpFitP  = (float*) malloc(sizeof(float) * G_nPSize);
  G_fpPnewx = (float*) malloc(sizeof(float) * G_nPSize * 32);
  G_fpPnewn = (float*) malloc(sizeof(float) * G_nPSize * 32);
  G_fpFitNewp  = (float*) malloc(sizeof(float) * G_nPSize);
  G_npWin1 = (int*) malloc(sizeof(int) * G_nPSize);
  G_npWin2 = (int*) malloc(sizeof(int) * G_nPSize);
  temp = (float*) malloc(sizeof(float) * G_nPSize);
  G_fpOrderedList = (float*) malloc(sizeof(float) * G_nPSize);
  temp32 = (float*) malloc(sizeof(float) * G_nPSize * 32);
  if ((temp == NULL) || (G_fpPx == NULL) || (G_fpPn == NULL) || (G_fpFitP == NULL) || 
      (G_fpPnewx == NULL) || (G_fpPnewn == NULL) || (G_fpFitNewp== NULL) || (G_npWin1 == NULL) ||
      (G_npWin2 == NULL) || (G_fpOrderedList == NULL) || (temp32 == NULL))
    ErrExit("not enough memory\n");
  printf("finished [init]\n");  
}



//
// tournament
//
// the tournament round, in order to select the new generation
// it works as follow:
//  1. from the union of newly mutated population and the orginal population, each chromosome performs
//     a random pick up of an opponent from the union, it receives a win if its fitness value is smaller
//     than the opponent. The number of times of oppponent is controlled by TOUR_SIZE
//  2. the random pickup process works as first random draw and address between [0, population size -1], 
//     and then toss a coin (random), to see if the opponent is the original population or the newly mutated
//     population
//
// INPUT:
//  fp1 : fitness values of all chromosomes of the original population
//  fp2 : fitness values of all chromosomes of the newly mutated population
//
// OUTPUT:
//  win1: the winning value of the original population
//  win2: the winning value of the newly generated population
//
void tournament(float *fp1, float *fp2, int *win1, int *win2)
{
  int i;
  
  int sel;
  int j,k;

  for (i=0; i < G_nPSize; i++)
  {
    win1[i] = 0;
    // for the original population
    for (k=0 ; k < TOUR_SIZE ; k++)
    {
      sel = (int) floor((rand()/(float)RAND_MAX) * (G_nPSize - 1) + 0.5);
      // toss a coin the see if the original population or the newly mutated population
      j = rand() % 2;
      if (j == 0)
      {
        if (fp1[i] < fp1[sel])
          win1[i]++;      
      }
      else
      {
        if (fp1[i] < fp2[sel])
          win1[i]++;
      }
    }
  }
  // for the newly mutated population
  for (i=0; i < G_nPSize; i++)
  {
    win2[i] = 0;
    for (k = 0; k < TOUR_SIZE; k++)
    {
      sel = (int) floor((rand()/(float)RAND_MAX) * (G_nPSize - 1) + 0.5);
      j = rand() % 2;
      if (j == 0)
      {
        if (fp2[i] < fp1[sel])
          win2[i]++;      
      }
      else
      {
        if (fp2[i] < fp2[sel])
          win2[i]++;
      }
    }
  }
}





//
// build_order
//
// to determine which chromosome from the union of original population and the newly mutated population
// to be survived. It first counts the winning function to pick up the median winning value. 
// Chromosome having winning value larger or equals to median winning value survived. 
// First this pogram will count how many winning for each group, group means winning value of 0,1, 2, 3..., TOUR_SIZE
// then we count the number of win of each group until popualtion size met, since the union have the size of 2 * population size
// the group having cumulative number of win equals to population size is the medina winning value
// After the median found
// we check which of the chromosome survive
// we scan the orginal chromosome's winning value, if it exceeds or equal to medain winning value, it survies
// if it is not, we scan the newly mutated chromomosome's winning value, and replace the original chromosome by the first newly
// mutated chromosome having value equal or exceeds the median winning value
//
// INPUT:
//   win_original : the winning value of original population
//   win_new      : the winning value of newly mutated population
//
// OUTPUT:
//   G_fpOrderedList: the location of the survival chromosome
//   G_fpOrderedList[i]  = -1 represent the chromosome should taken from original chromosome's location i;
//   G_fpOrderedList[i]  = n, where n is an +ve integer means the chromsome should taken from the newly mutated chrosomes' location n
//
//
void build_order(int *win_original, int *win_new, float *G_fpOrderedList)
{
  int   count[TOUR_SIZE + 1];
  int   i;
  int   temp;
  int   min_win;    // record at least how many win to survive
  int   left_original,left_new;

  // 10-10-2005 MLWong
  int	no_median;  // The number of survival individuals with median win value  

  for (i=0; i <= TOUR_SIZE; i++)
    count[i] = 0;
  for (i=0; i < G_nPSize; i++)
  {   
    count[win_original[i]]++;
    count[win_new[i]]++;

  }
  temp = 0;
  for (i=TOUR_SIZE; i >= 0; i--)
  {
    temp += count[i];

    if (temp >= G_nPSize)
    {
      min_win = i;   // median win value	
      no_median = count[i] - (temp - G_nPSize);   // 10-10-2005 MLWong
      break;
    }
  }

  // 10-10-2005 MLWong  
  // The following code ensures the number of chromosomes (with win value
  // value = median win value) must be bounded by no_median. This avoids
  // chromosomes with better win value being killed due to insufficient 
  // space (occupied by chromosomes with median win value).
  left_new = 0;  
  for (left_original=0; left_original < G_nPSize ; left_original++)
  {
    if (win_original[left_original] > min_win)
    {
      G_fpOrderedList[left_original] = -1;  // marked as "survive"
    }
    else if ((win_original[left_original] == min_win) && (no_median > 0))
    {
      G_fpOrderedList[left_original] = -1;  // marked as "survive"
      no_median--;
    }
    else
    {
      if (no_median > 0)  // < min_win
      {
        while (win_new[left_new] < min_win)
          left_new++;
        // now left_new is point to one at least min_win
        // swap with left_new      
        G_fpOrderedList[left_original] = left_new;      
        if (win_new[left_new] == min_win)
          no_median--;
        left_new++;
      }
      else 
      {
        while (win_new[left_new] <= min_win)
          left_new++;
        // now left_new is point to one large than min_win
        // swap with left_new      
        G_fpOrderedList[left_original] = left_new;      
        left_new++;
      }
    }
  }
  // End MLWong
}



//
// reorder_new
//
// actual moving the chromosome in this function, according to the result from build_order
// it copies the value of soruce_array (s_array) to target array (t_array) if the input is a positive integer
//
// INPUT  
//   t_array : the target_array, if the G_fpOrederList[i] == -1, then it won't change, else it's value is overwrite by the
//             corresponding value is s_array
//   s_array : the source_array, it is the array containing the newly mutated eta or chromosome
//   G_fpOrderList: the list containing how the value of t_array should be overwrite
//
// OUTPUT
//    t_array       
//
void reorder_new(float* t_array, float *s_array,float *G_fpOrderedList)
{
  float chromosome[32];  
  int   left;

  left = 0;
  for (left=0; left < G_nPSize ; left++)
  {
    if (floor(G_fpOrderedList[left]) == -1)
    {
      //do nothing
    }
    else
    {
      get_chromosome(s_array,floor(G_fpOrderedList[left]),chromosome);
      set_chromosome(t_array,left,chromosome);
    }    
  }
}


//
//  SoftwareLoop
//
//  The core function of software implementation of EC
//  Algorithm of EC
//  1. Initailize a population, a population contains POPULAION SIZE (G_nPSize) of chromosmome
//    in this implementation, we use chromosome of size 32, i.e. the chromosome contains 32 variables.
//  2. Perform fitness evulation, i.e. the objective function, in this implementation, we assumed we try 
//     to MINIMIZE the objective functions
//  3. We produce new population by perform mutation using Cauchy Mutation stated in the paper.
//  4. Then we perform tournaments on the union of mutated population (new population) and 
//     the parent population to generate the next generation,  i.e. totally size of 2 * G_nPSize
//     chromosome. Each tournament round picks up a random opponent, the chromosome wins 
//     if its objective value is smaller than that of opponent. The total rounds of of tournament 
//     is controlled by variable TOUR_SIZE.
//  5. the G_nPsize chromosme having the winning value higher than the median winning value is selected as the new generation
//  6. Go to Step 2 until maximum number of generation (G_nTmax) is reached
//
void SoftwareLoop()
{
  int t;
  int i;
  int  oneFifty;

  double st,et;       //st,et,st1,et1,et2 used for time counting
  double st1,et1,et2;
  double sort_time;
  double fitness_time;
  double generation_time;

  sort_time =0 ;
  fitness_time = 0;
  generation_time = 0;
  printf("Software Approach\n");
  oneFifty = G_nTmax / 50;
  st = myTime();

  //initialize the first population
  for (i=0; i < G_nPSize * 32; i++)
  {
    G_fpPx[i] = uni_rand(RANGE);
    G_fpPn[i] = uni_rand(RANGE);
  }

  //avoid division by zero error
  if (oneFifty == 0)
    oneFifty = 1;

  printf("Progress\n");
  printf("0________20________40________60________80________100%%\n");


  //loop it G_nTmax time, G_nTmax is the maximum generation allowed
  for (t=0; t <= G_nTmax; t++)
  {
    st1 = myTime();
    //calculate the current population's objective value
    cal_fitness(G_fpPx,G_fpFitP);
    et1 = myTime();
    fitness_time += et1 - st1;

    st1 = myTime();
    //======Create one random texture for "C"=====================================================
    for (i=0; i < G_nPSize*32; i++)
      temp32[i] = rand()/(double) RAND_MAX;      
    //generate the newly mutated population, it will stored in G_newX
    new_generation_x(temp32);

    //=====Prepare two random texture============================================================================
    for (i=0; i < G_nPSize; i++)
      temp[i] = (float) normsinv(rand()/(double) RAND_MAX);
    for (i=0; i < G_nPSize*32; i++)
      temp32[i] = (float) normsinv(rand()/(double) RAND_MAX);      
    //===========================================================================================================      
    //generate the newly mutated eta, it will stored in G_newN
    new_generation_n(temp,temp32);      
    et1 = myTime();
    generation_time += et1 - st1;

    st1 = myTime();
    //cacluate the fitness value of mutated generation
    cal_fitness(G_fpPnewx,G_fpFitNewp);
    et1 = myTime();
    fitness_time += et1 - st1;

    st1 = myTime();
    //perform tournament round
    tournament(G_fpFitP,G_fpFitNewp,G_npWin1,G_npWin2);
    build_order(G_npWin1,G_npWin2,G_fpOrderedList);
    reorder_new(G_fpPx,G_fpPnewx,G_fpOrderedList);
    reorder_new(G_fpPn,G_fpPnewn,G_fpOrderedList);
    et1 = myTime();
    sort_time += et1 - st1;
    //printf("%d, %f \n",t, min_f(G_fpFitP,&i));

    if (t % oneFifty == 0)
    {
      printf(".");
    }
    if (t % 100 == 0)
    {	    
      et2 = myTime();
      fprintf(timefile,"%lf\t",et2-st);
      fprintf(outfile,"%f\t",min_f(G_fpFitP,&i));
    }
  }
  printf("\n");
  et = myTime();

  //output to statistical file
  fprintf(timefile,"\n"); 
  fprintf(outfile,"\n"); 
  fprintf(otherfile,"%lf\t",et-st);
  fprintf(otherfile,"%lf\t",sort_time);
  fprintf(otherfile,"%lf\t",fitness_time);
  fprintf(otherfile,"%lf\n",generation_time); 
  fclose(outfile);
  fclose(timefile);
  fclose(otherfile);
  printf("finished [SoftwareLoop]\n");
  printf("(1a) Total time used      : %lf\n",et-st);
  printf("(2a) Sort  time used      : %lf\n",sort_time);
  printf("(3a) Fitness time used    : %lf\n",fitness_time);
  printf("(4a) Generation time used : %lf\n",generation_time);
  printf("(5a) min Value            : %f\n",min_f(G_fpFitP,&i));
  printf("\n\n");
}




//=========================HARDWARE RELATED CODE===================================================

//
//  cgErrorCallback
//  
//  a CG error call back error subroutine, responsible to display error message if shader 
//  content have problem
//
//  REFER:
//    CG_ShaderContext
//
void cgErrorCallback(void)
{
  CGerror lastError = cgGetError();
  if(lastError)
  {
    fprintf(stderr,"%s\n",cgGetErrorString(lastError));
    fprintf(stderr,"%s\n",cgGetLastListing(CG_ShaderContext));
    ErrExit("<cgErrorCallback> CG error\n");
  }
  return;
}





//
//  loadshare
//
//  it is used to load the shader file into memory
//  the shader file should be put in the folder ./shader/
//  this program contains serval important shader file
//  1. fitness.cg : the shader which calculate the objective value of chromosomes
//  2. newn.cg    : the shader to evolute the eta part 
//  3. newx.cg    : the shader to evolute the chromosome
//  4. reorder.cg: the shader to assign the new generation of chromosome according to the ordered texture given by CPU
//  5. display.cg : simple shader to draw out the choromosome on the screen
//
void loadShader()
{
  cgSetErrorCallback(cgErrorCallback);
  CG_ShaderContext   = cgCreateContext();
  CG_fragmentProfile = cgGLGetLatestProfile(CG_GL_FRAGMENT);
  //CG_fragmentProfile = CG_PROFILE_FP40;
  cgGLSetOptimalOptions(CG_fragmentProfile);

  //====fitness value calcalation====================================
  CG_f = cgCreateProgramFromFile(CG_ShaderContext, CG_SOURCE, SHADER_FILE, CG_fragmentProfile, NULL, 0);
  cgGLLoadProgram(CG_f);
  CG_f_texPx = cgGetNamedParameter(CG_f, "texPx");
  CG_f_POP_SIZE_X = cgGetNamedParameter(CG_f, "POP_SIZE_X");
  CG_f_POP_SIZE_Y = cgGetNamedParameter(CG_f, "POP_SIZE_Y");
  cgGLSetParameter1f(CG_f_POP_SIZE_X,(float) P_SIZE_X);
  cgGLSetParameter1f(CG_f_POP_SIZE_Y,(float) P_SIZE_Y);
  if (CG_f_texPx == 0)
    ErrExit("[loadshader]: invalid parameter handeler");
  //=================================================================

  //==============new n======================================
  CG_newn = cgCreateProgramFromFile(CG_ShaderContext, CG_SOURCE, "./shader/newn.cg", CG_fragmentProfile, NULL, 0);
  cgGLLoadProgram(CG_newn);
  CG_newn_texPn   = cgGetNamedParameter(CG_newn, "texPn");
  CG_newn_texR    = cgGetNamedParameter(CG_newn, "texR");
  CG_newn_texGaus = cgGetNamedParameter(CG_newn, "texGaus");
  CG_newn_searchRange = cgGetNamedParameter(CG_newn, "searchRange");
  cgGLSetParameter1f(CG_newn_searchRange,(float) RANGE);

  CG_newn_P_SIZE_X = cgGetNamedParameter(CG_newn, "P_SIZE_X");
  cgGLSetParameter1f(CG_newn_P_SIZE_X,(float) P_SIZE_X);
  CG_newn_P_SIZE_Y = cgGetNamedParameter(CG_newn, "P_SIZE_Y");
  cgGLSetParameter1f(CG_newn_P_SIZE_Y,(float) P_SIZE_Y);
  if ((CG_newn_texPn == 0) || (CG_newn_texR == 0) || (CG_newn_texGaus == 0))
    ErrExit("[loadshader]: invalid parameter handeler");
  //=================================================================

  //==============new x======================================
  CG_newx = cgCreateProgramFromFile(CG_ShaderContext, CG_SOURCE, "./shader/newx.cg", CG_fragmentProfile, NULL, 0);
  cgGLLoadProgram(CG_newx);
  CG_newx_texPn   = cgGetNamedParameter(CG_newx, "texPn");
  CG_newx_texPx   = cgGetNamedParameter(CG_newx, "texPx");
  CG_newx_texRand = cgGetNamedParameter(CG_newx, "texRand");
  CG_newx_texRand2 = cgGetNamedParameter(CG_newx, "texRand2");
  CG_newx_searchRange = cgGetNamedParameter(CG_newx, "searchRange");
  cgGLSetParameter1f(CG_newx_searchRange,(float) RANGE);

  if ((CG_newx_texPn == 0) || (CG_newx_texPx == 0) || (CG_newx_texRand == 0) || (CG_newx_texRand2 == 0))
    ErrExit("[loadshader]: invalid parameter handeler");
  //=================================================================

  //==================Reordering======================================
  CG_reorder = cgCreateProgramFromFile(CG_ShaderContext, CG_SOURCE, "./shader/reorder.cg", CG_fragmentProfile, NULL, 0);
  cgGLLoadProgram(CG_reorder);
  CG_reorder_texP1   = cgGetNamedParameter(CG_reorder, "texP1");
  CG_reorder_texP2   = cgGetNamedParameter(CG_reorder, "texP2");
  CG_reorder_texOrderList   = cgGetNamedParameter(CG_reorder, "texOrderList");
  CG_reorder_P_SIZE_X   = cgGetNamedParameter(CG_reorder, "P_SIZE_X");
  CG_reorder_P_SIZE_Y   = cgGetNamedParameter(CG_reorder, "P_SIZE_Y");

  if ((CG_reorder_texP1 == 0) || (CG_reorder_texP2 == 0) || (CG_reorder_texOrderList == 0) || 
      (CG_reorder_P_SIZE_X == 0) || (CG_reorder_P_SIZE_Y == 0))
    ErrExit("[loadshader]: invalid parameter handeler");

  cgGLSetParameter1f(CG_reorder_P_SIZE_X,(float) P_SIZE_X);
  cgGLSetParameter1f(CG_reorder_P_SIZE_Y,(float) P_SIZE_Y);
  //=================================================================

  CG_display = cgCreateProgramFromFile(CG_ShaderContext, CG_SOURCE, "./shader/display.cg", CG_fragmentProfile, NULL, 0);
  cgGLLoadProgram(CG_display);
  CG_display_texDisplay   = cgGetNamedParameter(CG_display, "texDisplay");
  CG_display_texWidth     = cgGetNamedParameter(CG_display, "texWidth");
  CG_display_texHeight    = cgGetNamedParameter(CG_display, "texHeight");
  CG_display_lboundary    = cgGetNamedParameter(CG_display, "lboundary");
  CG_display_uboundary    = cgGetNamedParameter(CG_display, "uboundary");
  cgGLSetParameter1f(CG_display_texWidth,(float) P_SIZE_X);
  cgGLSetParameter1f(CG_display_texHeight,(float) P_SIZE_Y);

#ifdef F1
  cgGLSetParameter1f(CG_display_lboundary,0);
  cgGLSetParameter1f(CG_display_uboundary,10);
#elif defined(F2)
  cgGLSetParameter1f(CG_display_lboundary,0);
  cgGLSetParameter1f(CG_display_uboundary,60);
#elif defined(F3)
  cgGLSetParameter1f(CG_display_lboundary,0);
  cgGLSetParameter1f(CG_display_uboundary,20);
#elif defined(F4)
  cgGLSetParameter1f(CG_display_lboundary,1550);
  cgGLSetParameter1f(CG_display_uboundary,1850);
#elif defined(F5)
  cgGLSetParameter1f(CG_display_lboundary,0);
  cgGLSetParameter1f(CG_display_uboundary,10);
#endif

  

  //new random
  CG_random = cgCreateProgramFromFile(CG_ShaderContext, CG_SOURCE, "./shader/random.cg", CG_fragmentProfile, NULL, 0);
  cgGLLoadProgram(CG_random);
  CG_random_texInput = cgGetNamedParameter(CG_random, "texInput");



  if (CG_display_texDisplay == 0)
    ErrExit("[loadshader]: invalid parameter handeler");
}


//
//  display
//
//  core hardware implementation of EP
//  It contains the major operations to be done in one evolution
// 
//  Algorithm of EP
//  1. Initialize a population, a population contains POPULATION SIZE (G_nPSize) of chromosomes
//     in this implementation, we use chromosome of size 32, i.e. each chromosome contains 32 variables.
//  2. Perform fitness evaluation, i.e. the objective function, in this implementation, we assumed we try 
//     to MINIMIZE the objective functions
//  3. we produce new population by perform mutation using Cauchy Mutation stated in the paper.
//  4. For the union of mutated population (new population) and the original population, i.e. totally size of 2 * G_nPSize chromosmes, we 
//     perform tournament rounds, each tournament round involve to pick up a random opponent, the chromosome wins if its objective value
//     is smaller than that of opponent, the time of tournament is controlled by variable TOUR_SIZE.
//  5. the G_nPsize chromosome having the win value higher than the median win value is selected (or survived) as the new generation
//  6. Go to Step 2 until maximum number of generation (G_nTmax) is reached
//
//  Steps 1 and 4 will be performed by software
//  Steps 2, 3, and 5 are performed by GPU
//
void display()
{
  static char       FIRST = 1;
  int               i;
  static            t=0;
  static double     st,et;
  double            st1,et1,et2;
  static double     fitness_time =0;
  static double     generation_time = 0;
  static double     sort_time = 0;
  int               oneHundred;
  char              aString[100];
  static int        count = 0;

  oneHundred = G_nTmax / 100;
  if (oneHundred == 0)
    oneHundred = 1;

  if (t==0)      // step 1, initialize the first generation
  {              // done for the first time only
    st = myTime();
    for (i=0 ; i < G_nPSize*32 ; i++)
    {
      G_fpPx[i] = uni_rand(RANGE);  // initialized as uniform random values
      G_fpPn[i] = uni_rand(RANGE);
    }

    // bind the G_fpPx and G_fpPn to textures, to be accessed by GPU
    // x part
    glBindTexture(GL_TEXTURE_RECTANGLE_NV, G_texPx);  
    shader_set_tex_para();
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_FLOAT_RGBA32_NV,P_SIZE_X*4,P_SIZE_Y*2,0,GL_RGBA,GL_FLOAT,G_fpPx);   
    // eta part
    glBindTexture(GL_TEXTURE_RECTANGLE_NV, G_texPn);
    shader_set_tex_para();
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_FLOAT_RGBA32_NV,P_SIZE_X*4,P_SIZE_Y*2,0,GL_RGBA,GL_FLOAT,G_fpPn);
  }      

  // evaluate the fitness value
  st1 = myTime();
  G_rtFitP->BeginCapture();
    cgGLEnableProfile(CG_fragmentProfile);  
    cgGLBindProgram(CG_f);
    if (t == 0)
      cgGLSetTextureParameter(CG_f_texPx,G_texPx);
    else 
    {
      // since the next rendering pass will need the result of previous rendering pass, so
      // we prepared two p-buffer rt, and swap it for input and output each rendering pass
      if (t % 2 == 0)  // even pass
        cgGLSetTextureParameter(CG_f_texPx,G_rtPx1->GetTextureID());
      else             // odd  pass
        cgGLSetTextureParameter(CG_f_texPx,G_rtPx0->GetTextureID());
    }
    cgGLEnableTextureParameter(CG_f_texPx);
    shaderDrawQuad(P_SIZE_X,P_SIZE_Y);        // Perform evaluation by shader
    glReadPixels(0,0,P_SIZE_X,P_SIZE_Y,GL_RED,GL_FLOAT,G_fpFitP);  // download fitness values to main memory
    cgGLDisableTextureParameter(CG_f_texPx);
    cgGLDisableProfile(CG_fragmentProfile);
  G_rtFitP->EndCapture();        
  et1 = myTime();
  fitness_time += et1 - st1;

  st1 = myTime();
  //=============================Cachy EP=======================================================

  if (GPU_RANDOM == 1)
  {
    if (t == 0)
    {
      //======Create one random texture for "C"=====================================================
      for (i=0; i < G_nPSize*32; i++)   // Generate uniform random buffer and store in main memory
        temp32[i] = (float) rand();

      // Transfer random value buffer from main memory to texture memory
      glBindTexture(GL_TEXTURE_RECTANGLE_NV, G_texTemp32);
      shader_set_tex_para(); 
      glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_FLOAT_RGBA32_NV,P_SIZE_X*4,P_SIZE_Y*2,0,GL_RGBA,GL_FLOAT,temp32);  
      G_rtRandomFull[0]->BeginCapture();
        cgGLEnableProfile(CG_fragmentProfile);  
        cgGLBindProgram(CG_random);
        cgGLSetTextureParameter(CG_random_texInput,G_texTemp32);
        cgGLEnableTextureParameter(CG_random_texInput);
        shaderDrawQuad(P_SIZE_X*4,P_SIZE_Y*2);    // actual perform the generation of population
        cgGLDisableTextureParameter(CG_random_texInput);
        cgGLDisableProfile(CG_fragmentProfile);
      G_rtRandomFull[0]->EndCapture();
    }
    else
    {
      G_rtRandomFull[t%2]->BeginCapture();
        cgGLEnableProfile(CG_fragmentProfile);  
        cgGLBindProgram(CG_random);
        cgGLSetTextureParameter(CG_random_texInput,G_rtRandomFull[(t+1)%2]->GetTextureID());
        cgGLEnableTextureParameter(CG_random_texInput);
        shaderDrawQuad(P_SIZE_X*4,P_SIZE_Y*2);    // actual perform the generation of population
        cgGLDisableTextureParameter(CG_random_texInput);
        cgGLDisableProfile(CG_fragmentProfile);
      G_rtRandomFull[t%2]->EndCapture();
    }
  }
  else
  {
    for (i=0; i < G_nPSize*32; i++)   // Generate uniform random buffer and store in main memory
      temp32[i] = (float) rand();

    // Transfer random value buffer from main memory to texture memory
    glBindTexture(GL_TEXTURE_RECTANGLE_NV, G_texTemp32);
    shader_set_tex_para(); 
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_FLOAT_RGBA32_NV,P_SIZE_X*4,P_SIZE_Y*2,0,GL_RGBA,GL_FLOAT,temp32);  
  }



  //===========================new_Population_x==================================================
  G_rtPnewx->BeginCapture();
    cgGLEnableProfile(CG_fragmentProfile);  
    cgGLBindProgram(CG_newx);
    if (t == 0)
    {
      cgGLSetTextureParameter(CG_newx_texPx,G_texPx);
      cgGLSetTextureParameter(CG_newx_texPn,G_texPn);
    }
    else
    {
      if (t %2 == 0) // even pass
      {
        cgGLSetTextureParameter(CG_newx_texPx,G_rtPx1->GetTextureID());
        cgGLSetTextureParameter(CG_newx_texPn,G_rtPn1->GetTextureID());
      }
      else           // odd pass
      {
        cgGLSetTextureParameter(CG_newx_texPx,G_rtPx0->GetTextureID());
        cgGLSetTextureParameter(CG_newx_texPn,G_rtPn0->GetTextureID());
      }
    }
    cgGLEnableTextureParameter(CG_newx_texPx);               
    cgGLEnableTextureParameter(CG_newx_texPn);       
    if (GPU_RANDOM == 0)
      cgGLSetTextureParameter(CG_newx_texRand,G_texTemp32);
    else
      cgGLSetTextureParameter(CG_newx_texRand,G_rtRandomFull[t%2]->GetTextureID());
    cgGLEnableTextureParameter(CG_newx_texRand);        
    shaderDrawQuad(P_SIZE_X*4,P_SIZE_Y*2);    // actual perform the generation of population
    //glReadPixels(0,0,P_SIZE_X*4,P_SIZE_Y*2,GL_RGBA,GL_FLOAT,G_fpPnewx);               
    cgGLDisableTextureParameter(CG_newx_texPx);       
    cgGLDisableTextureParameter(CG_newx_texPn);       
    cgGLDisableTextureParameter(CG_newx_texRand);       
    cgGLDisableProfile(CG_fragmentProfile);
  G_rtPnewx->EndCapture();        
  //===========================new_generation_x==================================================
   
  


  if (GPU_RANDOM == 1)
  {
    if (t == 0)
    {
      // Transfer random value buffer in main memory to GPU texture buffer.
      for (i=0; i < G_nPSize; i++)
        temp[i] = (float) rand();
      glBindTexture(GL_TEXTURE_RECTANGLE_NV, G_texTemp);
      shader_set_tex_para();
      glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_FLOAT_R32_NV,P_SIZE_X,P_SIZE_Y,0,GL_LUMINANCE,GL_FLOAT,temp);    
  
      for (i=0; i < G_nPSize*32; i++)
        temp32[i] = (float) rand();
      glBindTexture(GL_TEXTURE_RECTANGLE_NV, G_texTemp32);
      shader_set_tex_para();
      glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_FLOAT_RGBA32_NV,P_SIZE_X*4,P_SIZE_Y*2,0,GL_RGBA,GL_FLOAT,temp32);


      G_rtRandom1[0]->BeginCapture();
        cgGLEnableProfile(CG_fragmentProfile);  
        cgGLBindProgram(CG_random);
        cgGLSetTextureParameter(CG_random_texInput,G_texTemp);
        cgGLEnableTextureParameter(CG_random_texInput);
        shaderDrawQuad(P_SIZE_X,P_SIZE_Y);    // actual perform the generation of population
        cgGLDisableTextureParameter(CG_random_texInput);
        cgGLDisableProfile(CG_fragmentProfile);
      G_rtRandom1[0]->EndCapture();

      G_rtRandomFull1[0]->BeginCapture();
        cgGLEnableProfile(CG_fragmentProfile);  
        cgGLBindProgram(CG_random);
        cgGLSetTextureParameter(CG_random_texInput,G_texTemp32);
        cgGLEnableTextureParameter(CG_random_texInput);
        shaderDrawQuad(P_SIZE_X*4,P_SIZE_Y*2);    // actual perform the generation of population
        cgGLDisableTextureParameter(CG_random_texInput);
        cgGLDisableProfile(CG_fragmentProfile);
      G_rtRandomFull1[0]->EndCapture();
    }
  
    else
    {
      G_rtRandom1[t%2]->BeginCapture();
        cgGLEnableProfile(CG_fragmentProfile);  
        cgGLBindProgram(CG_random);
        cgGLSetTextureParameter(CG_random_texInput,G_rtRandom1[(t+1)%2]->GetTextureID());
        cgGLEnableTextureParameter(CG_random_texInput);
        shaderDrawQuad(P_SIZE_X,P_SIZE_Y);    // actual perform the generation of population
        cgGLDisableTextureParameter(CG_random_texInput);
        cgGLDisableProfile(CG_fragmentProfile);
      G_rtRandom1[t%2]->EndCapture();

      G_rtRandomFull1[t%2]->BeginCapture();
        cgGLEnableProfile(CG_fragmentProfile);  
        cgGLBindProgram(CG_random);
        cgGLSetTextureParameter(CG_random_texInput,G_rtRandomFull1[(t+1)%2]->GetTextureID());
        cgGLEnableTextureParameter(CG_random_texInput);
        shaderDrawQuad(P_SIZE_X*4,P_SIZE_Y*2);    // actual perform the generation of population
        cgGLDisableTextureParameter(CG_random_texInput);
        cgGLDisableProfile(CG_fragmentProfile);
      G_rtRandomFull1[t%2]->EndCapture();

    }
  }
  else
  {
    //===== Prepare two random textures ===========================================================      
    // Transfer random value buffer in main memory to GPU texture buffer.
    for (i=0; i < G_nPSize; i++)
      temp[i] = (float) rand();
    glBindTexture(GL_TEXTURE_RECTANGLE_NV, G_texTemp);
    shader_set_tex_para();
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_FLOAT_R32_NV,P_SIZE_X,P_SIZE_Y,0,GL_LUMINANCE,GL_FLOAT,temp);      

    for (i=0; i < G_nPSize*32; i++)
      temp32[i] = (float) rand();
    glBindTexture(GL_TEXTURE_RECTANGLE_NV, G_texTemp32);
    shader_set_tex_para();
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_FLOAT_RGBA32_NV,P_SIZE_X*4,P_SIZE_Y*2,0,GL_RGBA,GL_FLOAT,temp32);
    //===========================================================================================================      
  }






  //====new_generation_n===================
  G_rtPnewn->BeginCapture();
    cgGLEnableProfile(CG_fragmentProfile);  
    cgGLBindProgram(CG_newn);
    if (t == 0)
      cgGLSetTextureParameter(CG_newn_texPn,G_texPn);
    else
    {
      if (t %2 == 0) // even pass
        cgGLSetTextureParameter(CG_newn_texPn,G_rtPn1->GetTextureID());
      else           // odd pass
        cgGLSetTextureParameter(CG_newn_texPn,G_rtPn0->GetTextureID());
    }
    cgGLEnableTextureParameter(CG_newn_texPn);       
    if (GPU_RANDOM == 0)
      cgGLSetTextureParameter(CG_newn_texR,G_texTemp);
    else
      cgGLSetTextureParameter(CG_newn_texR,G_rtRandom[t%2]->GetTextureID());
    cgGLEnableTextureParameter(CG_newn_texR);         

    if (GPU_RANDOM == 0)
      cgGLSetTextureParameter(CG_newn_texGaus,G_texTemp32);
    else
      cgGLSetTextureParameter(CG_newn_texGaus,G_rtRandomFull1[t%2]->GetTextureID());
    cgGLEnableTextureParameter(CG_newn_texGaus);      
    shaderDrawQuad(P_SIZE_X*4,P_SIZE_Y*2);   //actual perform new population's control variable (eta part)
    //glReadPixels(0,0,P_SIZE_X*4,P_SIZE_Y*2,GL_RGBA,GL_FLOAT,G_fpPnewn);               
    cgGLDisableTextureParameter(CG_newn_texPn);
    cgGLDisableTextureParameter(CG_newn_texR);
    cgGLDisableTextureParameter(CG_newn_texGaus);
    cgGLDisableProfile(CG_fragmentProfile);
  G_rtPnewn->EndCapture();        
  //==== end of new_generation_n===================
  et1 = myTime();
  generation_time += et1 - st1;

  st1= myTime();
  //======Calculate fitness of mutated population =========================
  G_rtFitPnew->BeginCapture();
    cgGLEnableProfile(CG_fragmentProfile);  
    cgGLBindProgram(CG_f);
    cgGLSetTextureParameter(CG_f_texPx,G_rtPnewx->GetTextureID());
    cgGLEnableTextureParameter(CG_f_texPx);
    shaderDrawQuad(P_SIZE_X,P_SIZE_Y);        // calculate the fitness value
    glReadPixels(0,0,P_SIZE_X,P_SIZE_Y,GL_RED,GL_FLOAT,G_fpFitNewp); // download fitness value from GPU to CPU, it must be read back since the need of counting median and minimum fitness
    cgGLDisableTextureParameter(CG_f_texPx);
    cgGLDisableProfile(CG_fragmentProfile);
  G_rtFitPnew->EndCapture();        
  //====== end of Calculate fitness of mutated population =========================
  et1 = myTime();
  fitness_time += et1 - st1;
                       
      
  st1 = myTime();
  // perform tournament selection using software
  tournament(G_fpFitP,G_fpFitNewp,G_npWin1,G_npWin2); 
  // the texture contain which chromosome is perserved for next generation
  build_order(G_npWin1,G_npWin2,G_fpOrderedList);
  // upload the texture to GPU memory     
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, G_texTemp);
  shader_set_tex_para();
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_FLOAT_R32_NV,P_SIZE_X,P_SIZE_Y,0,GL_LUMINANCE,GL_FLOAT,G_fpOrderedList);  

  //=======Reorder Px============================================================
  if (t % 2 == 0)  // even pass
    G_rtPx0 ->BeginCapture();
  else             // odd pass
    G_rtPx1 ->BeginCapture();

    cgGLEnableProfile(CG_fragmentProfile);  
    cgGLBindProgram(CG_reorder);
    cgGLSetTextureParameter(CG_reorder_texOrderList,G_texTemp);
    cgGLEnableTextureParameter(CG_reorder_texOrderList);
    if (t == 0)
      cgGLSetTextureParameter(CG_reorder_texP1,G_texPx);
    else
    {
      if (t %2 == 0)  // even pass
        cgGLSetTextureParameter(CG_reorder_texP1,G_rtPx1->GetTextureID());
      else            // odd pass
        cgGLSetTextureParameter(CG_reorder_texP1,G_rtPx0->GetTextureID()); 
    }
    cgGLEnableTextureParameter(CG_reorder_texP1);
    cgGLSetTextureParameter(CG_reorder_texP2,G_rtPnewx->GetTextureID());
    cgGLEnableTextureParameter(CG_reorder_texP2);
    shaderDrawQuad(P_SIZE_X*4,P_SIZE_Y*2);  // actual reorder the chromosome, forming new generation
    cgGLDisableTextureParameter(CG_reorder_texOrderList);
    cgGLDisableTextureParameter(CG_reorder_texP1);
    cgGLDisableTextureParameter(CG_reorder_texP2);       
    cgGLDisableProfile(CG_fragmentProfile);

  if (t % 2== 0)
    G_rtPx0 ->EndCapture();
  else
    G_rtPx1 ->EndCapture();
    //=======Reorder Px============================================================

    //=========== reorder the eta =====================================================
    if (t % 2 == 0)  // even pass
      G_rtPn0 ->BeginCapture();
    else             // odd pass
      G_rtPn1 ->BeginCapture();

      cgGLEnableProfile(CG_fragmentProfile);  
      cgGLBindProgram(CG_reorder);
      cgGLSetTextureParameter(CG_reorder_texOrderList,G_texTemp);
      cgGLEnableTextureParameter(CG_reorder_texOrderList);
      if (t == 0)
        cgGLSetTextureParameter(CG_reorder_texP1,G_texPn);
      else
      {
        if (t %2 == 0) // even pass
          cgGLSetTextureParameter(CG_reorder_texP1,G_rtPn1->GetTextureID());
        else           // odd pass
          cgGLSetTextureParameter(CG_reorder_texP1,G_rtPn0->GetTextureID()); 
      }
      cgGLEnableTextureParameter(CG_reorder_texP1);
      cgGLSetTextureParameter(CG_reorder_texP2,G_rtPnewn->GetTextureID());
      cgGLEnableTextureParameter(CG_reorder_texP2);
      shaderDrawQuad(P_SIZE_X*4,P_SIZE_Y*2);          // reorder the eta   
      cgGLDisableTextureParameter(CG_reorder_texOrderList);
      cgGLDisableTextureParameter(CG_reorder_texP1);
      cgGLDisableTextureParameter(CG_reorder_texP2);       
      cgGLDisableProfile(CG_fragmentProfile);
  
    if (t % 2== 0)  // even pass
      G_rtPn0 ->EndCapture();
    else            // odd pass
      G_rtPn1 ->EndCapture();
    et1 = myTime();
    sort_time += et1 - st1;      

      
    // simply display it out to the screen                
    cgGLEnableProfile(CG_fragmentProfile);  
    cgGLBindProgram(CG_display);     
    cgGLSetTextureParameter(CG_display_texDisplay,G_rtPnewx->GetTextureID());
    cgGLEnableTextureParameter(CG_display_texDisplay);
    shaderDrawQuad(P_SIZE_X*4,P_SIZE_Y*2);             
    cgGLDisableTextureParameter(CG_display_texDisplay);
    cgGLDisableProfile(CG_fragmentProfile);
      
    
    // output statistics to file
    if (t % 100 == 0)
    {
      et2 = myTime();
      fprintf(timefile,"%lf\t",et2-st);
      fprintf(outfile,"%f\t",min_f(G_fpFitP,&i));
    }

    if (t % oneHundred == 0)
    {
      sprintf(aString,"%d %%",count);
      glutSetWindowTitle(aString);   
      count++;
    }      

    if (t == G_nTmax)
    {
      et = myTime();
      printf("(1b) Total time used      : %lf\n",et-st);
      printf("(2b) Sort  time used      : %lf\n",sort_time);
      printf("(3b) Fitness time used    : %lf\n",fitness_time);
      printf("(4b) Generation time used : %lf\n",generation_time);
      printf("(5b) min Value            : %f\n",min_f(G_fpFitP,&i));
      printf("\n\n");
      fprintf(outfile,"\n");
      fprintf(timefile,"\n");
      fprintf(otherfile,"%lf\t",et-st);
      fprintf(otherfile,"%lf\t",sort_time);
      fprintf(otherfile,"%lf\t",fitness_time);
      fprintf(otherfile,"%lf\n",generation_time);        
      fclose(outfile);
      fclose(timefile);
      fclose(otherfile);
      exit(0);
    }
    t++;
    glutSwapBuffers();    
}


void initRT()
{  
  // buffer for storing fitness value of current population
  G_rtFitP = new RenderTexture(P_SIZE_X, P_SIZE_Y);
  G_rtFitP->Initialize(true, false, false, false, false, 32,0,0,0);  

  // buffer for storing fitness value of mutated population
  G_rtFitPnew = new RenderTexture(P_SIZE_X, P_SIZE_Y);
  G_rtFitPnew->Initialize(true, false, false, false, false, 32,0,0,0);  

  // buffer for storing mutated eta
  G_rtPnewn = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtPnewn->Initialize(true, false, false, false, false, 32,32,32,32);  

  // buffer for storing mutated chromosomes
  G_rtPnewx = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtPnewx->Initialize(true, false, false, false, false, 32,32,32,32);  

  // buffer for storing current population of chromosomes, since new generation needs the previous information of chromosome, we
  // prepare two buffers for eta and the actual chromosome value, G_rtPn0 and G_rtPn1 store
  // the eta, while G_rtPx0 and G_rtPx1 store the chromosome values
  G_rtPn0 = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtPn0->Initialize(true, false, false, false, false, 32,32,32,32);  
  G_rtPn1 = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtPn1->Initialize(true, false, false, false, false, 32,32,32,32);  
  G_rtPx0 = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtPx0->Initialize(true, false, false, false, false, 32,32,32,32);  
  G_rtPx1 = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtPx1->Initialize(true, false, false, false, false, 32,32,32,32);  

  G_rtRandomFull[0]  = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtRandomFull[0]->Initialize(true, false, false, false, false, 32,32,32,32);  

  G_rtRandomFull[1]  = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtRandomFull[1]->Initialize(true, false, false, false, false, 32,32,32,32);  

  G_rtRandomFull1[0]  = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtRandomFull1[0]->Initialize(true, false, false, false, false, 32,32,32,32);  

  G_rtRandomFull1[1]  = new RenderTexture(P_SIZE_X*4, P_SIZE_Y*2);
  G_rtRandomFull1[1]->Initialize(true, false, false, false, false, 32,32,32,32);  


  G_rtRandom[0]  = new RenderTexture(P_SIZE_X, P_SIZE_Y);
  G_rtRandom[0]->Initialize(true, false, false, false, false, 32,32,32,32);  

  G_rtRandom[1]  = new RenderTexture(P_SIZE_X, P_SIZE_Y);
  G_rtRandom[1]->Initialize(true, false, false, false, false, 32,32,32,32);  

  G_rtRandom1[0]  = new RenderTexture(P_SIZE_X, P_SIZE_Y);
  G_rtRandom1[0]->Initialize(true, false, false, false, false, 32,32,32,32);  

  G_rtRandom1[1]  = new RenderTexture(P_SIZE_X, P_SIZE_Y);
  G_rtRandom1[1]->Initialize(true, false, false, false, false, 32,32,32,32);  



  printf("finished [initRT]\n");
}


//
//  initGL
//
//  openGL initialization, it will initiaze the openGL window, and also respond for malloc the openGL texture variable
//
//  INPUT
//    argc,argv : unmodified program argument from main
//  OUTPUT
//
//  REFER
//    G_texPx,G_texPn
//
void initGL(int argc, char* argv[])
{
  int err; // glew error handler
  glutInit(&argc,argv);
  glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGBA);
  
  //glutInitWindowSize(P_SIZE_X,P_SIZE_Y);
  glutInitWindowSize(P_SIZE_X*4,P_SIZE_Y*2);
  //glutInitWindowSize(500,500);
  glutInitWindowPosition(10,10);
  G_nGLmain = glutCreateWindow("EP GPU");
  glutDisplayFunc(display);

  err = glewInit();
  if (GLEW_OK != err)
  {
    printf("%s\n",glewGetErrorString(err));
    ErrExit("<InitOpenGLExetension>: initalization error");
  } 
  glGenTextures(1, &G_texPx);  //generate the G_texPx texture for encode the G_fpPx
  glGenTextures(1, &G_texPn);
  glGenTextures(1, &G_texTemp);  
  glGenTextures(1, &G_texTemp32);  
  printf("finished [initGL]\n");
  return;
}



void hrd_idle(void)
{
    glutPostRedisplay();
}



//
// main function
//
int main(int argc, char *argv[])
{
  int select;

  // argument setting
  // argument 1: filename storing each round's minimum fitness value
  // argument 2: filename storing each round's cumulative running time
  // argument 3: filename storing other's statistic such as mutation time, fitness evaluation time
  // argument 4: width of "population"
  // argument 5: height of "population"; i.e. whole population size = argument 4 * argument 5
  // argument 6: the maximum number of generation runs
  // argument 7: selection of software or hardware implementation of EP, 
  //             0 for software implementation and 1 for hardware implementation
  // agrument 8: a switch to turn on/off GPU generate random number, 0 for using software random
  //             1 for using GPU random

  if (argc != 9)
  {
    printf("<usage> %s <outValue.txt> < outTime.txt> <otherInfo.txt> <P_SIZE_X> <P_SIZE_Y> <G_nTmax> <soft (0) or hard(1)> <GPU_RANDOM random>",argv[0]);
    exit(-1);
  }

  sprintf(outValueName,argv[1]); 
  sprintf(outTimeName,argv[2]);
  sprintf(outOtherName,argv[3]);
  P_SIZE_X  = atoi(argv[4]);
  P_SIZE_Y  = atoi(argv[5]);
  G_nTmax   = atoi(argv[6]); 
  select    = atoi(argv[7]);
  GPU_RANDOM       = atoi(argv[8]);


  

  init();
  outfile   = fopen(outValueName,"a");
  timefile  = fopen(outTimeName,"a");
  otherfile = fopen(outOtherName,"a");


  if (select == 0)
  {
    // Software implementation
    SoftwareLoop();
  }
  else 
  {
    // Hardware Implemetation
    initGL(argc,argv);
    loadShader();
    initRT();
    glutIdleFunc(hrd_idle);    
    glutMainLoop();
  }
  // printf("press any key exit\n");
  // getchar(); 
  
  return 0;
}