
//
// util.cpp
//
// an utility function contains most frequently used function
//

//
// LICENCE AGREEMENT:
// 
// This agreement also includes all clauses in LICENCE.txt
//
// Copyright (c) 2005, The Chinese University of Hong Kong
//
// If you publish work based on this software (binary or source code) 
// or its derivative, you agree to cite the following references in your
// publication:
//
//   Ka-Ling Fok, Tien-Tsin Wong and Man-Leung Wong, Evolutionary Computing on 
//   Consumer-Level Graphics Hardware, IEEE Intelligent Systems, to appear.
//   (http://www.cse.cuhk.edu.hk/~ttwong/download/papers/ecgpu/ecgpu.html)
// 
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted for commercial and non-commercial 
// research and academic use, provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice and
// the file LICENCE.txt, this list of conditions and the following disclaimer.
// Each individual file must retain its own copyright notice.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, 
// this list of conditions, the following disclaimer and the list of contributors 
// in the documentation and/or other materials provided with the distribution.
//
// 3. Modification of the program or portion of it is allowed provided that the 
// modified files carry prominent notices stating where and when they have been 
// changed. 
//
#ifdef WIN32
  #include <windows.h>
  #include <float.h>
  #include <sys/timeb.h>
#else
  #include <sys/resource.h>
  #include <sys/times.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>  
#include <GL/glut.h>
#include <GL/gl.h>
#include <cg/cgGL.h>
#include <cg/cg.h> 
#include "util.h"
#include <math.h>

//
// ErrExit
//
// called when there is any error found, it will display the reason of error and then quit the program
//
void ErrExit(char *reason)
{
  fprintf(stderr,"%s\n",reason);
  exit(-1);
}




//
// ShaderDrawQuad
//
// Draw a rectangular quad to make it possible for use of shader
//
// INPUT:
//   width: the width of the rectangular quad which needed to render
//   height: the height of the rectangular quad which needed to render
//
void shaderDrawQuad(int width, int height)
{
  glBegin(GL_QUADS);    
    glTexCoord2f(0,height);    
    glVertex2f(-1,1);
    glTexCoord2f(width,height);
    glVertex2f(1,1);
    glTexCoord2f(width,0);
    glVertex2f(1,-1);
    glTexCoord2f(0,0);
    glVertex2f(-1,-1);
  glEnd();
  glFlush();
};


//
// shader_set_tex_para
//
// set the texture parameter nature, i.e. nearest neightbour fetching and clamp to edge
//
void shader_set_tex_para(void)
{
  glTexParameterf(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameterf(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameterf(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameterf(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
};



//
// myTime
//
// get the system time
//
// OUTPUT:
//   a double variable containing the system time
//
double myTime()
{
#ifdef WIN32
  struct _timeb timebuffer;
  _ftime( &timebuffer );
  return (timebuffer.time + timebuffer.millitm * 0.001);
#else
  struct rusage t;
  double procTime;
  getrusage(0,&t);
  procTime = t.ru_utime.tv_sec + t.ru_stime.tv_sec;
  procTime += (t.ru_utime.tv_usec + t.ru_stime.tv_usec) * 1e-6;
  return procTime;
#endif
}





//
// uni_rand
//
// generate a uniformly distributed random number that within -Range <--> Range
//
// INPUT:  
//   range: the range that the random variable required
// OUTPUT:
//   a uniform random variable that is within -Range <--> Range
//
float uni_rand(float range)
{
  float result;
  result = rand() / (float) RAND_MAX; //0 - 1
  result = (float) (result  - 0.5) * 2; // -1 -1
  result = result * range;  // - range - range
  return result;
}



