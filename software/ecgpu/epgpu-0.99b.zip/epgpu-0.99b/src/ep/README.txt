
		EPGPU (Evolutionary Programming on GPU) v0.99b
		==============================================
				10 October 2005


This is the EPGPU package. If there is any problem or
question, please email me at ttwong@acm.org

This package contains the C++ implementation of the "Evolutionary Programming 
on GPU"


HOW TO INSTALL 
==============


MS Windows
----------
You are assumed to be equipped with Visual C++ 6.0 or above. For other
compiler, you may need to create the project file yourself.

- Start the file "ecgpu.dsw"
- Click on the menu bar
  Build -> Batch Build
- Make sure all configurations have been "ticked". Press "Rebuild All"
  button to build all.


HOW TO USE
==========

Usage:

  ep <outValue.txt> < outTime.txt> <otherInfo.txt> <P_SIZE_X> <P_SIZE_Y> <G_nTmax> <soft (0) or hard(1)> <GPU_RANDOM random>

  argument setting
  argument 1: file storing each round's minimum fitness value
  argument 2: file storing each round's cumulative running time
  argument 3: file storing other's statistic such as mutation time, 
              fitness evaluation time
  argument 4: width of "population"
  argument 5: height of "population"; i.e. whole population size 
              = argument 4 * argument 5
  argument 6: the maximum number of generation runs
  argument 7: selection of software or hardware implementation of EP, 
              0 for software implementation and 
              1 for hardware implementation
  agrument 8: turn on/off GPU random number generator, 
              0 for using software random number generator  (more accurate)
              1 for using GPU random number generator       (less accurate)

The program will optimize a pre-set function using EP, and the fitness, 
running time, and other statistic files will be stored. 

The current program will pop up a window during evolution to visualize the 
convergence. You will see 8 tiles on the window. When the population 
converges, a checker box pattern will appear indicating that the solution 
found is very near to the optimal.

Example usage:

  ep  value.txt time.txt other.txt 50 50 2000 1 0

meaning a 50x50 population iterating for 2000 generations with GPU 
acceleration and software random number generator. The statistics will be 
stored in values.txt, times.txt, and other.txt.



ASSUMPTIONS
===========

Each chromosome contains 32 genes. This can be easily extended to other 
length. Please read our official paper listed in LICENCE.txt to see how that 
can be done.

The optimization functions we demonstrated are minimization functions
and having the optimal values of zeros. Obviously they can be trivially 
modified to other optimization functions. The checker-board visualization 
may need slight modification because the visualization makes use of the 
property of zero optimal value for displaying the B/W checkerboard. 




TO CHANGE THE OPTIMZATION FUNCTION
==================================
You can switch between 2 objective functions, F1 to F5, in the code. 
The default is F1. You can activate one of the functions by defining, e.g.

#define F3

If you design your own, you need to modify the Cg code to implement yours.
Learn shader programming and modify the files "f1.cg" or "f2.cg" to suit
your purpose.



Tien-Tsin Wong
ttwong@acm.org
