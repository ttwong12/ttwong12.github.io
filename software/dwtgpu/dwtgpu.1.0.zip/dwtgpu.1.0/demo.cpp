// Sample Test Program of CDWTObj Class
/*
 *
 * Copyright (c) 2004-2006  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Jianqing Wang, Tien-Tsin Wong, Pheng-Ann Heng, Chi-Sing Leung,
 *    and Liang Wan
 *
 * All rights reserved.
 *
 * References:
 *    Tien-Tsin Wong, Chi-Sing Leung, Pheng-Ann Heng, and Jianqing Wang, 
 *    "Discrete Wavelet Transform on Consumer-Level Graphics Hardware,"
 *    IEEE Transaction on Multimedia, Vol. 9, No. 3, April 2007, pp. 668-673.
 *
 *
*/

/*
 * Permission is hereby granted, free of charge, to any person (the
 * "User") obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 *
 * 1.  If User publishes work based on the Software or its derivative, User
 * agrees to cite the following reference in the publication:
 *
 *     Tien-Tsin Wong, Chi-Sing Leung, Pheng-Ann Heng, and Jianqing Wang, 
 *     "Discrete Wavelet Transform on Consumer-Level Graphics Hardware,"
 *     IEEE Transaction on Multimedia, Vol. 9, No. 3, April 2007, pp. 668-673.
 *     (http://www.cse.cuhk.edu.hk/~ttwong/papers/dwtgpu/dwtgpu.html)
 *
 * 2.  The above copyright notices and this permission notice (which
 * includes the disclaimer below) shall be included in all copies or
 * substantial portions of the Software.
 *
 * 3.  The name of a copyright holder shall not be used to endorse or
 * promote products derived from the Software without specific prior
 * written permission.
 *
 * 4.  The Software is free for both non-commercial and commercial usages.
 * Only the commercial usage requires online registration through the 
 * following webpage:
 *
 * http://www.cse.cuhk.edu.hk/~ttwong/software/dwtgpu/dwtgpu.html 
 * 
 *
 * THIS DISCLAIMER OF WARRANTY CONSTITUTES AN ESSENTIAL PART OF THIS
 * LICENSE.  NO USE OF THE SOFTWARE IS AUTHORIZED HEREUNDER EXCEPT UNDER
 * THIS DISCLAIMER.  THE SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.  IN NO
 * EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL
 * INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING
 * FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
 * WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.  NO ASSURANCES ARE
 * PROVIDED BY THE COPYRIGHT HOLDERS THAT THE SOFTWARE DOES NOT INFRINGE
 * THE PATENT OR OTHER INTELLECTUAL PROPERTY RIGHTS OF ANY OTHER ENTITY.
 * EACH COPYRIGHT HOLDER DISCLAIMS ANY LIABILITY TO THE USER FOR CLAIMS
 * BROUGHT BY ANY OTHER ENTITY BASED ON INFRINGEMENT OF INTELLECTUAL
 * PROPERTY RIGHTS OR OTHERWISE.  AS A CONDITION TO EXERCISING THE RIGHTS
 * GRANTED HEREUNDER, EACH USER HEREBY ASSUMES SOLE RESPONSIBILITY TO SECURE
 * ANY OTHER INTELLECTUAL PROPERTY RIGHTS NEEDED, IF ANY.  THE SOFTWARE
 * IS NOT FAULT-TOLERANT AND IS NOT INTENDED FOR USE IN MISSION-CRITICAL
 * SYSTEMS, SUCH AS THOSE USED IN THE OPERATION OF NUCLEAR FACILITIES,
 * AIRCRAFT NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL
 * SYSTEMS, DIRECT LIFE SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH
 * THE FAILURE OF THE SOFTWARE OR SYSTEM COULD LEAD DIRECTLY TO DEATH,
 * PERSONAL INJURY, OR SEVERE PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH
 * RISK ACTIVITIES").  THE COPYRIGHT HOLDERS SPECIFICALLY DISCLAIM ANY
 * EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR HIGH RISK ACTIVITIES.
 * 
 * Credit:
 * This C++ class uses GLEW for OpenGL Extensions.
 */




#include "DwtObj.h"

#include <GL/glut.h>
#include <cg/cgGL.h>
#include <assert.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>





#define CLOCKS_PER_SEC 1000


BITMAPINFO *TexInfo;
GLubyte    *TexBits;


int  imgwidth=1024, imgheight=256;


float * imgbuffer;


GLubyte *LoadBmp(const char *filename, BITMAPINFO **bmpinfo)
{
	FILE* file;
	
	if((file=fopen(filename,"rb"))==NULL)
	{
		printf("\n can't open file %s",filename);
		exit(1);
	}

	BITMAPFILEHEADER bmpheader;
	fread(&bmpheader,sizeof(BITMAPFILEHEADER),1,file);
	
	if(bmpheader.bfType!='MB')
	{
		printf("\n %s is not a bmp file",filename);
		exit(1);
	}

	*bmpinfo=(BITMAPINFO*)malloc(sizeof(BITMAPINFO));

	assert(*bmpinfo!=NULL);

	
	int readsize=fread((*bmpinfo), 1, bmpheader.bfOffBits-sizeof(BITMAPFILEHEADER) , file);

	
	int bufsize=((*bmpinfo)->bmiHeader.biWidth)*((((*bmpinfo)->bmiHeader.biBitCount)+7)/8)*((*bmpinfo)->bmiHeader.biHeight);
		
	GLubyte * imgbits=(GLubyte*) malloc(bufsize);
	
	assert(imgbits!=NULL);

	fread(imgbits,1,bufsize,file); 


	GLubyte * pbits=imgbits;
	GLubyte temp;
	for (int j=0; j<(*bmpinfo)->bmiHeader.biHeight; j++)
	{
		for(int i=0; i<(*bmpinfo)->bmiHeader.biWidth; i++)
		{
			temp=pbits[0];
			pbits[0]=pbits[2];
			pbits[2]=temp;

			pbits+=3;
		}

	}
	

	fclose(file);
	return imgbits;
	
}


void LoadInitTexture(char * filename)
{

		TexBits=LoadBmp(filename, &TexInfo);

		imgwidth=TexInfo->bmiHeader.biWidth;
		imgheight=TexInfo->bmiHeader.biHeight;
		
};


void Reshape(int w, int h)
{
  if (h == 0) h = 1;
  
  glViewport(0, 0, w, h);
  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(0.0f,1.0f,0.0f,1.0f);


}


void Display()
{
  
  // Render the result buffer
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glColor3f(1, 1, 1);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();

  glRasterPos2f(0,0);
  glDrawPixels(imgwidth,imgheight,GL_RGB,GL_FLOAT,imgbuffer);
  
   
  
  
  glutSwapBuffers();
}


void main()
{
	
  clock_t tmptime=0;


  // load the image and get relevant info
  LoadInitTexture("test.bmp");


  // initialize and create opengl window
  glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
  glutInitWindowPosition(50, 50);
  glutInitWindowSize(imgwidth, imgheight);
  glutCreateWindow("DWT on GPU using Cg"); 


  glutDisplayFunc(Display);
  glutReshapeFunc(Reshape);
  
  
  glMatrixMode(GL_MODELVIEW);
  glDisable(GL_LIGHTING);
  glEnable(GL_COLOR_MATERIAL);
  glDisable(GL_DEPTH_TEST); 
  glClearColor(0.4, 0.6, 0.8, 1);


  //setting  byte alignment for pixel transfer
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glPixelStorei(GL_PACK_ALIGNMENT, 1);


  // allocate the image buffer and normalize the image values

  imgbuffer=(float*)malloc(imgwidth*imgheight*3*sizeof(float));

  for(int i=0; i<imgwidth*imgheight*3; i++)
  {
	  imgbuffer[i]=TexBits[i]/255.0f;
  }



  //  DWT Sample 1

   tmptime=clock();

   //create the gpudwt obj
  CDwtObj *mydwtobj=new CDwtObj;
  
  // do initialization and input the image buffer
  mydwtobj->initialize(symper,imgwidth,imgheight,imgbuffer,false,true);

  // do DWT level 0
  mydwtobj->forwarddwt(0);

  // do DWT level 1
  mydwtobj->forwarddwt(1);

  //mydwtobj->forwarddwt(2);
  //mydwtobj->forwarddwt(3);
  //mydwtobj->inversedwt(3);
  //mydwtobj->inversedwt(2);
  //mydwtobj->inversedwt(1);
  //mydwtobj->inversedwt(0);

  
  //retrieve the transformed buffer back
  mydwtobj->getbuffer(imgbuffer);

  tmptime=clock()-tmptime;
  
  printf("totaldwt:      %d.%.3d s\n", tmptime/CLOCKS_PER_SEC, (tmptime%CLOCKS_PER_SEC)*1000/CLOCKS_PER_SEC);

  
  //destory the gpudwt obj;
  delete mydwtobj;

 
  glutMainLoop();  

  free(imgbuffer);
}
