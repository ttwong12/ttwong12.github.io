// DwtObj.h: definition of the CDwtObj class.
//////////////////////////////////////////////////////////////////////
/*
 * DWT-GPU License Version 1.0
 *
 * Copyright (c) 2004-2006  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Jianqing Wang, Tien-Tsin Wong, Pheng-Ann Heng, Chi-Sing Leung,
 *    and Liang Wan
 *
 * All rights reserved.
 *
 * References:
 *    Tien-Tsin Wong, Chi-Sing Leung, Pheng-Ann Heng, and Jianqing Wang, 
 *    "Discrete Wavelet Transform on Consumer-Level Graphics Hardware,"
 *    IEEE Transaction on Multimedia, Vol. 9, No. 3, April 2007, pp. 668-673.
 *
 * Modification History:
 * From 0.9a to 0.9b:  (by Tien-Tsin Wong)
 * - Make "dwtsource" and "dwtcolsource" consistent with published paper
 * - Make "invdwtsource" and "invdwtcolsource" consistent with published paper
 * - Simplify the creation of indirect address table for inverse DWT (createIDATexture)
 * - Make the code more neat and tidy
 *
 * From 0.9c to 1.0:  (by Liang Wan)
 * - Provide Frame Buffer Objects (FBO) as an alternative for RenderTexture
 * - Use the latest fragment profile available on the GPU
 *
*/

/*
 * Permission is hereby granted, free of charge, to any person (the
 * "User") obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 *
 * 1.  If User publishes work based on the Software or its derivative, User
 * agrees to cite the following reference in the publication:
 *
 *     Tien-Tsin Wong, Chi-Sing Leung, Pheng-Ann Heng, and Jianqing Wang, 
 *     "Discrete Wavelet Transform on Consumer-Level Graphics Hardware,"
 *     IEEE Transaction on Multimedia, Vol. 9, No. 3, April 2007, pp. 668-673.
 *     (http://www.cse.cuhk.edu.hk/~ttwong/papers/dwtgpu/dwtgpu.html)
 *
 * 2.  The above copyright notices and this permission notice (which
 * includes the disclaimer below) shall be included in all copies or
 * substantial portions of the Software.
 *
 * 3.  The name of a copyright holder shall not be used to endorse or
 * promote products derived from the Software without specific prior
 * written permission.
 *
 * 4.  The Software is free for both non-commercial and commercial usages.
 * Only the commercial usage requires online registration through the 
 * following webpage:
 *
 * http://www.cse.cuhk.edu.hk/~ttwong/software/dwtgpu/dwtgpu.html 
 *
 *
 * THIS DISCLAIMER OF WARRANTY CONSTITUTES AN ESSENTIAL PART OF THIS
 * LICENSE.  NO USE OF THE SOFTWARE IS AUTHORIZED HEREUNDER EXCEPT UNDER
 * THIS DISCLAIMER.  THE SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.  IN NO
 * EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL
 * INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING
 * FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
 * WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.  NO ASSURANCES ARE
 * PROVIDED BY THE COPYRIGHT HOLDERS THAT THE SOFTWARE DOES NOT INFRINGE
 * THE PATENT OR OTHER INTELLECTUAL PROPERTY RIGHTS OF ANY OTHER ENTITY.
 * EACH COPYRIGHT HOLDER DISCLAIMS ANY LIABILITY TO THE USER FOR CLAIMS
 * BROUGHT BY ANY OTHER ENTITY BASED ON INFRINGEMENT OF INTELLECTUAL
 * PROPERTY RIGHTS OR OTHERWISE.  AS A CONDITION TO EXERCISING THE RIGHTS
 * GRANTED HEREUNDER, EACH USER HEREBY ASSUMES SOLE RESPONSIBILITY TO SECURE
 * ANY OTHER INTELLECTUAL PROPERTY RIGHTS NEEDED, IF ANY.  THE SOFTWARE
 * IS NOT FAULT-TOLERANT AND IS NOT INTENDED FOR USE IN MISSION-CRITICAL
 * SYSTEMS, SUCH AS THOSE USED IN THE OPERATION OF NUCLEAR FACILITIES,
 * AIRCRAFT NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL
 * SYSTEMS, DIRECT LIFE SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH

  * THE FAILURE OF THE SOFTWARE OR SYSTEM COULD LEAD DIRECTLY TO DEATH,
 * PERSONAL INJURY, OR SEVERE PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH
 * RISK ACTIVITIES").  THE COPYRIGHT HOLDERS SPECIFICALLY DISCLAIM ANY
 * EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR HIGH RISK ACTIVITIES.
 * 
 * Credit:
 * This C++ class uses GLEW for OpenGL Extensions.
 */


#if !defined(_DWTOBJ_H)
#define _DWTOBJ_H

#include "RenderTexture.h"
#include <GL/glut.h>
#include <cg/cg.h>
#include <cg/cgGL.h>


// boundary extension modes
enum extmode {
  per,
  symper
};

// dwt modes
enum dwtmode {
  forward,
  inverse,
  both
};	


class CDwtObj  
{

public:

  ////////////// The overloaded functions for general usage without JPEG2000 indices ////////////

  // one-stop dwt transform, suitable for tasks that only do forward or inverse dwt once
  // detail information about the parameters please see inside the cpp file
  bool dwtallinone(extmode mode, int imagewidth, int imageheight, float*  imagebuffer, int level, bool isforward, bool initGL, bool initGLEW);
  bool dwtallinone(extmode mode, int imagewidth, int imageheight, float*  imagebuffer, int beg_level, int end_level, bool isforward, bool initGL, bool initGLEW);

  // initialize and feed in the buffer, both forward and inverse dwt functions are available for call after return
  bool initialize(extmode mode, int imagewidth, int imageheight, float*  imagebuffer, bool initGL, bool initGLEW);

  // the forward and inverse dwt function
  bool forwarddwt(int level);
  bool inversedwt(int level);


  //////////////////  Functions for JPEG2000 Wavelet Transform ////////////////////

  // one-stop dwt transform, suitable for tasks that only do forward or inverse dwt once
  // detail information about the parameters please see inside the cpp file
  bool dwtallinone(extmode mode, int imagewidth, int imageheight, float*  imagebuffer, int level, bool isforward, bool initGL, bool initGLEW, int startx, int starty,int endx,int endy);
  bool dwtallinone(extmode mode, int imagewidth, int imageheight, float*  imagebuffer, int beg_level, int end_level, bool isforward, bool initGL, bool initGLEW, int startx, int starty,int endx,int endy);

  // initialize and feed in the buffer, both forward and inverse dwt functions are available for call after return
  bool initialize(extmode mode, int imagewidth, int imageheight, float*  imagebuffer, bool initGL, bool initGLEW, int startx, int starty, int endx,int endy);

  // the forward and inverse dwt function
  bool forwarddwt(int level,int startx, int starty, int endx,int endy);
  bool inversedwt(int level,int startx, int starty, int endx,int endy);

  // retrieve the transformed buffer back
  void getbuffer(float *myfloatbuffer);	
	
  CDwtObj();
  virtual ~CDwtObj();	

	
private:

  // Create the  Ext,HL,BasePos Lookup Texture 
  bool createLookupTex(extmode mode,int startx, int starty, int endx, int endy);
	
  // Create the  Ext,HL,BasePos Lookup Texture for inverse dwt
  bool createInvLookupTex(extmode mode,int startx, int starty, int endx, int endy);

  // create the high/low pass filter texture
  bool createFilterTex(dwtmode mode);

  // initialize Cg and Cg Shaders
  bool Init_Cg(dwtmode mode);

  // initialize the frame buffer objects
  bool initFBO(int BPP);

  // initialize the render texture objects
  bool CDwtObj::initRenderTexture(int BPP);
	
  // set image dimension variables
  bool setImageDimensions(int width, int height);
	
  // render input image data to texture
  bool createImgTex( float *imgbuffer);	

  // initilize opengl and glew
  bool initOpenGL();
  bool initglew();

  // delete textures
  bool finalcleanup();

  // boundary extension function
  int ext(int index, int datalen, extmode mode);

  // calculate total levels using the JPEG2000 start and end indices
  int calLevels(int startind, int endind);

  // calculate the downsampling length and sampling offset for lowpassed part
  void calLength(int startind, int endind, int level, int * llength, int * loffset);

  // create the indirect addressing table for the inverse DWT
  bool createIDATexture(extmode mode,float ** itex1, int width, int height, int &texwidth, int &texheight, int startx, int starty, int endx,int endy);
	

private:
  // Cg Programs
  CGprogram m_invdwtcolProg;
  CGprogram m_invdwtrowProg;
  CGprogram m_dwtcolProg;
  CGprogram m_dwtrowProg;
  CGprogram m_fillProg;

  // Cg Parameters
  CGparameter m_dwtrow_lookup_Param, m_dwtrow_imageTex_Param,m_dwtrow_filterTex_Param,m_dwtrow_level_Param;
  CGparameter m_dwtcol_lookup_Param, m_dwtcol_imageTex_Param,m_dwtcol_filterTex_Param,m_dwtcol_level_Param;

  CGparameter m_invdwtrow_lookup_Param, m_invdwtrow_imageTex_Param,m_invdwtrow_filterTex_Param,m_invdwtrow_level_Param;
  CGparameter m_invdwtcol_lookup_Param, m_invdwtcol_imageTex_Param,m_invdwtcol_filterTex_Param,m_invdwtcol_level_Param,m_invdwtcol_texwidth_Param,m_invdwtcol_texheight_Param;

  CGparameter m_fill_Tex_Param;

  // Texture IDs
  GLuint m_colLookupTexID;
  GLuint m_rowLookupTexID;
  GLuint m_LookupTexID;
  GLuint m_imageTexID;
  GLuint m_reconFilterTexID;
  GLuint m_decomFilterTexID;

  // lookuptex dimension
  int m_ida_texwidth;
  int m_ida_texheight;

  // Image Dimensions
  int m_imageHeight;
  int m_imageWidth;

  // the current operation buffer
  int m_iReadBuffer;

  // Cg profile  
  CGprofile m_fpProfile;

  // FBO objects
  GLuint m_fbo;
  GLuint m_fbort[2];

  // RenderTexture Objects
  RenderTexture * m_rt[2];

  // Use FBO if there is, otherwise use RenderTexture
  bool m_busefbo;
};



#endif // !defined(_DWTOBJ_H)

