
//  The jasper library addon header file ( for data conversion)
//////////////////////////////////////////////////////////////////////

/*
 * DWT-GPU License Version 0.9a
 *
 * Copyright (c) 2004  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Jianqing Wang, Tien-Tsin Wong, Pheng-Ann Heng, Chi-Sing Leung
 *
 * All rights reserved.
*/

/*
 * Permission is hereby granted, free of charge, to any person (the
 * "User") obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 *
 * 1.  The above copyright notices and this permission notice (which
 * includes the disclaimer below) shall be included in all copies or
 * substantial portions of the Software.
 *
 * 2.  The name of a copyright holder shall not be used to endorse or
 * promote products derived from the Software without specific prior
 * written permission.
 *
 * 3.  The Software is free for both non-commercial and commercial usages.
 * Only the commercial usage requires online registration through the 
 * following webpage:
 *
 * http://www.cse.cuhk.edu.hk/~ttwong/software/dwtgpu/dwtgpu.html 
 * 
 *
 * THIS DISCLAIMER OF WARRANTY CONSTITUTES AN ESSENTIAL PART OF THIS
 * LICENSE.  NO USE OF THE SOFTWARE IS AUTHORIZED HEREUNDER EXCEPT UNDER
 * THIS DISCLAIMER.  THE SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.  IN NO
 * EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL
 * INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING
 * FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
 * WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.  NO ASSURANCES ARE
 * PROVIDED BY THE COPYRIGHT HOLDERS THAT THE SOFTWARE DOES NOT INFRINGE
 * THE PATENT OR OTHER INTELLECTUAL PROPERTY RIGHTS OF ANY OTHER ENTITY.
 * EACH COPYRIGHT HOLDER DISCLAIMS ANY LIABILITY TO THE USER FOR CLAIMS
 * BROUGHT BY ANY OTHER ENTITY BASED ON INFRINGEMENT OF INTELLECTUAL
 * PROPERTY RIGHTS OR OTHERWISE.  AS A CONDITION TO EXERCISING THE RIGHTS
 * GRANTED HEREUNDER, EACH USER HEREBY ASSUMES SOLE RESPONSIBILITY TO SECURE
 * ANY OTHER INTELLECTUAL PROPERTY RIGHTS NEEDED, IF ANY.  THE SOFTWARE
 * IS NOT FAULT-TOLERANT AND IS NOT INTENDED FOR USE IN MISSION-CRITICAL
 * SYSTEMS, SUCH AS THOSE USED IN THE OPERATION OF NUCLEAR FACILITIES,
 * AIRCRAFT NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL
 * SYSTEMS, DIRECT LIFE SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH
 * THE FAILURE OF THE SOFTWARE OR SYSTEM COULD LEAD DIRECTLY TO DEATH,
 * PERSONAL INJURY, OR SEVERE PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH
 * RISK ACTIVITIES").  THE COPYRIGHT HOLDERS SPECIFICALLY DISCLAIM ANY
 * EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR HIGH RISK ACTIVITIES.
 * 
 * Credit:
 * This C++ class incoporates the RenderTexture class from Mark. J. Harris.
 * This C++ class uses GLEW for OpenGL Extensions.
 */


/*
 * Copyright (c) 1999-2000 Image Power, Inc. and the University of
 *   British Columbia.
 * Copyright (c) 2001-2003 Michael David Adams.
 * All rights reserved.
 */

/* __START_OF_JASPER_LICENSE__
 * 
 * JasPer License Version 2.0
 * 
 * Copyright (c) 1999-2000 Image Power, Inc.
 * Copyright (c) 1999-2000 The University of British Columbia
 * Copyright (c) 2001-2003 Michael David Adams
 * 
 * All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person (the
 * "User") obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 * 
 * 1.  The above copyright notices and this permission notice (which
 * includes the disclaimer below) shall be included in all copies or
 * substantial portions of the Software.
 * 
 * 2.  The name of a copyright holder shall not be used to endorse or
 * promote products derived from the Software without specific prior
 * written permission.
 * 
 * THIS DISCLAIMER OF WARRANTY CONSTITUTES AN ESSENTIAL PART OF THIS
 * LICENSE.  NO USE OF THE SOFTWARE IS AUTHORIZED HEREUNDER EXCEPT UNDER
 * THIS DISCLAIMER.  THE SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.  IN NO
 * EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL
 * INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING
 * FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
 * WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.  NO ASSURANCES ARE
 * PROVIDED BY THE COPYRIGHT HOLDERS THAT THE SOFTWARE DOES NOT INFRINGE
 * THE PATENT OR OTHER INTELLECTUAL PROPERTY RIGHTS OF ANY OTHER ENTITY.
 * EACH COPYRIGHT HOLDER DISCLAIMS ANY LIABILITY TO THE USER FOR CLAIMS
 * BROUGHT BY ANY OTHER ENTITY BASED ON INFRINGEMENT OF INTELLECTUAL
 * PROPERTY RIGHTS OR OTHERWISE.  AS A CONDITION TO EXERCISING THE RIGHTS
 * GRANTED HEREUNDER, EACH USER HEREBY ASSUMES SOLE RESPONSIBILITY TO SECURE
 * ANY OTHER INTELLECTUAL PROPERTY RIGHTS NEEDED, IF ANY.  THE SOFTWARE
 * IS NOT FAULT-TOLERANT AND IS NOT INTENDED FOR USE IN MISSION-CRITICAL
 * SYSTEMS, SUCH AS THOSE USED IN THE OPERATION OF NUCLEAR FACILITIES,
 * AIRCRAFT NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL
 * SYSTEMS, DIRECT LIFE SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH
 * THE FAILURE OF THE SOFTWARE OR SYSTEM COULD LEAD DIRECTLY TO DEATH,
 * PERSONAL INJURY, OR SEVERE PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH
 * RISK ACTIVITIES").  THE COPYRIGHT HOLDERS SPECIFICALLY DISCLAIM ANY
 * EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR HIGH RISK ACTIVITIES.
 * 
 * __END_OF_JASPER_LICENSE__
 */



#include <time.h>	


bool	g_bgpumode=true;

int		g_numcomps=3;



/* Convert a fixed-point number to a float. */
#define JAS_FIXTOFLT(fix_t, fracbits, x) \
	(JAS_CAST(float, x) / (JAS_CAST(fix_t, 1) << (fracbits)))

/* Convert a float to a fixed-point number. */
#define JAS_FLTTOFIX(fix_t, fracbits, x) \
	JAS_CAST(fix_t, ((x) * JAS_CAST(float, JAS_CAST(fix_t, 1) << (fracbits))))


#define jpc_fixtoflt(x)	JAS_FIXTOFLT(jpc_fix_t, JPC_FIX_FRACBITS, x)
#define jpc_flttofix(x)	JAS_FLTTOFIX(jpc_fix_t, JPC_FIX_FRACBITS, x)



/* Added by Albert WANG 17/09/03 */

void jpc_combine_cmpts(jas_matrix_t *c0, jas_matrix_t *c1, jas_matrix_t *c2, float ** combined_array,int * width, int * height);
void jpc_update_cmpts(jas_matrix_t *c0, jas_matrix_t *c1, jas_matrix_t *c2, float * combined_array);




/*****************************************************************
** Added by Albert WANG 17/09/03  
** take jpc_rct as reference 
** Combine the 3 components of an image to form a float array 
**
** The output:  combined_arry , no need to be allocated before call
******************************************************************/


void jpc_combine_cmpts(jas_matrix_t *c0, jas_matrix_t *c1, jas_matrix_t *c2, float ** combined_array, int *width,int *height)
{
	int numrows;
	int numcols;
	int i;
	int j;
	jpc_fix_t *c0p;
	jpc_fix_t *c1p;
	jpc_fix_t *c2p;

	float *pfloat;

	numrows =jas_matrix_numrows(c0);
	numcols =jas_matrix_numcols(c0);

	*width=numcols;
	*height=numrows;

	/*allocate the output array */
	*combined_array=(float*)malloc(numrows*numcols*3*sizeof(float));
	pfloat=*combined_array;



	

	for (i =0 ; i<numrows; i++) {

			
		for (j = 0; j< numcols; j++) {

			
			*pfloat++=jpc_fixtoflt(*jas_matrix_getref(c0,i,j));
			
			if(g_numcomps==3)
			{
				*pfloat++=jpc_fixtoflt(*jas_matrix_getref(c1,i,j));
				*pfloat++=jpc_fixtoflt(*jas_matrix_getref(c2,i,j));
			}
			else
			{
				*pfloat++=jpc_fixtoflt(*jas_matrix_getref(c0,i,j));
				*pfloat++=jpc_fixtoflt(*jas_matrix_getref(c0,i,j));
			}
			

		}
	}
}





/*****************************************************************
** Added by Albert WANG 17/09/03  
** take jpc_rct as reference 
**
** Update the 3 components of an image from a float array which contains
** the DWT transformed data
**
** The combined_arry input need to be allocated and filled
** with the DWT transformed data before call this function
******************************************************************/

void jpc_update_cmpts(jas_matrix_t *c0, jas_matrix_t *c1, jas_matrix_t *c2, float * combined_array)
{
	int numrows;
	int numcols;
	int i;
	int j;
	jpc_fix_t *c0p;
	jpc_fix_t *c1p;
	jpc_fix_t *c2p;

	float *pfloat;

	numrows = jas_matrix_numrows(c0);
	numcols = jas_matrix_numcols(c0);

	
	pfloat=combined_array;


	for (i = 0; i<numrows; i++) {

		for (j = 0; j<numcols; j++) {

	
			*jas_matrix_getref(c0,i,j)=jpc_flttofix(*pfloat++);

				if(g_numcomps==3)
				{
					*jas_matrix_getref(c1,i,j)=jpc_flttofix(*pfloat++);
					*jas_matrix_getref(c2,i,j)=jpc_flttofix(*pfloat++);

				}
				else
				{ pfloat+=2;
				}

		}
	}
}