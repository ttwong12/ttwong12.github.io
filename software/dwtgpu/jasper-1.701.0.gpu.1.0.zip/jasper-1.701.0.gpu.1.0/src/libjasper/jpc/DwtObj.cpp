// DwtObj.cpp: implementation of the CDwtObj class.
//////////////////////////////////////////////////////////////////////
/*
 * DWT-GPU License Version 1.0
 *
 * Copyright (c) 2004-2006  The Chinese University of Hong Kong
 *
 * Developed by: 
 *    Jianqing Wang, Tien-Tsin Wong, Pheng-Ann Heng, Chi-Sing Leung,
 *    and Liang Wan
 *
 * All rights reserved.
 *
 * References:
 *    Tien-Tsin Wong, Chi-Sing Leung, Pheng-Ann Heng, and Jianqing Wang, 
 *    "Discrete Wavelet Transform on Consumer-Level Graphics Hardware,"
 *    IEEE Transaction on Multimedia, Vol. 9, No. 3, April 2007, pp. 668-673.
 *
 * Modification History:
 * From 0.9a to 0.9b:  (by Tien-Tsin Wong)
 * - Make "dwtsource" and "dwtcolsource" consistent with published paper
 * - Make "invdwtsource" and "invdwtcolsource" consistent with published paper
 * - Simplify the creation of indirect address table for inverse DWT (createIDATexture)
 * - Make the code more neat and tidy
 *
 * From 0.9c to 1.0:  (by Liang Wan)
 * - Provide Frame Buffer Objects (FBO) as an alternative for RenderTexture
 * - Use the latest fragment profile available on the GPU
 *
*/

/*
 * Permission is hereby granted, free of charge, to any person (the
 * "User") obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 *
 * 1.  If User publishes work based on the Software or its derivative, User
 * agrees to cite the following reference in the publication:
 *
 *     Tien-Tsin Wong, Chi-Sing Leung, Pheng-Ann Heng, and Jianqing Wang, 
 *     "Discrete Wavelet Transform on Consumer-Level Graphics Hardware,"
 *     IEEE Transaction on Multimedia, Vol. 9, No. 3, April 2007, pp. 668-673.
 *     (http://www.cse.cuhk.edu.hk/~ttwong/papers/dwtgpu/dwtgpu.html)
 *
 * 2.  The above copyright notices and this permission notice (which
 * includes the disclaimer below) shall be included in all copies or
 * substantial portions of the Software.
 *
 * 3.  The name of a copyright holder shall not be used to endorse or
 * promote products derived from the Software without specific prior
 * written permission.
 *
 * 4.  The Software is free for both non-commercial and commercial usages.
 * Only the commercial usage requires online registration through the 
 * following webpage:
 *
 * http://www.cse.cuhk.edu.hk/~ttwong/software/dwtgpu/dwtgpu.html 
 * 
 *
 * THIS DISCLAIMER OF WARRANTY CONSTITUTES AN ESSENTIAL PART OF THIS
 * LICENSE.  NO USE OF THE SOFTWARE IS AUTHORIZED HEREUNDER EXCEPT UNDER
 * THIS DISCLAIMER.  THE SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.  IN NO
 * EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL
 * INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING
 * FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
 * WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.  NO ASSURANCES ARE
 * PROVIDED BY THE COPYRIGHT HOLDERS THAT THE SOFTWARE DOES NOT INFRINGE
 * THE PATENT OR OTHER INTELLECTUAL PROPERTY RIGHTS OF ANY OTHER ENTITY.
 * EACH COPYRIGHT HOLDER DISCLAIMS ANY LIABILITY TO THE USER FOR CLAIMS
 * BROUGHT BY ANY OTHER ENTITY BASED ON INFRINGEMENT OF INTELLECTUAL
 * PROPERTY RIGHTS OR OTHERWISE.  AS A CONDITION TO EXERCISING THE RIGHTS
 * GRANTED HEREUNDER, EACH USER HEREBY ASSUMES SOLE RESPONSIBILITY TO SECURE
 * ANY OTHER INTELLECTUAL PROPERTY RIGHTS NEEDED, IF ANY.  THE SOFTWARE
 * IS NOT FAULT-TOLERANT AND IS NOT INTENDED FOR USE IN MISSION-CRITICAL
 * SYSTEMS, SUCH AS THOSE USED IN THE OPERATION OF NUCLEAR FACILITIES,
 * AIRCRAFT NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL
 * SYSTEMS, DIRECT LIFE SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH
 * THE FAILURE OF THE SOFTWARE OR SYSTEM COULD LEAD DIRECTLY TO DEATH,
 * PERSONAL INJURY, OR SEVERE PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH
 * RISK ACTIVITIES").  THE COPYRIGHT HOLDERS SPECIFICALLY DISCLAIM ANY
 * EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR HIGH RISK ACTIVITIES.
 * 
 * Credit:
 * This C++ class uses GLEW for OpenGL Extensions.
 */


#include <math.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <time.h>
#include <GL/glew.h>
#ifdef _WIN32
#include <GL/wglew.h>
#else
#include <GL/glxew.h>
#endif

#define  CHECKSUCC(X)  if(!(X)){return false;};
#define  DELTEXTURES(n,t)  if(glIsTexture((*t))){glDeleteTextures(n,t);};




#include "DwtObj.h"

// Wavelet filters kernel


const float decomp_filter[18] = {	
  0.026749, -0.016864, -0.078223, 0.266864, 0.602949, 0.266864, -0.078223, -0.016864, 0.026749,
  0,  0.045636, -0.028772, -0.29564,  0.55754, -0.29564, -0.028772,  0.045636,        0
};


// The Uninterleaved filter
/*
//const float scal=2.0;
float recon_filter[18]={  0, -0.091272f, -0.057544f, 0.591272f, 1.115087f,
                    0.591272f, -0.057544f, -0.091272f, 0 ,
                    0.026749f*scal, 0.016864f*scal, -0.078223f*scal, -0.266864f*scal,
                    0.602949f*scal, -0.266864f*scal, -0.078223f*scal, 0.016864f*scal, 0.026749f*scal
                    };
*/


// Interleaved reconstruction filter
const float recon_filter[18] = {
  0,  0.033728f, -0.057544f, -0.533728f, 1.115087f,-0.533728f, -0.057544f,  0.033728f, 0, 
  0.053498f, -0.091272f, -0.156446f,  0.591272f, 1.205898f, 0.591272f, -0.156446f, -0.091272f, 0.053498f
};




/* Global cgcontext  */
CGcontext   cgContext;


/**********************************************************************/
/*******     Cg program string					   			 **********/
/**********************************************************************/


/*************  Simple Pass Through  **************************/

char fillsource[]="	fragout_float main(vf30 IN,"
"             uniform samplerRECT texture) \n"
"{"
"  fragout_float OUT;\n"

"  OUT.col =f4texRECT(texture, IN.TEX0.xy); \n"
"  OUT.col.a=1.0; \n"
"  return OUT;	\n"
"} \n";


/********************** dwt horizontal decomposition ************************/
char dwtsource[] = 
"fragout_float main(vf30 IN,"
"                   uniform samplerRECT dwt,	  "
"                   uniform samplerRECT filter,   "
"                   uniform samplerRECT lut,      "
"                   uniform float       level) \n"
"{ \n"
"  float  base, offset, level_center=level+0.5;	\n"
"  float2 neighbor;                             \n"
"  float3 lookup, sum=float3(0,0,0);            \n"

"  // Look up alpha (lut.g) and beta (lut.b)                        \n"
"  lookup     = f3texRECT(lut,float2(IN.TEX0.x+4.0, level_center)); \n"
"  offset     = lookup.g*9.0;  // 0 - low-pass, 1 - high-pass       \n"	
"  base       = lookup.b;   \n"
"  neighbor.y = IN.TEX0.y;  \n" 
	
"  for (int i=0; i<9; i++)	\n"
"  {"
"    // Boundary extension is handled by the indirect addressing with lut.r         \n"
"    neighbor.x = f3texRECT(lut,float2(base+i,level_center)).r;	                    \n"
"    // Convolve corresponding filter values with data from level j                 \n"
"    sum += f3texRECT(filter,float2(i+offset+0.5,0.5)).x * f3texRECT(dwt,neighbor); \n"
"  } \n"

"  fragout_float OUT;          \n"
"  OUT.col = float4(sum, 1.0); \n"
"  return OUT;                 \n"
"}" ;


/********************** dwt vertical decomposition ************************/
char dwtcolsource[] =
"fragout_float main(vf30 IN,"
"                   uniform samplerRECT dwt,     "  
"                   uniform samplerRECT filter,  "
"                   uniform samplerRECT lut,     "
"                   uniform float       level) \n"
"{"
"  float  base, offset, level_center=level+0.5; \n"
"  float2 neighbor;                             \n"
"  float3 lookup, sum=float3(0,0,0);            \n"

"  // Look up alpha (lut.g) and beta (lut.b)    \n"
"  lookup     = f3texRECT(lut,float2(IN.TEX0.y+4.0, level_center)); \n"
"  offset     = lookup.g*9.0;  // 0 - low-pass, 1 - high-pass       \n"
"  base       = lookup.b;     \n"
"  neighbor.x = IN.TEX0.x;    \n"

"  for (int i=0; i<9; i++)                   \n"
"  {"
"    // Boundary extension is handled by the indirect addressing with lut.r         \n"
"    neighbor.y = f3texRECT(lut,float2(base+i,level_center)).r;                     \n"
"    // Convolve corresponding filter values with data from level j                 \n"
"    sum += f3texRECT(filter,float2(i+offset+0.5,0.5)).x * f3texRECT(dwt,neighbor); \n"
"  }"

"  fragout_float OUT;          \n"
"  OUT.col = float4(sum, 1.0); \n"
"  return OUT;                 \n"
"} ";



/********************** idwt horizontal reconstruction ************************/
char invdwtsource[] =
"fragout_float main(vf30 IN,"
"                   uniform samplerRECT dwt,     "
"                   uniform samplerRECT filter,  "
"                   uniform samplerRECT lut,     "
"                   uniform float       level) \n"
"{"
"  float  lookup, level_center=level+0.5; \n"
"  float2 st, filter_st;                  \n"
"  float3 sum=float3(0,0,0);              \n"

"  // Look up filter selector (lut.g)                           \n"
"  lookup    = f4texRECT(lut,float2(IN.TEX0.x,level_center)).g; \n"
"  filter_st = float2(lookup*9.0+0.5,0.5);                      \n"
"  st        = float2(0.0,IN.TEX0.y);                           \n"

"  // Lookup indirect address (lut.r) & filter values (filter.x), then convolve \n"
"  for (int i=0 ; i<9 ; i++)                                           \n"
"  {                                                                   \n"
"    st.x         = f4texRECT(lut,float2(IN.TEX0.x+i,level_center)).r; \n"
"    sum         += f3texRECT(filter,filter_st).x * f3texRECT(dwt,st); \n"
"    filter_st.x += 1.0;	                                           \n"
"  }                                                                   \n"

"  fragout_float OUT;	        \n"
"  OUT.col = float4(sum, 1.0);	\n"
"  return OUT;	                \n"
"}";



/********************** idwt vertical reconstruction ************************/
char invdwtcolsource[]=
"fragout_float main(vf30 IN,"
"                   uniform samplerRECT dwt,      "
"                   uniform samplerRECT filter,   "
"                   uniform samplerRECT lut,      "
"                   uniform float       texwidth, "
"                   uniform float       texheight,"
"                   uniform float       level)  \n"
"{"
"  float  lookup, level_center=level+0.5; \n"
"  float2 st, filter_st;                  \n"
"  float3 sum=float3(0,0,0);              \n"

"  // Look up filter selector (lut.g)                                               \n"
"  lookup    = f4texRECT(lut,float2(texwidth-IN.TEX0.y, texheight-level_center)).g; \n"
"  filter_st = float2(0.0+lookup*9.0+0.5,0.5);                                      \n"
"  st        = float2(IN.TEX0.x,0.0);                                               \n"

"  // Lookup indirect address (lut.r) & filter values (filter.x), then convolve            \n"
"  for (int i=0 ; i<9 ; i++) {                                                             \n"
"    st.y         = f4texRECT(lut,float2(texwidth-IN.TEX0.y-i, texheight-level_center)).r; \n"
"    sum         += f3texRECT(filter,filter_st).x * f3texRECT(dwt,st);                     \n"
"    filter_st.x += 1.0;	                                                           \n"
"  }                                                                                       \n"

"  fragout_float OUT;	        \n"
"  OUT.col = float4(sum, 1.0);	\n"
"  return OUT;	                \n"
"}";




//------------------------------------------------------------------------------
// Function			: CDwtObj::ext()
// Description	    : boundary extension function
//------------------------------------------------------------------------------
// [in] index, datalen -- the item index and the whole data length for boundary extension
// [in] mode --boundary extension mode (symper, per)
//  return value --  the index after perform boundary extension


int CDwtObj::ext(int index, int datalen, extmode mode)
{
  int id = index;
  int eo = datalen % 2;

  // symmetric padding
  switch (mode)
  {
    case symper:

      if (id < 0)
        id = -id;

      if (id >= datalen)
        id = datalen - 1 - (id - datalen + 1);

      return id;
      break;


    //periodic padding

    case per:

      id = (id + datalen + eo) % (datalen + eo);
      //id=(id+datalen)%(datalen);

      if (eo == 0)
        return id;

      else
      {
        if (id != datalen)
          return id;
        else
          return datalen - 1;
      }
      break;

    default:
      id = (id + datalen) % datalen;
      return id;
      break;
  }
}



//------------------------------------------------------------------------------
// Function         : CDwtObj::calLevels()
// Description      : calculate maximum levels
//------------------------------------------------------------------------------
// [in] startind, endind -- start index and end index in JPEG2000 tiling
//  return value --  total levels

int CDwtObj::calLevels(int startind, int endind)
{
  int level, lstart, lend;

  lstart = startind;
  lend   = endind;
  level  = 1;

  while (lend - lstart > 1)
  {
    lstart = ceil(lstart / 2.0f);
    lend = ceil(lend / 2.0f);
    level++;
  }
  return level;

}



//------------------------------------------------------------------------------
// Function         : CDwtObj::calLength()
// Description      : calculate the downsampling length and sampling offset for lowpassed part
//------------------------------------------------------------------------------
// [in] startind, endind, level -- start index and end index, and the desired level in JPEG2000 tiling
// [out]  llenghth , loffset -- downsampling length and sampling offset for lowpassed part

void CDwtObj::calLength(int startind, int endind, int level, int *llength, int *loffset)
{

  int hstart, lstart, hend, lend, i;

  lstart = startind;
  lend   = endind;
  hstart = startind;
  hend   = endind;

  for (i = 0; i < level; i++)
  {
    hstart = floor(lstart / 2.0f);
    hend   = floor(lend   / 2.0f);
    lstart = ceil (lstart / 2.0f);
    lend   = ceil (lend   / 2.0f);
  }

  // low-passed signal length
  *llength = lend - lstart;

  // controls the downsampling, i.e, the even/oddness of the filtered samples to be taken for lowpassed-part
  if (hstart < lstart)
    *loffset = 1;
  else
    *loffset = 0;
}




//------------------------------------------------------------------------------
// Function			: CDwtObj::createIDATexture()
// Description	    : create the indirect addressing table for inverse DWT
//------------------------------------------------------------------------------
// [out]  itex1, -- the texture for holding the indirect addressing table
//		 -- memory allocation is done inside the function, user is responsible to free the memory using delete[]
// [in]  width, height   -- the width and height of the image (not for the indirect addressing table)
// [in]  startx, endx, starty, endy -- the indices of x and y direction
// [out] texwidth, texheight --  the dimensions of the indirect addressing table texture
// 
// Modification history:
//
// 1 June 2005  (By Tien-Tsin Wong) 
// -  Remove the 9D indirect address tables (tex1, tex2, tex3) and combine them into 
//    1 indirect address table. Because they are redundant.
// -  Due to the removal of 9D table, the computation of indirect addresses can be reduced by 9 folds
//
bool CDwtObj::createIDATexture(extmode mode, float **itex1, int width, int height,
                               int &texwidth, int &texheight, int startx, int starty, int endx, int endy)
{
  if (width < 1 || height < 1)
    return false;

  int i, j, k;
  int levellength, halflength, loffset;
  int L = width > height ? width : height;
  int xlevels = calLevels(startx, endx) + 1;
  int ylevels = calLevels(starty, endy) + 1;
  int maxlevels = xlevels > ylevels ? xlevels : ylevels;    //maximum number of decomposition levels for this image

  texwidth = L + 1 + 8 + 8;     // the (8 + 8) is due to boundary extension
  texheight = maxlevels;

  // lookup table holding indices for indirect addressing
  float   (*tex1)[4] = new float[texwidth * texheight][4];

  // create the indirect addressing texture
  for (i = 0; i < xlevels; i++)
  {
    calLength(startx, endx, i, &levellength, &loffset);
    calLength(startx, endx, i + 1, &halflength, &loffset);

    for (j = 0; j < levellength; j++)
    {
      int   eo = j % 2;
      float neighbours[9];

      // put filter selector to tex3
      if (loffset == 1)
        tex1[i * texwidth + j][1] = 1 - eo;
      else
        tex1[i * texwidth + j][1] = eo;
      tex1[i * texwidth + j][2] = 0;


      // Calculate neighbor indirect address (offset = -4), and put it to tex1
      if (loffset == 1)
        neighbours[0] = 0.5 + halflength * (1.0 - eo) + (ext(j - 4, levellength, mode) - 1.0 * eo) / 2.0;
      else
        neighbours[0] = 0.5 + halflength * eo + (ext(j - 4, levellength, mode) - 1.0 * eo) / 2.0;
      tex1[i * texwidth + j][0] = neighbours[0];

      // Compute 9 neighbors' addresses only for the last element (boundary extension)
      if (j == levellength - 1)
      {
        //  these 5 neighbours share same parity (even/oddness) 
        for (k = -4; k <= 4; k += 2)
        {
          if (loffset == 1)
            neighbours[k + 4] = 0.5 + halflength * (1.0 - eo) + (ext(j + k, levellength, mode) - 1.0 * eo) / 2.0;
          else
            neighbours[k + 4] = 0.5 + halflength * eo + (ext(j + k, levellength, mode) - 1.0 * eo) / 2.0;
        }

        eo = 1 - eo;

        //  these 4 neighbours share same parity (even/oddness) 
        for (k = -3; k <= 3; k += 2)
        {
          if (loffset == 1)
            neighbours[k + 4] = 0.5 + halflength * (1.0 - eo) + (ext(j + k, levellength, mode) - 1.0 * eo) / 2.0;
          else
            neighbours[k + 4] = 0.5 + halflength * eo + (ext(j + k, levellength, mode) - 1.0 * eo) / 2.0;
        }

        for (k = 0; k < 9; k++) // compute 9 neighbor's indirect address
          tex1[i * texwidth + j + k][0] = neighbours[k];
      }
    }
  }


  for (i = 0; i < ylevels; i++)
  {
    calLength(starty, endy, i, &levellength, &loffset);
    calLength(starty, endy, i + 1, &halflength, &loffset);

    for (j = 0; j < levellength; j++)
    {
      int   eo = j % 2;
      float neighbours[9];

      // put filter selector to tex1
      if (loffset == 1)
        tex1[(maxlevels - i - 1) * texwidth + (texwidth - 1) - j][1] = 1 - eo;
      else
        tex1[(maxlevels - i - 1) * texwidth + (texwidth - 1) - j][1] = eo;
      tex1[(maxlevels - i - 1) * texwidth + (texwidth - 1) - j][2] = 0;


      // Calculate neighbor indirect address (offset = -4), and put it to tex1            
      if (loffset == 1)
        neighbours[0] = 0.5 + halflength * (1.0 - eo) + (ext(j - 4, levellength, mode) - 1.0 * eo) / 2.0;
      else
        neighbours[0] = 0.5 + halflength * eo + (ext(j - 4, levellength, mode) - 1.0 * eo) / 2.0;
      tex1[(maxlevels - i - 1) * texwidth + (texwidth - 1) - j][0] = neighbours[0];


      // Compute 9 neighbors' addresses only for the last element (boundary extension)
      if (j == levellength - 1)
      {
        //  these 5 neighbour share same parity (even/oddness) 
        for (k = -4; k <= 4; k += 2)
        {
          if (loffset == 1)
            neighbours[k + 4] = 0.5 + halflength * (1.0 - eo) + (ext(j + k, levellength, mode) - 1.0 * eo) / 2.0;
          else
            neighbours[k + 4] = 0.5 + halflength * eo + (ext(j + k, levellength, mode) - 1.0 * eo) / 2.0;
        }

        eo = 1 - eo;

        //  these 4 neighbour share same parity (even/oddness) 
        for (k = -3; k <= 3; k += 2)
        {
          if (loffset == 1)
            neighbours[k + 4] = 0.5 + halflength * (1.0 - eo) + (ext(j + k, levellength, mode) - 1.0 * eo) / 2.0;
          else
            neighbours[k + 4] = 0.5 + halflength * eo + (ext(j + k, levellength, mode) - 1.0 * eo) / 2.0;
        }

        for (k = 0; k < 9; k++)
          tex1[(maxlevels - i - 1) * texwidth + (texwidth - 1) - j - k][0] = neighbours[k];
      }
    }
  }

  *itex1 = (float *) tex1;
  return true;
}








//------------------------------------------------------------------------------
// Function         : CDwtObj::CDwtObj()
// Description      : Constructor
//------------------------------------------------------------------------------

CDwtObj::CDwtObj()
{
  m_imageWidth  = 0;
  m_imageHeight = 0;
  m_iReadBuffer = 0;
  m_rt[0]       = NULL;
  m_rt[1]       = NULL;	
}




//------------------------------------------------------------------------------
// Function         : CDwtObj::~CDwtObj()
// Description      : Destructor
//------------------------------------------------------------------------------

CDwtObj::~CDwtObj()
{
  finalcleanup();
}




//------------------------------------------------------------------------------
// Function         : cgErrorCallback()
// Description      : Cg Error Callback
//------------------------------------------------------------------------------
void cgErrorCallback()
{
  CGerror lastError = cgGetError();
  
  if(lastError)
  {
    printf("%s\n\n", cgGetErrorString(lastError));
    printf("%s\n", cgGetLastListing(cgContext));
    printf("Cg error, exiting...\n");
    
    exit(0);
  }
} 





//------------------------------------------------------------------------------
// Function         : PrintGLerror()
// Description      : Print OpenGL Error Msg
//------------------------------------------------------------------------------

void PrintGLerror( char *msg )
{
 GLenum errCode;
 const GLubyte *errStr;

 if ((errCode = glGetError()) != GL_NO_ERROR) 
 {
    errStr = gluErrorString(errCode);
    fprintf(stderr,"OpenGL ERROR: %s: %s\n", errStr, msg);
 }
}




//------------------------------------------------------------------------------
// Function         : CDwtObj::createLookupTex
// Description      : Creat the  Ext,HL,BasePos Lookup Texture 
//------------------------------------------------------------------------------
// [in] mode --boundary extension mode (symper, per)
// [in] startx, endx, starty, endy -- the indices of x and y direction

bool CDwtObj::createLookupTex(extmode mode, int startx, int starty, int endx, int endy)
{
  //uninitialized imagedimension
  if (m_imageWidth <= 0 || m_imageHeight <= 0)
    return false;

  int   i;
  int   maxrowlevels = calLevels(startx, endx) + 3;
  int   maxcollevels = calLevels(starty, endy) + 3;
  float (*rowlookup)[3];
  float (*collookup)[3];

  // Designed for filter kernel with maximum length 9, so adding 4 at each side for boundary extension, total 8 more entries 
  rowlookup = new float[(m_imageWidth  + 8) * maxrowlevels][3];
  collookup = new float[(m_imageHeight + 8) * maxcollevels][3];

  // wrapping
  //***********************************************************************************
  //*    -4 -3 -2 -1 0 1 2.........m_imagewidth-2, m_imagewidth-1, m_imagewidth-2.... *
  //***********************************************************************************


  // fill up the  lookup table for horizontal decomposition
  for (i = 0 ; i < (m_imageWidth + 8) * maxrowlevels ; i++)
  {
    // determine current row--current level
    int fullrow, halfrow, loffset;
    int level = i / (m_imageWidth + 8);
    int pos   = i % (m_imageWidth + 8);

    calLength(startx, endx, level, &fullrow, &loffset);
    calLength(startx, endx, level + 1, &halfrow, &loffset);

    // The 3 components: boundary extension / High|low / Base Pos
    
    // boundary extension
    rowlookup[i][0] = pos - 4;

    switch (mode)
    {
      case symper:
        if (rowlookup[i][0] < 0)
          rowlookup[i][0] = -rowlookup[i][0];
        if (rowlookup[i][0] > fullrow - 1)
          rowlookup[i][0] = fullrow - 1 - (rowlookup[i][0] - fullrow + 1);
        break;

      case per:
        rowlookup[i][0] = fmod((rowlookup[i][0] + fullrow), fullrow);
        break;
    }

    // High pass or low pass?
    if (rowlookup[i][0] >= halfrow)
      rowlookup[i][1] = 1;      // for Highpass
    else
      rowlookup[i][1] = 0;      // for Lowpass

    // Base Position
    // loffset determine even or odd samples to choose for dowsampling
    if (loffset == 1)
      rowlookup[i][2] = (rowlookup[i][0] - halfrow * rowlookup[i][1]) * 2.0 + 0.5 + 1.0 - rowlookup[i][1];
    else
      rowlookup[i][2] = (rowlookup[i][0] - halfrow * rowlookup[i][1]) * 2.0 + 0.5 + rowlookup[i][1];

    rowlookup[i][0] += 0.5;

  }




  // fill up the lookup table for vertical decomposition
  for (i = 0; i < (m_imageHeight + 8) * maxcollevels; i++)
  {
    //determine current row--current level
    int fullcol, halfcol, loffset;
    int level = i / (m_imageHeight + 8);
    int pos   = i % (m_imageHeight + 8);

    calLength(starty, endy, level, &fullcol, &loffset);
    calLength(starty, endy, level + 1, &halfcol, &loffset);

    // The 3 component:  boundary extension/ High|low / Base Pos

    // boundary extension
    collookup[i][0] = pos - 4;

    switch (mode)
    {
      case symper:
        if (collookup[i][0] < 0)
          collookup[i][0] = -collookup[i][0];
        if (collookup[i][0] > fullcol - 1)
          collookup[i][0] = fullcol - 1 - (collookup[i][0] - fullcol + 1);
        break;

      case per:
        collookup[i][0] = fmod((collookup[i][0] + fullcol), fullcol);
        break;
    }

    // High pass or low pass?
    if (collookup[i][0] >= halfcol)
      collookup[i][1] = 1;      // for Highpass
    else
      collookup[i][1] = 0;      // for Lowpass


    // Base Position
    // loffset determine even or odd samples to choose for dowsampling
    if (loffset == 1)
      collookup[i][2] = (collookup[i][0] - halfcol * collookup[i][1]) * 2.0 + 0.5 + 1.0 - collookup[i][1];
    else
      collookup[i][2] = (collookup[i][0] - halfcol * collookup[i][1]) * 2.0 + 0.5 + collookup[i][1];

    collookup[i][0] += 0.5;
  }

  DELTEXTURES(1, &m_rowLookupTexID);
  DELTEXTURES(1, &m_colLookupTexID);
  glGenTextures(1, &m_rowLookupTexID);
  glGenTextures(1, &m_colLookupTexID);

  // Create the Horizontal Lookup Texture
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, m_rowLookupTexID);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGB32_NV, m_imageWidth + 8, maxrowlevels, 0, GL_RGB, GL_FLOAT,
               rowlookup);

  // Create the Vertical Lookup Texture
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, m_colLookupTexID);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGB32_NV, m_imageHeight + 8, maxcollevels, 0, GL_RGB, GL_FLOAT,
               collookup);

  delete[]rowlookup;
  delete[]collookup;
  return true;
}





//------------------------------------------------------------------------------
// Function         : CDwtObj::createImgTex
// Description      : render input image data to texture
//------------------------------------------------------------------------------
// [in] imgbuffer --the input image buffer
//
bool CDwtObj::createImgTex(float *imgbuffer)
{
  //uninitialized image dimensions
  if (m_imageWidth <= 0 || m_imageHeight <= 0)
    return false;

  glGenTextures(1, &m_imageTexID);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, m_imageTexID);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGB32_NV, m_imageWidth, m_imageHeight, 0, GL_RGB, GL_FLOAT, imgbuffer);
  PrintGLerror("createimgtex");

  if ( m_busefbo ) {
    // fill the 2nd color texture of FBO with the image texture
    glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);
  } else {
    m_rt[1]->BeginCapture();
  }
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();

  glClear(GL_COLOR_BUFFER_BIT);

  cgGLBindProgram(m_fillProg);
  cgGLEnableProfile(m_fpProfile);

  cgGLSetTextureParameter(m_fill_Tex_Param, m_imageTexID);
  cgGLEnableTextureParameter(m_fill_Tex_Param);

  glBegin(GL_QUADS);
    glTexCoord2f(0, 0);
    glVertex2f(0, 0);
    glTexCoord2f(m_imageWidth, 0);
    glVertex2f(m_imageWidth, 0);
    glTexCoord2f(m_imageWidth, m_imageHeight);
    glVertex2f(m_imageWidth, m_imageHeight);
    glTexCoord2f(0, m_imageHeight);
    glVertex2f(0, m_imageHeight);
  glEnd();

  cgGLDisableTextureParameter(m_fill_Tex_Param);
  cgGLDisableProfile(m_fpProfile);

  glPopMatrix();
  PrintGLerror(" create image texture");
  if ( !m_busefbo ) {
    m_rt[1]->EndCapture();
  }
  DELTEXTURES(1, &m_imageTexID);
  return true;
}


//------------------------------------------------------------------------------
// Function         : CDwtObj::setImageDimensions
// Description      : set image dimension variables
//------------------------------------------------------------------------------
//  [in] width, height -- the input image dimension

bool CDwtObj::setImageDimensions(int width, int height)
{
  if (width <= 0 || height <= 0)
    return false;

  this->m_imageWidth  = width;
  this->m_imageHeight = height;

  return true;

}


//------------------------------------------------------------------------------
// Function         : CDwtObj::initOpenGL
// Description      : initialize OpenGL
//------------------------------------------------------------------------------
//
bool CDwtObj::initOpenGL()
{
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);

  if (0 == glutGetWindow())
    glutCreateWindow("gpu dwt");

  return true;

}


//------------------------------------------------------------------------------
// Function             : CDwtObj::initglew()
// Description      : initialize glew
//------------------------------------------------------------------------------
//
bool CDwtObj::initglew()
{

  int err = glewInit();

  if (GLEW_OK != err)
  {
    fprintf(stderr, "GLEW Error: %s\n", glewGetErrorString(err));
    return false;
  }


  if (!GLEW_NV_texture_rectangle)
  {
    fprintf(stderr, "Sorry, Non--NVIDIA card detected, This class needs NVIDIA extensions ");
    return false;
  }

  return true;

}

//------------------------------------------------------------------------------
// Function             : CDwtObj::initRenderTexture
// Description      : initialize the renderTexture objects
//------------------------------------------------------------------------------
// [in] BPP--bits per pixel
//
bool CDwtObj::initRenderTexture(int BPP)
{
  bool succ;

  //only support 16-bit or 32-bit
  if (BPP != 16 && BPP != 32)
    return false;

  m_rt[0] = new RenderTexture(this->m_imageWidth, this->m_imageHeight);
  m_rt[1] = new RenderTexture(this->m_imageWidth, this->m_imageHeight);

  succ =          m_rt[0]->Initialize(true, false, false, false, false, BPP, BPP, BPP, 0, RenderTexture::RT_RENDER_TO_TEXTURE);
  succ = succ && (m_rt[1]->Initialize(true, false, false, false, false, BPP, BPP, BPP, 0, RenderTexture::RT_RENDER_TO_TEXTURE));

  if (!succ)
  {
    printf("can't create RenderTexture\n");
    exit(-1);
  }

  // setup the rendering context for the RenderTexture
  for (int i = 0; i < 2; i++)
  {
    m_rt[i]->BeginCapture();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0f, m_imageWidth, 0.0f, m_imageHeight);
    glDisable(GL_LIGHTING);
    glDisable(GL_COLOR_MATERIAL);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
    glClearColor(0.2, 0.2, 0.2, 1);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    m_rt[i]->EndCapture();
  }
  return true;
}

//------------------------------------------------------------------------------
// Function         : CDwtObj::initFBO
// Description      : initialize the FBO objects
//------------------------------------------------------------------------------
// [in] BPP--bits per pixel
//
bool CDwtObj::initFBO(int BPP)
{
  //only support 16-bit or 32-bit
  bool suc = false;
  if (BPP != 16 && BPP != 32)
    return false;

  // Initialize the FBO object
  GLenum GL_TARGET = GL_TEXTURE_RECTANGLE_NV;
  GLuint GL_FORMAT = (BPP == 16) ? GL_FLOAT_RGB16_NV : GL_FLOAT_RGB32_NV;  

  glGenFramebuffersEXT(1, &m_fbo);
  // Enable FBO
  glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, m_fbo);

  // Initialize two textures
  glGenTextures(1, &m_fbort[0]);
  glBindTexture(GL_TARGET, m_fbort[0]);
  glTexParameteri(GL_TARGET, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TARGET, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TARGET, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TARGET, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexImage2D(GL_TARGET, 0, GL_FORMAT, this->m_imageWidth, this->m_imageHeight, 0, GL_RGB, GL_FLOAT, NULL);

  glGenTextures(1, &m_fbort[1]);
  glBindTexture(GL_TARGET, m_fbort[1]);
  glTexParameteri(GL_TARGET, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TARGET, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TARGET, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TARGET, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexImage2D(GL_TARGET, 0, GL_FORMAT, this->m_imageWidth, this->m_imageHeight, 0, GL_RGB, GL_FLOAT, NULL);

  // Attach textures to two color attachements of the FBO
  glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TARGET, m_fbort[0], 0);
  glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT1_EXT, GL_TARGET, m_fbort[1], 0);
  glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);

  // Initialize the OpenGL rendering context	
  glViewport(0, 0, m_imageWidth, m_imageHeight);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(0.0f, m_imageWidth, 0.0f, m_imageHeight);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glDisable(GL_LIGHTING);
  glDisable(GL_COLOR_MATERIAL);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_BLEND);
  glClearColor(0.2, 0.2, 0.2, 1);

  // Check the completeness of the FBO
  GLenum status;
  status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);

  switch(status)
  {
    case GL_FRAMEBUFFER_COMPLETE_EXT:
      suc = true;
      break;
    case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT:
      printf("[initFBO]: FBO misses a required image/buffer attachment!\n");
      break;
    case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT:
      printf("[initFBO]:  FBO has no images/buffers attached!\n");
      break;
    case GL_FRAMEBUFFER_INCOMPLETE_DUPLICATE_ATTACHMENT_EXT:
      printf("[initFBO]:  FBO has an image/buffer attached in multiple locations!\n");
      break;
    case GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT:
      printf("[initFBO]:  FBO has mismatched image/buffer dimensions!\n");
      break;
    case GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT:
      printf("[initFBO]:  FBO colorbuffer attachments have different types!\n");
      break;
    case GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT:
      printf("[initFBO]:  FBO is trying to draw to non-attached color buffer!\n");
      break;
    case GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT:
      printf("[initFBO]:  FBO is trying to read from a non-attached color buffer!\n");
      break;
    case GL_FRAMEBUFFER_UNSUPPORTED_EXT:
      printf("[initFBO]:  FBO format is not supported by current graphics card/driver!\n");
      break;
    case GL_FRAMEBUFFER_STATUS_ERROR_EXT:
      printf("[initFBO]:  Non-framebuffer passed to glCheckFramebufferStatusEXT()!\n");
      break;
    default:
      printf("[initFBO]: *UNKNOWN ERROR* reported from glCheckFramebufferStatusEXT() for %s!\n");
      break;
  }

  return suc;
}





//------------------------------------------------------------------------------
// Function         : CDwtObj::Init_Cg
// Description      : initialize Cg and Cg Shaders
//------------------------------------------------------------------------------
// [in] mode--dwt mode ( forward, backward ,both)
//
// Modification history
//
// 15 March 2006  (By Liang Wan) 
// -  Use the latest fragment profile avaible on the GPU
//
bool CDwtObj::Init_Cg(dwtmode mode)
{
  // Get the latest CG profile
  m_fpProfile = cgGLGetLatestProfile(CG_GL_FRAGMENT);

  cgSetErrorCallback(cgErrorCallback);

  // Create cgContext.
  if (!cgIsContext(cgContext))
    cgContext = cgCreateContext();

  m_fillProg = cgCreateProgram(cgContext,
                               CG_SOURCE,
                               fillsource, m_fpProfile, NULL, NULL);

  if (m_fillProg != NULL)
  {
    cgGLLoadProgram(m_fillProg);
    m_fill_Tex_Param = cgGetNamedParameter(m_fillProg, "texture");
    assert(m_fill_Tex_Param != NULL);

  }


  //*******************************************************
  //****            forward dwt programs               ****
  //*******************************************************
  if (mode == forward || mode == both)
  {
    // Horizontal 1D forward DWT 
    m_dwtrowProg = cgCreateProgram(cgContext,
                                   CG_SOURCE,
                                   dwtsource, m_fpProfile, NULL, NULL);
    if (m_dwtrowProg != NULL)
    {
      cgGLLoadProgram(m_dwtrowProg);
      m_dwtrow_imageTex_Param  = cgGetNamedParameter(m_dwtrowProg, "dwt");
      assert(m_dwtrow_imageTex_Param != NULL);
      m_dwtrow_filterTex_Param = cgGetNamedParameter(m_dwtrowProg, "filter");
      assert(m_dwtrow_filterTex_Param != NULL);
      m_dwtrow_lookup_Param    = cgGetNamedParameter(m_dwtrowProg, "lut");
      assert(m_dwtrow_lookup_Param != NULL);
      m_dwtrow_level_Param     = cgGetNamedParameter(m_dwtrowProg, "level");
      assert(m_dwtrow_level_Param != NULL);

    }

    // Vertical 1D forward DWT 
    m_dwtcolProg = cgCreateProgram(cgContext,
                                   CG_SOURCE,
                                   dwtcolsource,
                                   m_fpProfile, NULL, NULL);
    if (m_dwtcolProg != NULL)
    {
      cgGLLoadProgram(m_dwtcolProg);
      m_dwtcol_imageTex_Param  = cgGetNamedParameter(m_dwtcolProg, "dwt");
      assert(m_dwtcol_imageTex_Param != NULL);
      m_dwtcol_filterTex_Param = cgGetNamedParameter(m_dwtcolProg, "filter");
      assert(m_dwtcol_filterTex_Param != NULL);
      m_dwtcol_lookup_Param    = cgGetNamedParameter(m_dwtcolProg, "lut");
      assert(m_dwtcol_lookup_Param != NULL);
      m_dwtcol_level_Param     = cgGetNamedParameter(m_dwtcolProg, "level");
      assert(m_dwtcol_level_Param != NULL);
    }
  }



  //*******************************************************
  //****            inverse dwt programs                ***
  //*******************************************************
  if (mode == inverse || mode == both)
  {

    // Horizontal 1D inverse DWT
    m_invdwtrowProg = cgCreateProgram(cgContext,
                                      CG_SOURCE,
                                      invdwtsource,
                                      m_fpProfile, NULL, NULL);
    if (m_invdwtrowProg != NULL)
    {
      cgGLLoadProgram(m_invdwtrowProg);
      m_invdwtrow_imageTex_Param  = cgGetNamedParameter(m_invdwtrowProg, "dwt");
      assert(m_invdwtrow_imageTex_Param != NULL);
      m_invdwtrow_filterTex_Param = cgGetNamedParameter(m_invdwtrowProg, "filter");
      assert(m_invdwtrow_filterTex_Param != NULL);
      m_invdwtrow_lookup_Param    = cgGetNamedParameter(m_invdwtrowProg, "lut");
      assert(m_invdwtrow_lookup_Param != NULL);
      m_invdwtrow_level_Param     = cgGetNamedParameter(m_invdwtrowProg, "level");
      assert(m_invdwtrow_level_Param != NULL);
    }


    // Vertical 1D inverse DWT
    m_invdwtcolProg = cgCreateProgram(cgContext,
                                      CG_SOURCE,
                                      invdwtcolsource,                                      
                                      m_fpProfile, NULL, NULL);
    if (m_invdwtcolProg != NULL)
    {
      cgGLLoadProgram(m_invdwtcolProg);
      m_invdwtcol_imageTex_Param  = cgGetNamedParameter(m_invdwtcolProg, "dwt");
      assert(m_invdwtcol_imageTex_Param != NULL);
      m_invdwtcol_filterTex_Param = cgGetNamedParameter(m_invdwtcolProg, "filter");
      assert(m_invdwtcol_filterTex_Param != NULL);
      m_invdwtcol_lookup_Param    = cgGetNamedParameter(m_invdwtcolProg, "lut");
      assert(m_invdwtcol_lookup_Param != NULL);
      m_invdwtcol_level_Param     = cgGetNamedParameter(m_invdwtcolProg, "level");
      assert(m_invdwtcol_level_Param != NULL);
      m_invdwtcol_texwidth_Param  = cgGetNamedParameter(m_invdwtcolProg, "texwidth");
      assert(m_invdwtcol_texwidth_Param != NULL);
      m_invdwtcol_texheight_Param = cgGetNamedParameter(m_invdwtcolProg, "texheight");
      assert(m_invdwtcol_texheight_Param != NULL);
    }
  }

  return true;
}




//------------------------------------------------------------------------------
// Function         : CDwtObj::get_buffer
// Description      : retrieve the transformed buffer
//------------------------------------------------------------------------------
// [in,out] myfloatbuffer-- pointer to USER ALLOCATED buffer for storing the result
//
void CDwtObj::getbuffer(float *myfloatbuffer)
{
  if ( m_busefbo )
  {
    //select the last operated colorbuffer and readback the pixel values       
    if(m_iReadBuffer == 0) 
      glReadBuffer(GL_COLOR_ATTACHMENT1_EXT); 
    else 
      glReadBuffer(GL_COLOR_ATTACHMENT0_EXT);    
    glReadPixels(0, 0, m_imageWidth, m_imageHeight, GL_RGB, GL_FLOAT, myfloatbuffer);
    // Disable the FBO
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
  }
  else  
  {
    //select the last operated buffer and readback the pixel values         
    m_rt[1 - m_iReadBuffer]->BeginCapture();
    glReadPixels(0, 0, m_imageWidth, m_imageHeight, GL_RGB, GL_FLOAT, myfloatbuffer);
    PrintGLerror("readbuffer");
    m_rt[1 - m_iReadBuffer]->EndCapture();
  }
}




//------------------------------------------------------------------------------
// Function         : CDwtObj::createFilterTex
// Description      : create the high/low pass filter texture
//------------------------------------------------------------------------------
// [in] mode--dwt mode ( forward, backward ,both)
//
bool CDwtObj::createFilterTex(dwtmode mode)
{

  DELTEXTURES(1, &m_decomFilterTexID);
  DELTEXTURES(1, &m_reconFilterTexID);
  glGenTextures(1, &m_decomFilterTexID);
  glGenTextures(1, &m_reconFilterTexID);

  // create the filter textures
  if (mode == forward || mode == both)
  {
    glBindTexture(GL_TEXTURE_RECTANGLE_NV, m_decomFilterTexID);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_R32_NV, 18, 1, 0, GL_RED, GL_FLOAT, decomp_filter);
  }

  if (mode == inverse || mode == both)
  {
    glBindTexture(GL_TEXTURE_RECTANGLE_NV, m_reconFilterTexID);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_R32_NV, 18, 1, 0, GL_RED, GL_FLOAT, recon_filter);
  }

  return true;
}


//------------------------------------------------------------------------------
// Function         : CDwtObj::forward_dwt
// Description      : do forward dwt
//------------------------------------------------------------------------------
// [in] level-- level 0 for whole image, level 1 for upper left 1/4 image, and so on
// [in] startx, endx, starty, endy -- the indices of x and y direction
//
// Modification history
//
// 15 March 2006 (by Liang Wan)
// -- Use Framebuffer objects in place of pbuffer
// 
#define RASTER_QUAD    { glBegin(GL_QUADS);                                        \
                           glTexCoord2f(             0.0f,               0.0f);    \
                           glVertex2f  (             0.0f,               0.0f);    \
                           glTexCoord2f((float) quadWidth,               0.0f);    \
                           glVertex2f  ((float) quadWidth,               0.0f);    \
                           glTexCoord2f((float) quadWidth, (float) quadHeight);    \
                           glVertex2f  ((float) quadWidth, (float) quadHeight);    \
                           glTexCoord2f(0.0f,              (float) quadHeight);    \
                           glVertex2f  (0.0f,              (float) quadHeight);    \
                         glEnd(); }

bool CDwtObj::forwarddwt(int level, int startx, int starty, int endx, int endy)
{

  int quadWidth, quadHeight, tmp;

  calLength(startx, endx, level, &quadWidth, &tmp);
  calLength(starty, endy, level, &quadHeight, &tmp);

  // Vertical Decomposition

  if (quadHeight > 1)
  {
    if ( m_busefbo ) 
    {
      if ( m_iReadBuffer == 0 ) 
        glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
      else 
        glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);      
    } 
    else 
      m_rt[m_iReadBuffer]->BeginCapture();
    

    cgGLBindProgram   (m_dwtcolProg);
    cgGLEnableProfile(m_fpProfile);
    cgGLSetParameter1f(m_dwtcol_level_Param, level);
    if ( m_busefbo ) 
      cgGLSetTextureParameter    (m_dwtcol_imageTex_Param,  m_fbort[1-m_iReadBuffer]);
    else 
      cgGLSetTextureParameter    (m_dwtcol_imageTex_Param,  m_rt[1 - m_iReadBuffer]->GetTextureID());
    
    cgGLEnableTextureParameter (m_dwtcol_imageTex_Param);
    cgGLSetTextureParameter    (m_dwtcol_filterTex_Param, m_decomFilterTexID);
    cgGLEnableTextureParameter (m_dwtcol_filterTex_Param);
    cgGLSetTextureParameter    (m_dwtcol_lookup_Param,    m_colLookupTexID);
    cgGLEnableTextureParameter (m_dwtcol_lookup_Param);

    // Draw the quad or actually perform vertical decomposition
    RASTER_QUAD;

    cgGLDisableTextureParameter(m_dwtcol_imageTex_Param);
    cgGLDisableTextureParameter(m_dwtcol_filterTex_Param);
    cgGLDisableTextureParameter(m_dwtcol_lookup_Param);
    cgGLDisableProfile(m_fpProfile);

    if ( !m_busefbo ) 
      m_rt[m_iReadBuffer]->EndCapture();
    
    m_iReadBuffer = (m_iReadBuffer + 1) % 2;
  }
  else   // pass through if not enough length
  {
    if ( m_busefbo ) 
    {
      if ( m_iReadBuffer == 0 ) 
        glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
      else 
        glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);
    } 
    else 
      m_rt[m_iReadBuffer]->BeginCapture();

    cgGLBindProgram(m_fillProg);
    cgGLEnableProfile(m_fpProfile);
    if ( m_busefbo ) 
      cgGLSetTextureParameter   (m_fill_Tex_Param, m_fbort[1 - m_iReadBuffer]);
    else 
      cgGLSetTextureParameter   (m_fill_Tex_Param, m_rt[1 - m_iReadBuffer]->GetTextureID());    
    cgGLEnableTextureParameter(m_fill_Tex_Param);

    RASTER_QUAD;

    cgGLDisableTextureParameter(m_fill_Tex_Param);
    cgGLDisableProfile(m_fpProfile);

    if ( !m_busefbo ) 
      m_rt[m_iReadBuffer]->EndCapture();
    
    m_iReadBuffer = (m_iReadBuffer + 1) % 2;
  }



  // Horizontal  Decomposition
  if (quadWidth > 1)
  {
    if ( m_busefbo ) 
    {
      if ( m_iReadBuffer == 0 ) 
        glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
      else 
        glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);      
    }
    else 
      m_rt[m_iReadBuffer]->BeginCapture();
    
    cgGLBindProgram   (m_dwtrowProg);
    cgGLEnableProfile(m_fpProfile);
    cgGLSetParameter1f(m_dwtrow_level_Param, (float) level);
    if ( m_busefbo ) 
      cgGLSetTextureParameter(m_dwtrow_imageTex_Param,  m_fbort[1-m_iReadBuffer]);
    else 
      cgGLSetTextureParameter(m_dwtrow_imageTex_Param,  m_rt[1 - m_iReadBuffer]->GetTextureID());    
    cgGLEnableTextureParameter(m_dwtrow_imageTex_Param);
    cgGLSetTextureParameter   (m_dwtrow_filterTex_Param, m_decomFilterTexID);
    cgGLEnableTextureParameter(m_dwtrow_filterTex_Param);
    cgGLSetTextureParameter   (m_dwtrow_lookup_Param,    m_rowLookupTexID);
    cgGLEnableTextureParameter(m_dwtrow_lookup_Param);

    RASTER_QUAD;

    cgGLDisableTextureParameter(m_dwtrow_imageTex_Param);
    cgGLDisableTextureParameter(m_dwtrow_filterTex_Param);
    cgGLDisableTextureParameter(m_dwtrow_lookup_Param);
    cgGLDisableProfile(m_fpProfile);
    if ( !m_busefbo ) 
      m_rt[m_iReadBuffer]->EndCapture();
    m_iReadBuffer = (m_iReadBuffer + 1) % 2;
  }
  else   // pass through if not enough length
  {
    if ( m_busefbo ) 
    {
      if ( m_iReadBuffer == 0 ) 
        glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
      else 
        glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);      
    } 
    else 
      m_rt[m_iReadBuffer]->BeginCapture();
    cgGLBindProgram  (m_fillProg);
    cgGLEnableProfile(m_fpProfile);
    if ( m_busefbo ) 
      cgGLSetTextureParameter   (m_fill_Tex_Param, m_fbort[1 - m_iReadBuffer]);
    else 
      cgGLSetTextureParameter   (m_fill_Tex_Param, m_rt[1 - m_iReadBuffer]->GetTextureID());    
    cgGLEnableTextureParameter(m_fill_Tex_Param);

    RASTER_QUAD;

    cgGLDisableTextureParameter(m_fill_Tex_Param);
    cgGLDisableProfile(m_fpProfile);
    if ( !m_busefbo ) 
      m_rt[m_iReadBuffer]->EndCapture();
    m_iReadBuffer = (m_iReadBuffer + 1) % 2;
  }

  return true;
}





//------------------------------------------------------------------------------
// Function         : CDwtObj::OneTimeDWT2
// Description      : one-stop solution for dwt,  
//------------------------------------------------------------------------------
// [in] mode    -- boundary extension mode (symper, per)
// [in] imagewidth,  imageheight  -- image dimension
// [in out]  imagebuffer        --  pointer for input buffer, when returned it holds the output
// [in]  beg_level, end_level -- begin level and end level for dwt
// [in]  isforward      -- ture for forward transform , false for inverse
// [in]  initGL -- initialize opengl? ( in opengl app, usually false)
// [in] initGLEW -- initialize glew, the extension libary
// [in] startx, endx, starty, endy -- the indices of x and y direction
//
bool CDwtObj::dwtallinone(extmode mode, int imagewidth, int imageheight, float *imagebuffer, int beg_level, int end_level,
                          bool isforward, bool initGL, bool initGLEW, int startx, int starty, int endx, int endy)
{
  int i;

  if (initGL)
    CHECKSUCC(initOpenGL());

  if (initGLEW)
    CHECKSUCC(initglew());

  CHECKSUCC(setImageDimensions(imagewidth, imageheight));
  CHECKSUCC(Init_Cg(forward));
  m_busefbo = false;
  if ( glewIsExtensionSupported("GL_EXT_framebuffer_object") ) 
    m_busefbo = true;
  if ( m_busefbo ) 
  {
    m_busefbo = initFBO(32);
    if ( !m_busefbo ) 
    {
      DELTEXTURES(2, m_fbort);
      // delete the FBO
      glDeleteFramebuffersEXT(1, &m_fbo);
    }
  } 
  if ( !m_busefbo ) 
    CHECKSUCC(initRenderTexture(32));
  CHECKSUCC(createImgTex(imagebuffer));
  CHECKSUCC(createFilterTex(forward));

  // dwt or idwt starts and ends at particular levels you specify
  if (forward)
  {
    CHECKSUCC(createLookupTex(mode, startx, starty, endx, endy));
    for (i = beg_level; i <= end_level; i++)
      CHECKSUCC(forwarddwt(i, startx, starty, endx, endy));
  }
  else
  {
    CHECKSUCC(createInvLookupTex(mode, startx, starty, endx, endy));
    for (i = beg_level; i >= end_level; i--)
      CHECKSUCC(inversedwt(i, startx, starty, endx, endy));
  }

  getbuffer(imagebuffer);
  return true;
}




//------------------------------------------------------------------------------
// Function         : CDwtObj::OneTimeDWT
// Description      : one-stop solution for dwt  
//------------------------------------------------------------------------------
// [in] mode    -- boundary extension mode (symper, per)
// [in] imagewidth,  imageheight  -- image dimension
// [in|out]  imagebuffer        --  pointer for input buffer, when returned it holds the output
// [in]  level -- how many levels for dwt, e.x for forward with 3 levels, it will do level 0, then 1, then 2, for inverse, it will do 2, then 1, then 0
// [in]  isforward      -- ture for forward transform , false for inverse
// [in]  initGL -- initialize opengl? ( in opengl app, usually false)
// [in] initGLEW -- initialize glew, the extension libary?
// [in] startx, endx, starty, endy -- the indices of x and y direction
//
// Modification history
// 
// 15 March 2006 (Liang Wan)
// -- Add comments on timing computation for DWT encoding 
//
bool CDwtObj::dwtallinone(extmode mode, int imagewidth, int imageheight, float *imagebuffer, int level, bool isforward,
                          bool initGL, bool initGLEW, int startx, int starty, int endx, int endy)
{
  int i;

  // Timing for OpenGL, CG initialization  
  // clock_t t1 = clock();
  if (initGL)
    CHECKSUCC(initOpenGL());
  if (initGLEW)
    CHECKSUCC(initglew());

  CHECKSUCC(setImageDimensions(imagewidth, imageheight));
  CHECKSUCC(Init_Cg(isforward ? forward : inverse));
  
  // Timing for OpenGL, CG initialization
  // clock_t t2 = clock();
  // clock_t totaltime = t2 - t1;
	// printf("OpenGL:    %d.%.3d s\n", totaltime/CLOCKS_PER_SEC, (totaltime%CLOCKS_PER_SEC)*1000/CLOCKS_PER_SEC);

  m_busefbo = false;
  if ( glewIsExtensionSupported("GL_EXT_framebuffer_object") ) 
    m_busefbo = true;
  if ( m_busefbo ) 
  {
    m_busefbo = initFBO(32);
    if ( !m_busefbo ) 
    {
      DELTEXTURES(2, m_fbort);
      // delete the FBO
      glDeleteFramebuffersEXT(1, &m_fbo);
    }
  } 
  if ( !m_busefbo ) 
    CHECKSUCC(initRenderTexture(32));
  CHECKSUCC(createImgTex(imagebuffer));
  CHECKSUCC(createFilterTex(isforward ? forward : inverse));


  if (isforward)
  {
    CHECKSUCC(createLookupTex(mode, startx, starty, endx, endy));
    // Timing for texture preparation
    // t1 = clock();
    // totaltime = t1 - t2;
    // printf("Texture:    %d.%.3d s\n", totaltime/CLOCKS_PER_SEC, (totaltime%CLOCKS_PER_SEC)*1000/CLOCKS_PER_SEC);

    for (i = 0; i < level; i++)
      CHECKSUCC(forwarddwt(i, startx, starty, endx, endy));

    // Timing for GPU DWT
    // t2 = clock();
    // totaltime = t2 - t1;
    // printf("DWT:    %d.%.3d s\n", totaltime/CLOCKS_PER_SEC, (totaltime%CLOCKS_PER_SEC)*1000/CLOCKS_PER_SEC);
  }
  else
  {
    CHECKSUCC(createInvLookupTex(mode, startx, starty, endx, endy));
    for (i = level - 1; i >= 0; i--)
      CHECKSUCC(inversedwt(i, startx, starty, endx, endy));
  }
  getbuffer(imagebuffer);
  return true;
}




//------------------------------------------------------------------------------
// Function         : CDwtObj::finalcleanup
// Description      : delete the textures
//------------------------------------------------------------------------------
//
bool CDwtObj::finalcleanup()
{
  //delete textures and rendertextures
  DELTEXTURES(1, &m_colLookupTexID);
  DELTEXTURES(1, &m_rowLookupTexID);
  DELTEXTURES(1, &m_imageTexID);
  DELTEXTURES(1, &m_decomFilterTexID);
  DELTEXTURES(1, &m_reconFilterTexID);
  DELTEXTURES(1, &m_LookupTexID);

  if ( m_busefbo ) 
  {
    DELTEXTURES(2, m_fbort);
    // delete the FBO
    glDeleteFramebuffersEXT(1, &m_fbo);
  }
  else 
  {
    if (m_rt[0] != NULL)
      delete m_rt[0];
    if (m_rt[1] != NULL)
      delete m_rt[1];
  }
  
  // delete resident cg programs
  CGprogram program = cgGetFirstProgram(cgContext);
  CGprogram tmpprog = program;

  while (tmpprog != 0)
  {
    tmpprog = cgGetNextProgram(program);
    cgDestroyProgram(program);
    program = tmpprog;
  }

  // destroy cg context
  if (cgIsContext(cgContext))
    cgDestroyContext(cgContext);

  return true;
}




//------------------------------------------------------------------------------
// Function         : CDwtObj::createInvLookupTex
// Description      : Create the Indirect Addressing Texture for inverse dwt
//------------------------------------------------------------------------------
// [in] mode --boundary extension mode (symper, per)
// [in] startx, endx, starty, endy -- the indices of x and y direction

bool CDwtObj::createInvLookupTex(extmode mode, int startx, int starty, int endx, int endy)
{
  float *tex1 = NULL;
  int    texwidth, texheight;

  createIDATexture(mode, &tex1, m_imageWidth, m_imageHeight, texwidth, texheight, startx, starty, endx, endy);
  m_ida_texwidth  = texwidth;
  m_ida_texheight = texheight;

  DELTEXTURES(1, &m_LookupTexID);
  glGenTextures(1, &m_LookupTexID);

  // Create the Lookup Texture for IDWT
  glBindTexture  (GL_TEXTURE_RECTANGLE_NV, m_LookupTexID);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexImage2D   (GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGBA32_NV, texwidth, texheight, 0, GL_RGBA, GL_FLOAT, tex1);

  delete[]tex1;
  return true;
}




//------------------------------------------------------------------------------
// Function         : CDwtObj::inverse_dwt
// Description      : do inverse dwt
//------------------------------------------------------------------------------
// [in] level-- level 0 for whole image, level 1 for upper left 1/4 image, and so on
// [in] startx, endx, starty, endy -- the indices of x and y direction
//
bool CDwtObj::inversedwt(int level, int startx, int starty, int endx, int endy)
{
  int quadWidth, quadHeight, tmp;

  calLength(startx, endx, level, &quadWidth, &tmp);
  calLength(starty, endy, level, &quadHeight, &tmp);

  // Horizontal Reconstruction
  if (quadWidth > 1)
  {
    if ( m_busefbo ) 
    {
      if ( m_iReadBuffer == 0 ) 
        glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
      else 
        glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);      
    } 
    else 
      m_rt[m_iReadBuffer]->BeginCapture();    
    cgGLBindProgram  (m_invdwtrowProg);
    cgGLEnableProfile(m_fpProfile);
    cgGLSetParameter1f(m_invdwtrow_level_Param, (float) level);
    if ( m_busefbo ) 
      cgGLSetTextureParameter(m_invdwtrow_imageTex_Param,  m_fbort[1 - m_iReadBuffer]);
    else 
      cgGLSetTextureParameter(m_invdwtrow_imageTex_Param,  m_rt[1 - m_iReadBuffer]->GetTextureID());    
    cgGLEnableTextureParameter(m_invdwtrow_imageTex_Param);
    cgGLSetTextureParameter   (m_invdwtrow_filterTex_Param, m_reconFilterTexID);
    cgGLEnableTextureParameter(m_invdwtrow_filterTex_Param);
    cgGLSetTextureParameter   (m_invdwtrow_lookup_Param,    m_LookupTexID);
    cgGLEnableTextureParameter(m_invdwtrow_lookup_Param);

    RASTER_QUAD;    

    cgGLDisableTextureParameter(m_invdwtrow_imageTex_Param);
    cgGLDisableTextureParameter(m_invdwtrow_filterTex_Param);
    cgGLDisableTextureParameter(m_invdwtrow_lookup_Param);
    cgGLDisableProfile(m_fpProfile);
    if ( !m_busefbo ) 
      m_rt[m_iReadBuffer]->EndCapture();
    m_iReadBuffer = (m_iReadBuffer + 1) % 2;
  }
  else  // pass through if not enough length
  {
    if ( m_busefbo ) 
    {
      if ( m_iReadBuffer == 0 ) 
        glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
      else 
        glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);      
    } 
    else 
      m_rt[m_iReadBuffer]->BeginCapture();
    
    cgGLBindProgram(m_fillProg);
    cgGLEnableProfile(m_fpProfile);
    if ( m_busefbo ) 
      cgGLSetTextureParameter(m_fill_Tex_Param, m_fbort[1 - m_iReadBuffer]);
    else 
      cgGLSetTextureParameter(m_fill_Tex_Param,  m_rt[1 - m_iReadBuffer]->GetTextureID());    
    cgGLEnableTextureParameter(m_fill_Tex_Param);
    
    RASTER_QUAD;    
    
    cgGLDisableTextureParameter(m_fill_Tex_Param);
    cgGLDisableProfile(m_fpProfile);
    if ( !m_busefbo ) 
      m_rt[m_iReadBuffer]->EndCapture();
    m_iReadBuffer = (m_iReadBuffer + 1) % 2;
  }

  // Vertical reconstruction
  if (quadHeight > 1)
  {
    if ( m_busefbo ) 
    {
      if ( m_iReadBuffer == 0 ) 
        glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
      else 
        glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);
    } 
    else 
      m_rt[m_iReadBuffer]->BeginCapture();    
    cgGLBindProgram  (m_invdwtcolProg);
    cgGLEnableProfile(m_fpProfile);
    cgGLSetParameter1f(m_invdwtcol_level_Param,     level);
    cgGLSetParameter1f(m_invdwtcol_texwidth_Param,  m_ida_texwidth);
    cgGLSetParameter1f(m_invdwtcol_texheight_Param, m_ida_texheight);
    if ( m_busefbo ) 
      cgGLSetTextureParameter(m_invdwtcol_imageTex_Param,  m_fbort[1 - m_iReadBuffer]);
    else 
      cgGLSetTextureParameter(m_invdwtcol_imageTex_Param,  m_rt[1 - m_iReadBuffer]->GetTextureID());    
    cgGLEnableTextureParameter(m_invdwtcol_imageTex_Param);
    cgGLSetTextureParameter   (m_invdwtcol_filterTex_Param, m_reconFilterTexID);
    cgGLEnableTextureParameter(m_invdwtcol_filterTex_Param);
    cgGLSetTextureParameter   (m_invdwtcol_lookup_Param,    m_LookupTexID);
    cgGLEnableTextureParameter(m_invdwtcol_lookup_Param);

    RASTER_QUAD;    

    cgGLDisableTextureParameter(m_invdwtcol_imageTex_Param);
    cgGLDisableTextureParameter(m_invdwtcol_filterTex_Param);
    cgGLDisableTextureParameter(m_invdwtcol_lookup_Param);
    cgGLDisableProfile(m_fpProfile);
    if ( !m_busefbo ) 
      m_rt[m_iReadBuffer]->EndCapture();
    m_iReadBuffer = (m_iReadBuffer + 1) % 2;
  }
  else   // pass through if not enough length
  {
    if ( m_busefbo ) 
    {
      if ( m_iReadBuffer == 0 ) 
        glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
      else 
        glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);      
    } 
    else 
      m_rt[m_iReadBuffer]->BeginCapture();
    cgGLBindProgram  (m_fillProg);
    cgGLEnableProfile(m_fpProfile);
    if ( m_busefbo )     
      cgGLSetTextureParameter(m_fill_Tex_Param, m_fbort[1 - m_iReadBuffer]);
    else 
      cgGLSetTextureParameter(m_fill_Tex_Param, m_rt[1 - m_iReadBuffer]->GetTextureID());    
    cgGLEnableTextureParameter(m_fill_Tex_Param);

    RASTER_QUAD;    

    cgGLDisableTextureParameter(m_fill_Tex_Param);
    cgGLDisableProfile(m_fpProfile);
    if ( !m_busefbo ) 
      m_rt[m_iReadBuffer]->EndCapture();
    m_iReadBuffer = (m_iReadBuffer + 1) % 2;
  }

  return true;
}


//------------------------------------------------------------------------------
// Function         : CDwtObj::initialize
// Description      : do the initialization, after return, user can call forward or inverse dwt functions
//------------------------------------------------------------------------------
// [in] mode    -- boundary extension mode (symper, per)
// [in] imagewidth,  imageheight  -- image dimension
// [in]  imagebuffer    --  pointer for input buffer
// [in]  initGL -- initialize opengl? ( in opengl app, usually false)
// [in] initGLEW -- initialize glew, the extension libary.
// [in] startx, endx, starty, endy -- the indices of x and y direction

bool CDwtObj::initialize(extmode mode, int imagewidth, int imageheight, float *imagebuffer, bool initGL, bool initGLEW,
                         int startx, int starty, int endx, int endy)
{
  if (initGL)
    CHECKSUCC(initOpenGL());
  if (initGLEW)
    CHECKSUCC(initglew());
  CHECKSUCC(setImageDimensions(imagewidth, imageheight));
  CHECKSUCC(Init_Cg(both));
  m_busefbo = false;
  if ( glewIsExtensionSupported("GL_EXT_framebuffer_object") ) 
    m_busefbo = true;
  if ( m_busefbo ) 
  {
    m_busefbo = initFBO(32);
    if ( !m_busefbo ) 
    {
      DELTEXTURES(2, m_fbort);
      // delete the FBO
      glDeleteFramebuffersEXT(1, &m_fbo);
    }
  } 
  if ( !m_busefbo ) 
    CHECKSUCC(initRenderTexture(32));
  CHECKSUCC(createImgTex(imagebuffer));
  CHECKSUCC(createFilterTex(both));
  CHECKSUCC(createLookupTex(mode, startx, starty, endx, endy));
  CHECKSUCC(createInvLookupTex(mode, startx, starty, endx, endy));

  return true;
}




///////////////// The overloaded functions for general usage without JPEG2000 indices ///////////////


// one-stop dwt transform, suitable for tasks that only do forward or inverse dwt once
// detail information about the parameters please see inside the cpp file
bool CDwtObj::dwtallinone(extmode mode, int imagewidth, int imageheight, float *imagebuffer, int level, bool isforward,
                          bool initGL, bool initGLEW)
{
  return dwtallinone(mode, imagewidth, imageheight, imagebuffer, level, isforward, initGL, initGLEW, 0, 0, imagewidth,
                     imageheight);
}



bool CDwtObj::dwtallinone(extmode mode, int imagewidth, int imageheight, float *imagebuffer, int beg_level, int end_level,
                          bool isforward, bool initGL, bool initGLEW)
{
  return dwtallinone(mode, imagewidth, imageheight, imagebuffer, beg_level, end_level, isforward, initGL, initGLEW, 0, 0,
                     imagewidth, imageheight);
}


// initialize and feed in the buffer, both forward and inverse dwt functions are available for call after return
bool CDwtObj::initialize(extmode mode, int imagewidth, int imageheight, float *imagebuffer, bool initGL, bool initGLEW)
{
  return initialize(mode, imagewidth, imageheight, imagebuffer, initGL, initGLEW, 0, 0, imagewidth, imageheight);
}


// the forward and inverse dwt function
bool CDwtObj::forwarddwt(int level)
{
  return forwarddwt(level, 0, 0, m_imageWidth, m_imageHeight);
}


bool CDwtObj::inversedwt(int level)
{
  return inversedwt(level, 0, 0, m_imageWidth, m_imageHeight);
}










