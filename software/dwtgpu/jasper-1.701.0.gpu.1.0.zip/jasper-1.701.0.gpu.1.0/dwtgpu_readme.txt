
	Jasper -- Unofficial GPU Extension Release 0.9a



Common Usage:
(for lossy coding, lossless coding don't utilize GPU)

Encoding a .bmp into .jpc using GPU mode
(1) jasper -f myfile.bmp -t bmp -F myfile.jpc -T jpc -O mode=real -O rate=0.9

Encoding a .bmp into .jpc using software mode
(2) jasper -f myfile.bmp -t bmp -F myfile.jpc -T jpc -O mode=real -O rate=0.9 -O nogpu

Decoding a .jpc into .bmp using GPU mode
(3) jasper -f myfile.jpc -t jpc -F myfile.bmp -T bmp

Decoding a .jpc into .bmp using software mode
(3) jasper -f myfile.jpc -t jpc -F myfile.bmp -T bmp -o nogpu


for other options as well as other utility usage, please refer to the japser manual.