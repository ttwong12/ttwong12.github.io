/* ioimage.cpp */
/*
* This program reads and writes images in the format of different 
* spherical mappings.
*
* Copyright (c) 2007-2010, The Chinese University of Hong Kong
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*  * Redistributions of source code must retain the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer.
*  * Redistributions in binary form must reproduce the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer in the documentation and/or other 
*    materials provided with the distribution.
*  * Neither the name of The Chinese University of Hong Kong nor the
*    names of its contributors may be used to endorse or promote products
*    derived from this software without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
* ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
* ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
* POSSIBILITY OF SUCH DAMAGE.
*
*/

#include <string.h>
#include <math.h>

#include "ioimage.h"
#include "ppm.h"
#include "pfm.h"
#include "tga.h"

int clampscale(float input, float scale)
{
  int res = int(input * scale);
  res = ( res > scale ) ? scale : res;
  return res;
}

//
// Rotate the image
//
template <class T> 
void imagerotate(T *image, int w, int h, int bpp, int angle)
{
  int i, j, k, l;
  int len = w * h * bpp;
  T *temp = new T [ len ];
  memcpy(temp, image, sizeof(T)*len);
  switch ( angle )
	{
	case 90: // rotate 90 degrees clockwise
    for ( j=0, k=0; j<w; j++, k++ ) {
      for ( i=h-1, l=0; i>=0; i--, l++ ) {
        memcpy(image+(k*h+l)*bpp, temp+(i*w+j)*bpp, bpp*sizeof(T));
      }
    }
		break;
	case 180: // rotate 180 degrees clockwise
    for ( i=h-1, k=0; i>=0; i--, k++ ) {
      for ( j=w-1, l=0; j>=0; j--, l++ ) {
        memcpy(image+(k*w+l)*bpp, temp+(i*w+j)*bpp, bpp*sizeof(T));
      }
    }
		break;
	case 270: // rotate 270 degrees clockwise
    for ( j=w-1, k=0; j>=0; j--, k++ ) {
      for ( i=0, l=0; i<h; i++, l++) {
        memcpy(image+(k*h+l)*bpp, temp+(i*w+j)*bpp, bpp*sizeof(T));
      }
    }
    break;	
  case -360: // flip horizontally
    for ( i=0, k=0; i<h; i++, k++ ) {
      for ( j=w-1, l=0; j>=0; j--, l++ ) {
        memcpy(image+(k*w+l)*bpp, temp+(i*w+j)*bpp, bpp*sizeof(T));
      }
    }
    break;
  case 360: // flip vertically
    for ( i=h-1, k=0; i>=0; i--, k++ ) {
      for ( j=0, l=0; j<w; j++, l++ ) {
				memcpy(image+(k*w+l)*bpp, temp+(i*w+j)*bpp, bpp*sizeof(T));
      }
    }
		break;
  default:
    break;
	}

  delete [] temp;
}

/////////////////////////////////////////////////////////////////////
////   Read images
//
// Read one image
//
void readoneimage(float *fSrcimage, char *fullname, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo)
{
  int i, j, w, h;
  unsigned char *oneface = NULL;
  int bpp = Srcinfo.ibpp;
  gliGenericImage *image = NULL;  
  int lindex, offset=0, index=0;

  switch ( Srcinfo.format ) {
    case SPH_CUBIC:
	case SPH_UCM:
	case SPH_ISOCUBE:
      w = h = Srcinfo.isize;
      break;
    case SPH_CUBEVERT:
	case SPH_UCMVERT:
	case SPH_ISOCUBEVERT:
      w = Srcinfo.isize * 3;
      h = Srcinfo.isize * 4;
      break;
    case SPH_PLANE: 
	case SPH_MIRROR:
	case SPH_MIRRORCLOSE:
	case SPH_PROBE:
      w = Srcinfo.iwidth;
      h = Srcinfo.iheight;
      break;
    case SPH_HEALPIX:
	case SPH_RHOMBIC:
      w = Srcinfo.isize * 3;
      h = Srcinfo.isize * 4;
      break;
  }

  int len = w*h*bpp;
  switch (Srcinfo.type)
  {
  case _PFM:
    read_pfm(fullname, fSrcimage);
    break;
  case _PPM:
    oneface = new unsigned char [len];
    read_ppm(fullname, oneface);
    for (i=0; i<len; i++)
      fSrcimage[i] = oneface[i]/255.f;
    break;
  case _TGA:    
    image = gliReadTGA(fullname); 
    lindex = (h-1)*w*Srcinfo.ibpp;
    for (i=0; i<h; i++)
    {
      offset = lindex;
      for (j=0; j<w; j++)
      {
        fSrcimage[index]   = image->pixels[offset+2]/255.f;
        fSrcimage[index+1] = image->pixels[offset+1]/255.f;
        fSrcimage[index+2] = image->pixels[offset]/255.f;
        if ( bpp == 4 )
          fSrcimage[index+3] = image->pixels[offset+3]/255.f;
        index += bpp;
        offset += bpp;
      }
      lindex -= w * bpp;
    }
    break;
  }

  if ( oneface ) {
    delete [] oneface;
  }
  if (image) {
    tgafree(image);
  }
}
 
//
// Read 6 single cubemap images in PPM, PFM or TGA
//
// Note the naming of 6 cubemap images should be like 
//   "imagename.xp.ppm", "imagename.zn.ppm", "imagename.xn.ppm",
//   "imagename.zp.ppm", "imagename.yp.ppm", "imagename.yn.ppm".
//
bool readcube( float ***fSrcimage, MYIMAGEINFO *pSrcinfo, MYIMAGEINFO &Dstinfo, char *imagename)
{
  int fn, w, h;
  gliGenericImage *image = NULL;
  char fullname[FILE_NAME_LEN];
  char *suffix[] = {"xp", "zn", "xn", "zp", "yp", "yn"};  
  
  pSrcinfo->ibpp = 3;
  w = h = 0;
  for ( fn=0; fn<pSrcinfo->ifacecnt; fn++ ) {
    // read one cubemap face 
    switch ( pSrcinfo->type ) {
    case _PPM:
      sprintf(fullname, "%s.%s%s", imagename, suffix[fn], ".ppm");
      get_ppm_size(fullname, w, h);
      if ( w == 0 ) {
        printf( "No such image:%s!\n", fullname );
        return false;
      }
      break;
    case _PFM:
      sprintf(fullname, "%s.%s%s", imagename, suffix[fn], ".pfm");
      get_pfm_size(fullname, w, h);
      if ( w == 0 ) {
        printf( "No such image:%s!\n", fullname );
        return false;
      }
      break;
    case _TGA:
      sprintf(fullname, "%s.%s%s", imagename, suffix[fn], ".tga");
      image = gliReadTGA(fullname);
      if ( image == NULL ) {
        printf( "No such image:%s!\n", fullname );
        return false;
      }
      w = image->width;
      h = image->height;
      pSrcinfo->ibpp = image->components;
      break;
    }

    if ( fn == 0 ) {
      pSrcinfo->iwidth = w; 
      pSrcinfo->iheight = h;
      pSrcinfo->isize = w;
    }
    else {
      if ( pSrcinfo->iwidth != w || pSrcinfo->iwidth != h ) {
        if ( image ) tgafree(image);
        return false;
      }
    }

    (*fSrcimage)[fn] = new float [w * h * pSrcinfo->ibpp];
    if ( !(*fSrcimage)[fn] ) {
      printf("Error in allocate memory in readcube()!\n");
      if ( image ) tgafree(image);
      return false;
    }
    readoneimage((*fSrcimage)[fn], fullname, *pSrcinfo, Dstinfo);
    
    // Rotate the image
    if ( fn == 4 ) {
      // rotate 270 degrees
      imagerotate( (*fSrcimage)[fn], w, h, pSrcinfo->ibpp, 270 );
    }
    else if ( fn == 5 ) {
      // rotate 90 degrees
      imagerotate( (*fSrcimage)[fn], w, h, pSrcinfo->ibpp, 90 );
    }

    if ( image ) {
      tgafree(image);
    }
  }
  
  return true;
}

//
// Read vertical-cross cubemap image
//
// Note the naming of vertical-cross cubemap image should be like 
//   "imagename_cross.ppm"
//
bool readcubevert( float ***fSrcimage, MYIMAGEINFO *pSrcinfo, MYIMAGEINFO &Dstinfo, char *imagename)
{
  int fn, w, h, i, j, size;
  gliGenericImage *image = NULL; 
  char fullname[FILE_NAME_LEN];
  unsigned char *ppmimg = NULL;
  float **cubeface = *fSrcimage;
  
  pSrcinfo->ibpp = 3;     
  w = h = 0;
  // read cube_cross.pfm, and cut it into six cube faces 
  switch ( pSrcinfo->type ) {
  case _PPM:
    sprintf(fullname, "%s%s", imagename, "_cross.ppm");
    get_ppm_size(fullname, w, h);
    if ( w == 0 ) {
      printf( "No such image:%s!\n", fullname );
      return false;
    }
    break;
  case _PFM:
    sprintf(fullname, "%s%s", imagename, "_cross.pfm");
    get_pfm_size(fullname, w, h);
    if ( w == 0 ) {
      printf( "No such image:%s!\n", fullname );
      return false;
    }
    break;
  case _TGA:
    sprintf(fullname, "%s%s", imagename, "_cross.tga");
    image = gliReadTGA(fullname);
    if ( image == NULL ) {
      printf( "No such image:%s!\n", fullname );
      return false;
    }
    w = image->width;
    h = image->height;
    pSrcinfo->ibpp = image->components;
    break;
  }
  if ( w/3 != h/4 )
  {
    printf("The HDR image is not in vertical_cross format!\n");    
    if ( image )  tgafree(image);
    return false;
  }
  size = w/3;
  pSrcinfo->iwidth = w; 
  pSrcinfo->iheight = h;      
  pSrcinfo->isize = size;
  
  // Read the vertical-cross image
  int len = w * h * pSrcinfo->ibpp;
  float * envimg = new float [len];
  readoneimage( envimg, fullname, *pSrcinfo, Dstinfo );
  
  // cut the vertical-cross image into six cube faces
  for ( fn=0; fn<pSrcinfo->ifacecnt; fn++ )
    cubeface[fn] = new float [size*size*pSrcinfo->ibpp];
  float *img = new float [size*size*pSrcinfo->ibpp]; // temp variable
  // cube[0] - xp
  int index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy(cubeface[0]+index, envimg+((size+i)*w+j)*pSrcinfo->ibpp, pSrcinfo->ibpp*sizeof(float));
      index += pSrcinfo->ibpp;
    }
  }
  // cube[1] - zn
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy(cubeface[1]+index, envimg+((4*size-i-1)*w+(2*size-j-1))*pSrcinfo->ibpp, pSrcinfo->ibpp*sizeof(float));
      index += pSrcinfo->ibpp;
    }
  }
  // cube[2] - xn
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy(cubeface[2]+index, envimg+((size+i)*w+(j+2*size))*pSrcinfo->ibpp, pSrcinfo->ibpp*sizeof(float));
      index += pSrcinfo->ibpp;
    }
  }
  // cube[3] - zp
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy(cubeface[3]+index, envimg+((size+i)*w+(j+size))*pSrcinfo->ibpp, pSrcinfo->ibpp*sizeof(float));
      index += pSrcinfo->ibpp;
    }
  }
  // cube[4] - yp -- rotate 270 degrees counter-clockwise
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy(img+index, envimg+(i*w+(j+size))*pSrcinfo->ibpp, pSrcinfo->ibpp*sizeof(float));
      index += pSrcinfo->ibpp;
    }
  }
  index = 0;
  for ( i=size-1; i>=0; i-- )
  {
		for ( j=0; j<size; j++ )
    {
			memcpy(cubeface[4]+(j*size+i)*pSrcinfo->ibpp, img+index, pSrcinfo->ibpp*sizeof(float));
      index += pSrcinfo->ibpp;
    }
  }
  // cube[5] - yn -- rotate 90 degrees counter-clockwise
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy(img+index, envimg+((2*size+i)*w+(j+size))*pSrcinfo->ibpp, pSrcinfo->ibpp*sizeof(float));
      index += pSrcinfo->ibpp;
    }
  }
  index = 0;
  for ( i=0; i<size; i++ )
  {
		for ( j=size-1; j>=0; j-- )
    {
			memcpy(cubeface[5]+(j*size+i)*pSrcinfo->ibpp, img+index, pSrcinfo->ibpp*sizeof(float));
      index += pSrcinfo->ibpp;
    }
  }  
  delete [] img;
  delete [] envimg;
    
  if ( image ) {
    tgafree(image);
  }
  return true;
}

//
// Read longitude-latitude image
//
// Note the naming of longitude-latitude image should be like 
//   "imagename.ppm"
//
bool readplane( float ***fSrcimage, MYIMAGEINFO *pSrcinfo, MYIMAGEINFO &Dstinfo, char *imagename)
{
  int w, h;
  gliGenericImage *image=NULL;
  char fullname[FILE_NAME_LEN];  
  unsigned char *ppmimg = NULL;

  pSrcinfo->ibpp = 3;  
  w = h = 0;
  // read image width & height
  switch ( pSrcinfo->type ) {
  case _PPM:
    sprintf(fullname, "%s%s", imagename, ".ppm");
    get_ppm_size(fullname, w, h);
    if ( w == 0 ) {
      printf( "No such image:%s!\n", fullname );
      return false;
    }
    break;
  case _PFM:
    sprintf(fullname, "%s%s", imagename, ".pfm");
    get_pfm_size(fullname, w, h);
    if ( w == 0 ) {
      printf( "No such image:%s!\n", fullname );
      return false;
    }
    break;
  case _TGA:
    sprintf(fullname, "%s%s", imagename, ".tga");
    image = gliReadTGA(fullname);
    if ( image == NULL ) {
      printf( "No such image:%s!\n", fullname );
      return false;
    }
    w = image->width;
    h = image->height;
    pSrcinfo->ibpp = image->components;
    break;
  }

  pSrcinfo->iwidth = w; 
  pSrcinfo->iheight = h; 

  // read source image
  int len = w * h * pSrcinfo->ibpp;
  float * envimg = new float [len];
  readoneimage(envimg, fullname, *pSrcinfo, Dstinfo);

  *fSrcimage[0] = envimg;        
  pSrcinfo->isize = 0;
  if ( image )
    tgafree(image);
  return true;
}

//
// Read healpix/rhombic dodecahedron image
//
// Note the naming of healpix/rhombic dodecahedron image should be like 
//   "imagename.hp.ppm"
//
bool readhealpix( float ***fSrcimage, MYIMAGEINFO *pSrcinfo, MYIMAGEINFO &Dstinfo, char *imagename)
{ 
	int w, h, size;
	gliGenericImage *image=NULL;
	char fullname[FILE_NAME_LEN];  
	unsigned char *ppmimg = NULL;
	float **hpface = *fSrcimage;

	pSrcinfo->ibpp = 3;  
	w = h = 0;
	// read image width & height
	switch ( pSrcinfo->type ) {
    case _PPM:
	  sprintf(fullname, "%s.hp%s", imagename, ".ppm");
	  get_ppm_size(fullname, w, h);
	  if ( w == 0 ) {
		  printf( "No such image:%s!\n", fullname );
		  return false;
	  }
	  break;
    case _PFM:
	  sprintf(fullname, "%s.hp%s", imagename, ".pfm");
	  get_pfm_size(fullname, w, h);
	  if ( w == 0 ) {
		  printf( "No such image:%s!\n", fullname );
		  return false;
	  }
	  break;
    case _TGA:
	  sprintf(fullname, "%s.hp%s", imagename, ".tga");
	  image = gliReadTGA(fullname);
	  if ( image == NULL ) {
		  printf( "No such image:%s!\n", fullname );
		  return false;
	  }
	  w = image->width;
	  h = image->height;
	  pSrcinfo->ibpp = image->components;
	  break;
	}

	size = w/3;
	pSrcinfo->iwidth = w; 
	pSrcinfo->iheight = h; 
	pSrcinfo->isize = size;

	int tilenum2face[] = {1, 12, 5, 6, 2, 9, 10, 7, 3, 4, 11, 8};  
	if (pSrcinfo->format == SPH_RHOMBIC)
	{
		tilenum2face[0] = 2;  
		tilenum2face[1] = 11;
		tilenum2face[2] = 7;
		tilenum2face[3] = 6; 
		tilenum2face[4] = 1; 
		tilenum2face[5] = 10;
		tilenum2face[6] = 9;
		tilenum2face[7] = 5;
		tilenum2face[8] = 4;
		tilenum2face[9] = 3;
		tilenum2face[10] = 12;
		tilenum2face[11] = 8;
	}
	
	// read source image
	int len = w * h * pSrcinfo->ibpp;
	float * envimg = new float [len];
	readoneimage(envimg, fullname, *pSrcinfo, Dstinfo);

	// cut 12 single healpix faces
	for ( int fn=0; fn<pSrcinfo->ifacecnt; fn++ )
		hpface[fn] = new float [size*size*pSrcinfo->ibpp];
	
	for ( int tile = 0; tile < pSrcinfo->ifacecnt; tile ++ )
	{
		int facenum = tilenum2face[tile]-1;
		int offset = (tile/3) * (size * size * 3) + (tile%3) * size;
		for ( int i=0; i<size; i++ )
			for ( int j=0; j<size; j++ )
			{
				int localindex = (i * size + j) * pSrcinfo->ibpp;
				int pixindex = (offset + i * size * 3 + j) * pSrcinfo->ibpp;
				memcpy(&hpface[facenum][localindex], &envimg[pixindex], sizeof(float)*pSrcinfo->ibpp);
			}
	}
	
	delete [] envimg;	

	if ( image )
		tgafree(image);

	return true;
}

///////////////////////////////////////////////////////////////////
//// Write image
//
// Write one image
//
bool writeoneimage( float *fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *filename )
{
  int i, j, temp;
  int size = Dstinfo.isize;
  int len = Dstinfo.iheight * Dstinfo.iwidth * Dstinfo.ibpp;
  unsigned char *dstimage = NULL;
  gliGenericImage *image = NULL;

  if ( fDstimage == NULL || filename == NULL) {
    return false;
  }

  // Pfm --> ppm, tga, exposure(1/2.2) for gamma correction
  if ( (Srcinfo.type == _PFM) && ( Dstinfo.type == _PPM || Dstinfo.type == _TGA ) ) {
    for ( i=0; i<len; i++ ) {
      fDstimage[i] = float(pow(double(fDstimage[i]), 1.0/2.2));
    }
  }

  switch ( Dstinfo.type ) {
  case _PPM:
    if ( Dstinfo.ibpp == 4 ) {
      printf("Only support 3 channels!\n");
      return false;
    }
    dstimage = new unsigned char [len];    
    for ( i=0; i<len; i++ ) {
      temp = clampscale(fDstimage[i], 255.f);
      dstimage[i] = unsigned char(temp);
    }
    write_ppm(filename, dstimage, Dstinfo.iheight, Dstinfo.iwidth);
    delete [] dstimage;
    break;
  case _PFM:
    if ( Dstinfo.ibpp == 4 ) {
      printf("Only support 3 channels!\n");
      return false;
    }
     write_pfm(filename, fDstimage, Dstinfo.iheight, Dstinfo.iwidth);
    break;
  case _TGA:
    image = new gliGenericImage;
    image->cmap = NULL;
    image->components = Dstinfo.ibpp;
    image->height = Dstinfo.iheight;
    image->width = Dstinfo.iwidth;
    image->pixels = new unsigned char [ len ];      
    int lindex = (Dstinfo.iheight-1) * Dstinfo.iwidth * Dstinfo.ibpp;
    int offset, index=0;
    for (i=0; i<Dstinfo.iheight; i++)
    {
      offset = lindex;
      for (j=0; j<Dstinfo.iwidth; j++)
      {
        temp = clampscale(fDstimage[index], 255.f);
        image->pixels[offset+2] = unsigned char(temp);
        temp = clampscale(fDstimage[index+1], 255.f);
        image->pixels[offset+1] = unsigned char(temp);
        temp = clampscale(fDstimage[index+2], 255.f);
        image->pixels[offset]   = unsigned char(temp);
        if ( Dstinfo.ibpp == 4 ) {
          temp = clampscale(fDstimage[index+3], 255.f);
          image->pixels[offset+3]   = unsigned char(temp);
        }
        index += Dstinfo.ibpp;
        offset += Dstinfo.ibpp;
      }
      lindex -= Dstinfo.iwidth * Dstinfo.ibpp;
    }
    gltWriteTGA(filename, image);
    tgafree(image);
    break;
  } 
  return true;
}

//
// Write 6 cube images
// 
// Note the naming of 6 cubemap images will be like 
//   "imagename.xp.ppm", "imagename.zn.ppm", "imagename.xn.ppm",
//   "imagename.zp.ppm", "imagename.yp.ppm", "imagename.yn.ppm".
//
bool writecube( float **fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *imagename )
{
  char fullname[FILE_NAME_LEN];
  char *suffix[] = {"xp", "zn", "xn", "zp", "yp", "yn"};  

  if ( fDstimage == NULL || imagename == NULL) {
    return false;
  }

  for ( int fn=0; fn<Dstinfo.ifacecnt; fn++ ) {
    switch ( Dstinfo.type ) {
      case _PPM:
        sprintf(fullname, "%s.%s%s", imagename, suffix[fn], ".ppm");
        break;
      case _PFM:
        sprintf(fullname, "%s.%s%s", imagename, suffix[fn], ".pfm");
        break;
      case _TGA:
        sprintf(fullname, "%s.%s%s", imagename, suffix[fn], ".tga");
        break;
    }
    if ( fn == 4 ) {
      // rotate 270 degrees
      imagerotate( fDstimage[fn], Dstinfo.isize, Dstinfo.isize, Dstinfo.ibpp, 180 );
    }
    else if ( fn == 5 ) {
      // rotate 90 degrees
      imagerotate( fDstimage[fn], Dstinfo.isize, Dstinfo.isize, Dstinfo.ibpp, 0 );
    }
    if ( !writeoneimage( fDstimage[fn], Srcinfo, Dstinfo, fullname ) )
      return false;
  }
  
  puts(fullname);
  return true;
}

//
// Write 6 cube faces into vertical-cross format
//
// Note the naming of vertical-cross cubemap image will be like 
//   "imagename_cross.ppm"
//
bool writecubevert( float **fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *imagename )
{
  char fullname[FILE_NAME_LEN];
  bool res = false;

  if ( fDstimage == NULL || imagename == NULL) {
    return false;
  }

  int i, j;
  int size = Dstinfo.isize;
  int bpp = Dstinfo.ibpp;
  int w = size*3;
  int h = size*4;
  int len = w * h * Dstinfo.ibpp;
  float * envimg = new float [len];
  memset(envimg, 0, sizeof(float)*len);
  float *img = new float [size*size*bpp]; // temp variable

  // cube[0] - xp
  int index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy(envimg+((size+i)*w+j)*bpp, fDstimage[0]+index, bpp*sizeof(float));
      index += bpp;
    }
  }
  // cube[1] - zn
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy(envimg+((4*size-i-1)*w+(2*size-j-1))*bpp, fDstimage[1]+index, bpp*sizeof(float));
      index += bpp;
    }
  }
  // cube[2] - xn
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy( envimg+((size+i)*w+(j+2*size))*bpp, fDstimage[2]+index, bpp*sizeof(float));
      index += bpp;
    }
  }
  // cube[3] - zp
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy( envimg+((size+i)*w+(j+size))*bpp, fDstimage[3]+index, bpp*sizeof(float));
      index += bpp;
    }
  }
  // cube[4] - yp -- rotate 270 degrees counter-clockwise
  index = 0;
  for ( i=0; i<size; i++ )
  {
		for ( j=0; j<size; j++)
    {
			memcpy(img+index, fDstimage[4]+(i*size+j)*bpp, bpp*sizeof(float));
      index += bpp;
    }
  }
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy( envimg+(i*w+(j+size))*bpp, img+index, bpp*sizeof(float));
      index += bpp;
    }
  } 
  // cube[5] - yn -- rotate 90 degrees counter-clockwise
  index = 0;
  for ( i=size-1; i>=0; i--)
  {
		for ( j=size-1; j>=0; j-- )
    {
			memcpy(img+index, fDstimage[5]+(i*size+j)*bpp, bpp*sizeof(float));
      index += bpp;
    }
  }  
  index = 0;
  for (i=0; i<size; i++)
  {
    for (j=0; j<size; j++)
    {
      memcpy( envimg+((2*size+i)*w+(j+size))*bpp, img+index, bpp*sizeof(float));
      index += bpp;
    }
  }
  
  switch ( Dstinfo.type )
  {
    case _PPM:
      sprintf(fullname, "%s%s", imagename, "_cross.ppm");
    break;
    case _PFM: 
      sprintf(fullname, "%s%s", imagename, "_cross.pfm");      
    break;  
    case _TGA:
      sprintf(fullname, "%s%s", imagename, "_cross.tga");      
    break;
  }
  res = writeoneimage( envimg, Srcinfo, Dstinfo, fullname ); 
  
  delete [] img;
  delete [] envimg;

  puts(fullname);
  return res;
}
      
//
// Write a longitude-latitude image
//
// Note the naming of longitude-latitude image will be like 
//   "imagename.ppm"
//
bool writeplane( float **fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *imagename )
{
  char fullname[FILE_NAME_LEN];
  if ( fDstimage == NULL || imagename == NULL) {
    return false;
  }
  switch ( Dstinfo.type )
  {
    case _PPM:
      sprintf(fullname, "%s%s", imagename, ".ppm");
    break;
    case _PFM: 
      sprintf(fullname, "%s%s", imagename, ".pfm");      
    break;  
    case _TGA:
      sprintf(fullname, "%s%s", imagename, ".tga");      
    break;
  }
  if ( !writeoneimage( fDstimage[0], Srcinfo, Dstinfo, fullname ) ) {
    return false;
  }

  puts(fullname);
  return true;
}

//
// Write healpix/rhombic dodecahedron image
//
// Note the naming of healpix/rhombic dodecahedron image will be like 
//   "imagename.hp.ppm"
//
bool writehealpix( float **fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *imagename )
{
  if ( fDstimage == NULL || imagename == NULL) {
    return false;
  }

  int tilenum2face[] = {1, 12, 5, 6, 2, 9, 10, 7, 3, 4, 11, 8};
  if (Dstinfo.format == SPH_RHOMBIC)
  {
	  tilenum2face[0] = 2;  
	  tilenum2face[1] = 11;
	  tilenum2face[2] = 7;
	  tilenum2face[3] = 6; 
	  tilenum2face[4] = 1; 
	  tilenum2face[5] = 10;
	  tilenum2face[6] = 9;
	  tilenum2face[7] = 5;
	  tilenum2face[8] = 4;
	  tilenum2face[9] = 3;
	  tilenum2face[10] = 12;
	  tilenum2face[11] = 8;
  }
  char fullname[FILE_NAME_LEN];
  bool res = false;

  int size = Dstinfo.isize;
  int bpp = Dstinfo.ibpp;
  int len = size * 3 * size * 4 * bpp;  

  float *healtex = new float[len];
  memset(healtex, 0, len * sizeof(float));  

  // Pack 12 separate faces into one image
  for ( int tile = 0; tile < Dstinfo.ifacecnt; tile ++ )
  {
    int facenum = tilenum2face[tile]-1;
    int offset = (tile/3) * (size * size * 3) + (tile%3) * size;
    for ( int i=0; i<size; i++ )
      for ( int j=0; j<size; j++ )
      {
        int localindex = (i * size + j) * bpp;
        int pixindex = (offset + i * size * 3 + j) * bpp;
        healtex[pixindex] = fDstimage[facenum][localindex];
        healtex[pixindex+1] = fDstimage[facenum][localindex+1];
        healtex[pixindex+2] = fDstimage[facenum][localindex+2];
        if ( bpp == 4 )
          healtex[pixindex+3] = fDstimage[facenum][localindex+3];
      }
  }

  // Save the image
  switch ( Dstinfo.type )
  {
    case _PPM:
      sprintf(fullname, "%s%s", imagename, ".hp.ppm");
    break;
    case _PFM: 
      sprintf(fullname, "%s%s", imagename, ".hp.pfm");      
    break;  
    case _TGA:
      sprintf(fullname, "%s%s", imagename, ".hp.tga");      
    break;
  }
  res = writeoneimage( healtex, Srcinfo, Dstinfo, fullname ); 

  puts(fullname);
  delete [] healtex;
  return res;
}