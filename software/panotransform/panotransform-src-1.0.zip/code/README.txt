**************************************************
* Panorama Transformation Software               *
* Version 1.0                                    *
* December 23, 2009                              *
**************************************************

The software converts panorama images between different spherical mappings.
Besides "cubemap", "longitude-latitude map", the software demonstrates the
use of four (near-) equal area spherical mappings, including "HEALPix", 
"isocube", "rhombic dodecahedron map", and "unicube". This program is free
sofeware. You can use it and/or modify it and/or redistribute it provided 
that you read and agree to the license agreement terms specified in the 
accompanying LICENSE.TXT. 

Instructions for compiling and using the software are included below.


======================= INSTRUCTIONS FOR CITATIONS ========================

Since this software builds on the algorithms presented in several different
papers, you should follow the instructions about proper citing below.

(a) If you use the HEALPix spherical mapping, you should cite the following paper:
      
    [1] Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung, 
        Spherical Q2tree for Sampling Dynamic Environment Sequences, 
        in Proc. of Eurographics Symposium on Rendering 2005 (EGSR'05), 
        Konstanz, Germany, June 2005, pp. 21-30.     
        
    [2] K.M. G��rski, E. Hivon, A.J. Banday, B.D. Wandelt, F.K. Hansen, 
        M. Reinecke, and M. Bartelmann, HEALPix: A Framework for High-resolution
        Discretization and Fast Analysis of Data Distributed on the Sphere, 
        Ap.J., 622, 759-771, 2005.
    
    The HEALPix mapping was proposed in Citation [2]. It was first introduced to 
    graphics community in Citation [1].
  
    The file healpix.c included here is a slight modification of the files,
    ang2pix_nest.c and pix2ang_nest.c in the package HEALPix_1.22, available from
    http://omega.jpl.nasa.gov/healpixSoftwareGetHealpix.shtml
            
(b) If you use the Isocube spherical mapping, you should cite the following paper:
      
    [3] Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung, 
        Isocube: Exploiting the Cubemap Hardware, 
        IEEE Transactions on Visualization and Computer Graphics (TVCG), 
        Vol. 13, No. 4, pp. 720-731, 2007.
        
(c) If you use the rhombic dodecahedron mapping, you should cite the following paper:
      
    [4] Chi-Wing Fu, Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung, 
        The Rhombic Dodecahedron Map: An Efficient Scheme for Encoding Panoramic
        Video, IEEE Transactions on Multimedia (TMM), 
        Vol. 11, No. 4, pp. 634-644, June 2009. 
        
(d) If you use the Unicube spherical mapping, you should cite the following paper:
      
    [5] Tze-Yiu Ho, Liang Wan, Ping-Man Lam, Chi-Sing Leung, and Tien-Tsin Wong, 
        Unicube for Dynamic Environment Mapping, 
        IEEE Transactions on Visualization and Computer Graphics (TVCG 2010), 
        to be published. 
        
                        
============================= INSTRUCTIONS FOR USAGE =================================
A Visual Stadio .Net 2003 solution file is included. Compiling the solution file
will generate an executable, panotransform.exe.


Here is a brief description of how to use the code; see also the software webpage
panotransform.html.

(a) Use the mapping functions

Each spherical map is provided with two functions. Suppose a pixel in a given
spherical map is represented by the local coordinates (facenum, ix, iy). The 
function "xxx_pix2ang" maps the pixel from local coodinates of the 2D spherical
map to spherical coordinates (theta, phi). The other function "xxx_ang2pix" maps
one pixel from spherical coordinates to local coordinates of the 2D spherical map.
The followings shows the two functions for "rhombic dodecahedron map":

void rd_pix2ang(long nside, int facenum, double ix, double iy, double *theta, double *phi);

void rd_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy);


(b) Use the executable 

# example 1
convert environment map from cubemap to isocube, both in vertical cross format. 
Suppose the input image is "example_cross.ppm", the output image will be "pano_cross.ppm".

   panotransform.exe /it ppm /if cv /ot ppm /of iv /s 160 /i example

# example 2
convert environment map from cubemap to unicube map in six separate faces. 
Suppose the input image is "example_cross.ppm", the output images will be "pano.xn.ppm",
"pano.zn.ppm", "pano.xp.ppm", "pano.zp.ppm", "pano.yn.ppm", "pano.yp.ppm".

   panotransform.exe /it ppm /if cv /ot ppm /of u /s 160 /i example

# example 3
convert environment map from cubemap to healpix format. 
Suppose the input image is "example_cross.ppm", the output image is "pano.hp.ppm".

   panotransform.exe /it ppm /if cv /ot ppm /of h /s 160 /i example 


 