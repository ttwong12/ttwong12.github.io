#ifndef _READIMAGE_H
#define _READIMAGE_H

#include "panotransform.h"

bool readcube( float ***fSrcimage, MYIMAGEINFO *pSrcinfo, MYIMAGEINFO &Dstinfo, char *imagename );

bool readcubevert( float ***fSrcimage, MYIMAGEINFO *pSrcinfo, MYIMAGEINFO &Dstinfo, char *imagename );

bool readplane( float ***fSrcimage, MYIMAGEINFO *pSrcinfo, MYIMAGEINFO &Dstinfo, char *imagename );

bool readhealpix( float ***fSrcimage, MYIMAGEINFO *pSrcinfo, MYIMAGEINFO &Dstinfo, char *imagename);


bool writeoneimage( float *fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *filename );

bool writecube( float **fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *imagename );

bool writecubevert( float **fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *imagename );
      
bool writeplane( float **fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *imagename );

bool writehealpix( float **fDstimage, MYIMAGEINFO &Srcinfo, MYIMAGEINFO &Dstinfo, char *imagename );


#endif