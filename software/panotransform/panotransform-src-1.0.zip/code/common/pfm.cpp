/* pfm.cpp */
/*
* This program reads/writes image in the format of PFM.
*
* Copyright (c) 2007-2010, The Chinese University of Hong Kong
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*  * Redistributions of source code must retain the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer.
*  * Redistributions in binary form must reproduce the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer in the documentation and/or other 
*    materials provided with the distribution.
*  * Neither the name of The Chinese University of Hong Kong nor the
*    names of its contributors may be used to endorse or promote products
*    derived from this software without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
* ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
* ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
* POSSIBILITY OF SUCH DAMAGE.
*
*/

#include <stdio.h>
#include <string.h>

#include "pfm.h"

bool get_pfm_size(const char *filename, int& w, int& h)
{
  FILE *fp = fopen(filename,"rb");
  if ( fp == NULL ) 
  {
    printf("Error reading file %s\n",filename);
    return false;
  }
  char buff[128];

  fscanf(fp, "%s\r", buff);
  while(buff[0] == '#') fgets(buff, 128, fp);
  if(strncmp(buff, "PF", 2))
    { fclose(fp); return false; }

  fscanf(fp, "%s", buff);
  while(buff[0] == '#') fgets(buff, 128, fp);
  sscanf(buff, "%d", &w);    

  fscanf(fp, "%s\r", buff);
  while(buff[0] == '#') fgets(buff, 128, fp);
  sscanf(buff, "%d", &h);    
        
  fclose(fp);
  return true;
}

// pimg should be allocated outside
bool read_pfm(const char *file, float * pimg)
{
	FILE *fp = fopen(file,"rb");
	if ( fp == NULL ) return false;
	char buff[128];

	fscanf(fp, "%s\r", buff);
  while(buff[0] == '#') fgets(buff, 128, fp);
  if(strncmp(buff, "PF", 2))
  { fclose(fp); return false; }
  
  int w, h;
  fscanf(fp, "%s", buff);
  while(buff[0] == '#') fgets(buff, 128, fp);
  sscanf(buff, "%d", &w);    
  
  fscanf(fp, "%s\r", buff);
  while(buff[0] == '#') fgets(buff, 128, fp);
  sscanf(buff, "%d", &h);    

  float tomin;
	fscanf(fp, "%f", &tomin);
  buff[0] = fgetc(fp);
  
  if ( tomin < 0 )
  {
    int index = w*(h-1)*3;
    for (int i=0; i<h; i++)
    {
      for (int j=0; j<w*3; j+=3)
      {
        fread(pimg+index+j, sizeof(float), 1, fp);
        fread(pimg+index+j+1, sizeof(float), 1, fp);
        fread(pimg+index+j+2, sizeof(float), 1, fp);
      }
      index -= w*3;
    }
  }
  else
	  fread(pimg, sizeof(float), w * h * 3, fp);

  fclose(fp);
  return true;
}

bool write_pfm(const char*filename, float*pimg, int h, int w)
{

  int i,j, index;
  
  FILE *fp = fopen(filename,"wb");
  if ( fp == NULL )
  {
     fclose(fp);
     return false;
  }

  fprintf(fp, "PF\r");
  fprintf(fp, "%d %d\r", w, h);
  fprintf(fp, "%f\r", -1.0);

  index = w*(h-1)*3;
  for (i=0; i<h; i++)
  {
    for (j=0; j<w*3; j+=3)
    {
      fwrite(pimg+index+j, sizeof(float), 1, fp);
      fwrite(pimg+index+j+1, sizeof(float), 1, fp);
      fwrite(pimg+index+j+2, sizeof(float), 1, fp);
    }
    index -= w*3;
  }
  fclose(fp);

  return true;
}


