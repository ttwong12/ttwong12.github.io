#ifndef PPM_H
#define PPM_H

void read_ppm(const char *filename, unsigned char * pimg);
void get_ppm_size(const char *filename, int& w, int& h);
void write_ppm(const char *filename, unsigned char*img, int h, int w); 

#endif