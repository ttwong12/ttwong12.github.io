#ifndef _PANO_H
#define _PANO_H

#define FILE_NAME_LEN 256
#define M_2PI       6.28318530717958647692

typedef enum {_PPM, _PFM, _TGA} IMG_TYPE;
typedef enum {
	SPH_CUBIC, 
	SPH_CUBEVERT, 
	SPH_UCM, 
	SPH_UCMVERT, 
	SPH_ISOCUBE, 
	SPH_ISOCUBEVERT, 
	SPH_HEALPIX, 
	SPH_RHOMBIC,
	SPH_PLANE, 
	SPH_MIRROR, 
	SPH_MIRRORCLOSE, 
	SPH_PROBE} SPH_FORMAT;

typedef struct _MYIMAGEINFO {
  int   ifacecnt;  // face cnt for source image
  int   iwidth;    // width of source image
  int   iheight;   // height of source image
  int   isize;     // size of base faces (cubic, healpix)
  int   ibpp;      // bpp of source image
  IMG_TYPE  type;      // image type 
  SPH_FORMAT format;   // image format  
} MYIMAGEINFO;


typedef struct _VECTOR3D {
  double x;
  double y;
  double z;
  double w;
} VECTOR3D;

#endif