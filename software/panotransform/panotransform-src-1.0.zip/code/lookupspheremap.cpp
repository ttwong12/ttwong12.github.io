/* lookupspheremap.cpp */
/*
 * This program looks up one pixel in spherical maps.
 *
 * Copyright (c) 2007-2010, The Chinese University of Hong Kong
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice and publication information, this list of conditions and 
 *    the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice and publication information, this list of conditions and 
 *    the following disclaimer in the documentation and/or other 
 *    materials provided with the distribution.
 *  * Neither the name of The Chinese University of Hong Kong nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
 * ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

#define _USE_MATH_DEFINES
#include <math.h>

#include <memory.h>

#include "lookupspheremap.h"
#include "cubic.h"
#include "plane.h"
#include "ucm.h"
#include "healpix.h"
#include "isocube.h"
#include "rhombic.h"

//////////////////////////////////////////////////////////////////////////
// Get the pixel color using bilinear interpolation.
// Note the discontinuity at face boundaries is not handled.
//
void samplebilinear(float* map, int width, int height, int bpp,
					double u, double v, float *prgb )
{
	int x1 = (int)floor(u-0.5);
	int y1 = (int)floor(v-0.5);
	double dx = u -0.5- x1;
	double dy = v -0.5- y1;

	double r, g, b, a;
	r = g = b = 0.f;
	a = 1.f;
	if ( (x1 >= 0) && (x1 < width-1) && (y1 >= 0) && (y1 < height-1) )	{
		// body 
		double dx_1 = 1 - dx;
		double dy_1 = 1 - dy;

		int idx1 = (y1 * width + x1) * bpp;
		int idx2 = (y1 * width + x1 + 1) * bpp;
		int idx3 = ((y1 + 1) * width + x1) * bpp;
		int idx4 = ((y1 + 1) * width + x1 + 1) * bpp;

		double r1 = map[idx1] * dx_1 + map[idx2] * dx;
		double g1 = map[idx1+1] * dx_1 + map[idx2+1] * dx;
		double b1 = map[idx1+2] * dx_1 + map[idx2+2] * dx;
		double r2 = map[idx3]* dx_1 + map[idx4] * dx;
		double g2 = map[idx3+1] * dx_1 + map[idx4+1] * dx;
		double b2 = map[idx3+2] * dx_1 + map[idx4+2] * dx;
		double a1, a2;
		if ( bpp == 4 ) {
			a1 = map[idx1+3] * dx_1 + map[idx2+3] * dx;
			a2 = map[idx3+3] * dx_1 + map[idx4+3] * dx;
		}

		r = r1 * dy_1 + r2 * dy;
		g = g1 * dy_1 + g2 * dy;
		b = b1 * dy_1 + b2 * dy;	
		if ( bpp == 4 ) {
			a = a1 * dy_1 + a2 * dy;	
		}
	}
	else if ( (x1 >= 0) && (x1 < width-1) )
	{	// y edge
		if ( y1 < 0 ) 	y1 = 0;
		if ( y1 > height-1 )	y1 = height - 1;
		double dx_1 = 1 - dx;
		int idx1 = (y1 * width + x1) * bpp;
		int idx2 = (y1 * width + x1 + 1) * bpp;

		r = map[idx1] * dx_1 + map[idx2] * dx;
		g = map[idx1+1] * dx_1 + map[idx2+1] * dx;
		b = map[idx1+2] * dx_1 + map[idx2+2] * dx;
		if ( bpp == 4 ) {
			a = map[idx1+3] * dx_1 + map[idx2+3] * dx;
		}
	}
	else if ( (y1 >= 0) && (y1 < height-1) )
	{	// x edge
		if ( x1 < 0 ) x1 = 0;
		if ( x1 > width-1 ) x1 = width - 1;
		double dy_1 = 1 - dy;
		int idx3 = (y1 * width + x1) * bpp;
		int idx4 = ((y1 + 1) * width + x1) * bpp;

		r = map[idx3] * dy_1 + map[idx4] * dy;
		g = map[idx3+1] * dy_1 + map[idx4+1] * dy;
		b = map[idx3+2] * dy_1 + map[idx4+2] * dy;
		if ( bpp == 4 ) {
			a = map[idx3+3] * dy_1 + map[idx4+3] * dy;
		}
	}
	else
	{	// corners
		if ( x1 < 0 ) 	x1 = 0;
		if ( x1 > width-1 ) 	x1 = width - 1;
		if ( y1 < 0 )   y1 = 0;
		if ( y1 > height-1 )   y1 = height - 1;

		int idx1 = (y1 * height + x1) * bpp;
		r = map[idx1];
		g = map[idx1+1];
		b = map[idx1+2];
		if ( bpp == 4 ) {
			a = map[idx1+3];
		}
	}
	*prgb = (float)r;
	*(prgb+1) = (float)g;
	*(prgb+2) = (float)b;
	if ( bpp == 4 ) {
		*(prgb+3) = (float)a;
	}
}


//////////////////////////////////////////////////////////////////////////
// Lookup the pixel in the cubemap for the direction (theta, phi)
//
void lookupcube(float** cubeface, int size, int bpp, 
			 double theta, double phi, float *prgb )   
{
   int facenum;
   double ix, iy;
   cube_ang2pix(size, theta, phi, &facenum, &ix, &iy);
   samplebilinear(cubeface[facenum], size, size, bpp, ix, iy, prgb);
}


//////////////////////////////////////////////////////////////////////////
// Lookup the pixel in the mirror ball for the direction (theta, phi)
//
void lookupmirror(float** mirrormap, int width, int height, int bpp, 
			   double theta, double phi, float *prgb )
{
	double u, v;
	double xcen, ycen;
	xcen = (double)width/2.0;
	ycen = (double)height/2.0;
	// mirror ball
	u = sin(theta/2.0)*cos(phi);
	v = sin(theta/2.0)*sin(phi);

	if ( u*u + v*v > 1 )
		memset( prgb, 0, sizeof(float)*bpp);
	else
	{
		u = xcen * u + xcen;
		v = ycen * v + ycen;
		samplebilinear(mirrormap[0], width, height, bpp, u, v, prgb );
	}
}


//////////////////////////////////////////////////////////////////////////
// Lookup the pixel in the mirror ball closeup for the direction (theta, phi)
//
void lookupmirrorcloseup(float** mirrormap, int width, int height, int bpp, 
					  double theta, double phi, float *prgb )
{
	double u, v;
	double xcen, ycen;
	xcen = (double)width/2.0;
	ycen = (double)height/2.0;

	// mirror ball closeup
	u = sin(theta/2.0)*cos(phi)*sqrt(2.0);
	v = sin(theta/2.0)*sin(phi)*sqrt(2.0);

	if ( u*u + v*v > 1 )
		memset( prgb, 0, sizeof(float)*bpp);
	else
	{
		u = xcen * u + xcen;
		v = ycen * v + ycen;
		samplebilinear(mirrormap[0], width, height, bpp, u, v, prgb );
	}
}


//////////////////////////////////////////////////////////////////////////
// Lookup the pixel in the light probe for the direction (theta, phi)
//
void lookupprobe(float** mirrormap, int width, int height, int bpp, 
			  double theta, double phi, float *prgb )
{
	double u, v;
	double xcen, ycen;
	xcen = (double)width/2.0;
	ycen = (double)height/2.0;

	// light probe
	u = theta/M_PI * cos(phi);
	v = theta/M_PI * sin(phi);

	if ( u*u + v*v > 1 )
		memset( prgb, 0, sizeof(float)*bpp);
	else
	{
		u = xcen * u + xcen;
		v = ycen * v + ycen;
		samplebilinear(mirrormap[0], width, height, bpp, u, v, prgb );
	}
}


//////////////////////////////////////////////////////////////////////////
// Lookup the pixel in the longitude-latitude map for the direction (theta, phi)
//
void lookupplane(float** planemap, int width, int height, int bpp, 
			   double theta, double phi, float *prgb )
{
	double u, v;
	plane_ang2pix(width, height, theta, phi, &u, &v);
	samplebilinear(planemap[0], width, height, bpp, u, v, prgb );
}


//////////////////////////////////////////////////////////////////////////
// Lookup the pixel in the unicube map for the direction (theta, phi)
//
void lookupucm(float** cubeface, int size, int bpp, 
			 double theta, double phi, float *prgb )   
{
	int facenum;
	double ix, iy;
	ucm_ang2pix(size, theta, phi, &facenum, &ix, &iy);
	samplebilinear(cubeface[facenum], size, size, bpp, ix, iy, prgb);
}


//////////////////////////////////////////////////////////////////////////
// Lookup the pixel in the HEALPix map for the direction (theta, phi)
//
void lookuphealpix(float** hpmap, int size, int bpp, 
			double theta, double phi, float *prgb ) 
{
	int facenum;
	double ix, iy;
	hp_ang2pix(size, theta, phi, &facenum, &ix, &iy);
	samplebilinear(hpmap[facenum], size, size, bpp, ix, iy, prgb);
}


//////////////////////////////////////////////////////////////////////////
// Lookup the pixel in the isocube map for the direction (theta, phi)
//
void lookupisocube(float** cubeface, int size, int bpp, 
			 double theta, double phi, float *prgb )   
{
	int facenum;
	double ix, iy;
	isocube_ang2pix(size, theta, phi, &facenum, &ix, &iy);
	samplebilinear(cubeface[facenum], size, size, bpp, ix, iy, prgb);
}


//////////////////////////////////////////////////////////////////////////
// Lookup the pixel in the rhombic dodecahedron map for the direction (theta, phi)
//
void lookuprhombic(float** rdmap, int size, int bpp, double theta, double phi, float *prgb )
{
	int facenum;
	double ix, iy;
	rd_ang2pix(size, theta, phi, &facenum, &ix, &iy);
	samplebilinear(rdmap[facenum], size, size, bpp, ix, iy, prgb);
}