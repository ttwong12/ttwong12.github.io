/* panotransform.cpp */
/*
 * This program converts panorama images between different spherical mappings.
 *
 * Copyright (c) 2007-2010, The Chinese University of Hong Kong
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice and publication information, this list of conditions and 
 *    the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice and publication information, this list of conditions and 
 *    the following disclaimer in the documentation and/or other 
 *    materials provided with the distribution.
 *  * Neither the name of The Chinese University of Hong Kong nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
 * ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 *
 * Usage:
 * panotransform /it [ppm/pfm/tga] 
 *               /if [c/cv/u/uv/i/iv/h/rd/p/b/m/r]
 *               /ot [ppm/pfm/tga]
 *               /of [c/cv/u/uv/i/iv/h/rd/p]
 *               /s size OR /w width /h height
 *               /i image1 [/x xrot1 /y yrot1 /z zrot1 /a weight1]
 *               /i image2 [/x xrot2 /y yrot2 /z zrot2 /a weight2]
 *               ...
 *
 * type "panotransform --help" to see the detailed explanations of parameters. 
 *
 */

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>

#define _USE_MATH_DEFINES
#include <math.h>

#include "panotransform.h"
#include "ioimage.h"

#include "cubic.h"
#include "plane.h"
#include "ucm.h"
#include "healpix.h"
#include "isocube.h"
#include "rhombic.h"
#include "lookupspheremap.h"

char  **g_cImagelist  = NULL;
VECTOR3D *g_pImageangle = NULL;
int  g_iImagecnt = 0;

// source images
float *** g_fSrcimages = NULL; // Imagecnt x facecnt x face2
MYIMAGEINFO g_Srcinfo;   // source image information

// destination image
float ** g_fDstimage = NULL; // destination image
MYIMAGEINFO g_Dstinfo;    // destination image information

////////////////////////////////////////////////////////////
// Declaration of user functions
//
void   printshortusage();
void   printfullusage();
IMG_TYPE   parsetype( char* param );
SPH_FORMAT parseformat( char* param );
void   parseimages( int argc, char **argv, int argind );

bool   readimages();
bool   panomerge();
bool   writeimage();
bool   panoface( float **pfSrcimage, MYIMAGEINFO &Srcinfo, VECTOR3D &Imageangle,
			  MYIMAGEINFO &Dstinfo,  float **pfDstimage);

void   myfree();

///////////////////////////////////////////////////////////
// Main function
// 
int main(int argc, char ** argv)
{
	if ( argc>=2 && strcmp( argv[1], "--help" ) == 0 )  {
		printfullusage(); return 1;
	}
    if ( argc < 13 )  {
        printshortusage();
		printf("Type --help to get detailed usage\n");
        return 1;
    }

    // Parse input parameters
    // source image type
    int argind = 1;
    if ( strcmp( argv[argind++], "/it" ) != 0 )  {
        printshortusage(); return 1;
    }  
    g_Srcinfo.type = parsetype( argv[argind++] );
    // source image format
    if ( strcmp( argv[argind++], "/if" ) != 0 )  {
        printshortusage(); return 1;
    }  
    g_Srcinfo.format = parseformat( argv[argind++] );
    // destination image type
    if ( strcmp( argv[argind++], "/ot" ) != 0 )  {
        printshortusage(); return 1;
    }  
    g_Dstinfo.type = parsetype( argv[argind++] );
    // destination image format
    if ( strcmp( argv[argind++], "/of" ) != 0 )  {
        printshortusage(); return 1;
    }  
    g_Dstinfo.format = parseformat( argv[argind++] );
    // destination size
    switch ( g_Dstinfo.format ) {
    case SPH_CUBIC:
    case SPH_CUBEVERT:    
	case SPH_UCM:
	case SPH_UCMVERT:
	case SPH_ISOCUBE:
	case SPH_ISOCUBEVERT:
    case SPH_HEALPIX:
	case SPH_RHOMBIC:
        if ( strcmp( argv[argind++], "/s" ) !=0 )  {
            printshortusage(); return 1;
        }  
        g_Dstinfo.isize = atoi( argv[argind++] );
        break;
    case SPH_PLANE:
        if ( strcmp( argv[argind++], "/w" ) !=0 ) {
            printshortusage(); return 1;
        }
        g_Dstinfo.iwidth = atoi( argv[argind++] );
        if ( strcmp( argv[argind++], "/h" ) !=0 ) {
            printshortusage(); return 1;
        }
        g_Dstinfo.iheight = atoi( argv[argind++] );
        break;
	default:
		printshortusage(); 
		return 1;
    }

    // Parse source images
    parseimages( argc, argv, argind );

    // Read source images
    if ( !readimages() ) {
        myfree();    return 1;
    }

    // Perform panomerge
    if ( !panomerge() ) {
        myfree();    return 1;
    }

    // Output the result
    if ( !writeimage() ) {
        myfree();    return 1;
    }

    // Release the buffer
    myfree();

    return 0;
}

//////////////////////////////////////////////////////////////////////////
// Print the command usage
//
void printshortusage()
{
	printf( "Usage: panotransform /it [ppm/pfm/tga]\n"  
		"                     /if [c/cv/u/uv/i/iv/h/rd/p/b/m/r]\n"
		"                     /ot [ppm/pfm/tga]\n"
		"                     /of [c/cv/u/uv/i/iv/h/rd/p]\n"
		"                     /s size OR /w width /h height\n"
		"                     /i image1 [/x xrot1 /y yrot1 /z zrot1 /a weight1]\n"
		"                     /i image2 [/x xrot2 /y yrot2 /z zrot2 /a weight2]\n"
		"                     ...\n"
		);
}

//////////////////////////////////////////////////////////////////////////
// Print the command usage
//
void printfullusage()
{
	printshortusage();
    printf("Parameters: \n"
		"#I/O options:\n"
		" /it : input file format  [ppm/pfm/tga]\n"
		" /ot : output file format [ppm/pfm/tga]\n"
		" /if : input panorama map\n"
		" /of : output panorama map\n"
		"#image format\n"
		" ppm : portable pixel map\n"
		" pfm : portable float map that supports HDR imaging\n"
		" tga : targa image\n"
		"#panorama format\n"
		"  c  : six-separate-face cubemap\n"
		"  cv : vertical cross cubemap\n"
		"  u  : six-separate-face unicube map\n"
		"  uv : vertical cross unicube map\n"
		"  i  : six-separate-face isocube map\n"
		"  iv : vertical cross isocube map\n"
		"  h  : fish-view healpix map\n"
		"  rd : rhombic dodecahedron map\n"
		"  p  : longitude-latitude map\n"
		"  b  : mirror ball\n"
		"  m  : mirror ball close-up\n"
		"  r  : light probe\n"
		"#resolution setting of target image\n"
		"  /s sets face resolution, used with c/cv/u/uv/i/iv/h\n"
		"  /w and /h set width and height, used with p\n"
		"#rotation settings (optional)\n"
		"  [/x xrot] rotates the source panorama around x axis by xrot degrees.\n"
		"#multiple source images\n"
		"  /i sets one source image\n"
		"  [/a weight] is the weighting factor to blend multiple source images.\n"
		"\n"
		"If the source image is MirrorBall, Mirror-Ball-Closeup, or LightProbe, we need to set"
        "/x 180 + /z 90 to get the converted image centered or /y 180 to get it upwards.\n" 
        );
}

//////////////////////////////////////////////////////////////////////////
// Parse the image type
//
IMG_TYPE parsetype( char* param )
{
    char buffer[256];
    IMG_TYPE type;

    strcpy(buffer, strlwr( param ) );
    if ( !strcmp( buffer, "ppm" ) )
        type = _PPM;
    else if ( !strcmp( buffer, "pfm" ) )
        type = _PFM;
    else if ( !strcmp( buffer, "tga" ) )
        type = _TGA;
    else 
    {
        printshortusage(); exit( 1 );
    }
    return type;
}

//////////////////////////////////////////////////////////////////////////
// Parse the image format
//
SPH_FORMAT parseformat( char* param )
{
    char buffer[256];
    SPH_FORMAT format;  

    strcpy(buffer, strlwr( param ) );
    if ( !strcmp( buffer, "c" ) )
        format = SPH_CUBIC;
    else if ( !strcmp( buffer, "cv" ) )
        format = SPH_CUBEVERT;
    else if ( !strcmp( buffer, "p" ) )
        format = SPH_PLANE;
    else if ( !strcmp( buffer, "h" ) )
        format = SPH_HEALPIX;
    else if ( !strcmp( buffer, "b" ) )
        format = SPH_MIRROR;
    else if ( !strcmp( buffer, "m" ) )
        format = SPH_MIRRORCLOSE;
    else if ( !strcmp( buffer, "r" ) )
        format = SPH_PROBE;
	else if ( !strcmp( buffer, "u" ) )
		format = SPH_UCM;
	else if ( !strcmp( buffer, "uv" ) )
		format = SPH_UCMVERT;
	else if ( !strcmp( buffer, "i" ) )
		format = SPH_ISOCUBE;
	else if ( !strcmp( buffer, "iv" ) )
		format = SPH_ISOCUBEVERT;
	else if ( !strcmp( buffer, "rd" ) )
		format = SPH_RHOMBIC;
    else 
    {
        printshortusage(); exit( 1 );
    }
    return format;
}

//////////////////////////////////////////////////////////////////////////
// Free global buffers
//
void myfree()
{
    if ( g_pImageangle )
        delete [] g_pImageangle;
    if ( g_cImagelist )  {
        for (int i=0; i<g_iImagecnt; i++ ) {
            if ( g_cImagelist[i] )
                delete [] g_cImagelist[i];
        }
        delete [] g_cImagelist;
    }
    if ( g_fDstimage ) {
        for ( int i=0; i<g_Dstinfo.ifacecnt; i++ ) {
            if ( g_fDstimage[i] ) {
                delete [] g_fDstimage[i];
            }
        }
        delete [] g_fDstimage;
    }
    if ( g_fSrcimages ) {
        for (int i=0; i<g_iImagecnt; i++ ) {
            for (int j=0; j<g_Srcinfo.ifacecnt; j++) {
                if ( g_fSrcimages[i][j] ) {
                    delete [] g_fSrcimages[i][j];
                }
            }
            delete [] g_fSrcimages[i];
        }
        delete [] g_fSrcimages;
    }
}

//////////////////////////////////////////////////////////////////////////
// Parse the image name and rotation angle
//
void parseimages( int argc, char **argv, int argind )
{
    int i, index=0;
    g_iImagecnt = 0;  
    for ( i=argind; i<argc; i++ )  {
        if ( !strcmp( argv[i], "/i" ) ) {
            g_iImagecnt ++;
        }
    }

    if ( g_iImagecnt == 0 ) {
        printf("No source image!\n");
        exit(1);
    }
    // Allocate memories
    g_cImagelist = new char *[g_iImagecnt];
    for ( i=0; i<g_iImagecnt; i++ ) {
        g_cImagelist[i] = new char [FILE_NAME_LEN];
    }
    g_pImageangle = new VECTOR3D [g_iImagecnt];
    memset( g_pImageangle, 0, sizeof(VECTOR3D) * g_iImagecnt );
    for ( i=0; i<g_iImagecnt; i++ ) {
        g_pImageangle[i].w = 1.f;
    }

    index = -1;
    for ( i=argind; i<argc; i++ ) {
        if ( !strcmp( argv[i], "/i" ) ) {
            i++;
            index ++;
            strcpy( g_cImagelist[index], argv[i] );
        }
        if ( !strcmp( argv[i], "/x" ) ) {
            i++;
            g_pImageangle[index].x = atof( argv[i] )/360.0*M_2PI;
        }
        if ( !strcmp( argv[i], "/y" ) ) {
            i++;
            g_pImageangle[index].y = atof( argv[i] )/360.0*M_2PI;
        }
        if ( !strcmp( argv[i], "/z" ) ) {
            i++;
            g_pImageangle[index].z = atof( argv[i] )/360.0*M_2PI;
        }
        if ( !strcmp( argv[i], "/a" ) ) {
            i++;
            g_pImageangle[index].w = atof( argv[i] );
            //if ( g_pImageangle[index].w > 1.f ) {
            //  printf("It should be 0 < weight < 1\n");
            //  exit(1);
            //}
        }
    }

}

//////////////////////////////////////////////////////////////////////////
// Get the face number for the source image
//
int getfacecnt( SPH_FORMAT format )
{
    int facecnt = 1;
    switch ( format ) {
      case SPH_CUBIC:     
      case SPH_CUBEVERT: 
	  case SPH_UCM:
	  case SPH_UCMVERT:
	  case SPH_ISOCUBE:
	  case SPH_ISOCUBEVERT:
		  facecnt = 6;   
		  break;
      case SPH_PLANE:     
		  facecnt = 1;   
		  break;
      case SPH_HEALPIX:
	  case SPH_RHOMBIC:
		  facecnt = 12;  
		  break;
      case SPH_MIRROR:
      case SPH_MIRRORCLOSE:
      case SPH_PROBE:
          facecnt = 1;   break;
    }
    return facecnt;
}

//////////////////////////////////////////////////////////////////////////
// Set the resolution of the target image 
//
void setdstsize( SPH_FORMAT format )
{
    switch ( format ) {
    case SPH_CUBIC:     
	case SPH_UCM:
	case SPH_ISOCUBE:
		g_Dstinfo.iwidth = g_Dstinfo.isize; 
        g_Dstinfo.iheight = g_Dstinfo.isize;  
        break;
    case SPH_CUBEVERT:  
	case SPH_UCMVERT:
	case SPH_ISOCUBEVERT:
		g_Dstinfo.iwidth = g_Dstinfo.isize*3;
        g_Dstinfo.iheight = g_Dstinfo.isize*4;  
        break;
    case SPH_PLANE:     
		// acquired from user input
		break;
    case SPH_HEALPIX:  
	case SPH_RHOMBIC:
		g_Dstinfo.iwidth = g_Dstinfo.isize*3;
        g_Dstinfo.iheight = g_Dstinfo.isize*4;  
        break;
    }
}

/////////////////////////////////////////////////////////////////////
///         Read source images
//
// Read source images
//
bool readimages()
{
    int i;
    bool res = false;
    if ( g_iImagecnt > 0 ) {
        // Allocate memory for source images 
        g_Srcinfo.ifacecnt = getfacecnt( g_Srcinfo.format );
        g_fSrcimages = new float ** [g_iImagecnt]; 
        if ( g_fSrcimages == NULL ) return false;
        for ( i=0; i<g_iImagecnt; i++ ) {
            g_fSrcimages[i] = NULL;
            g_fSrcimages[i] = new float *[g_Srcinfo.ifacecnt];
            if ( g_fSrcimages[i] == NULL ) return false;
            for (int j=0; j<g_Srcinfo.ifacecnt; j++ ) {
                g_fSrcimages[i][j] = NULL;
            }
        }

        // Read source images
        for ( i=0; i<g_iImagecnt; i++ ) {
            switch ( g_Srcinfo.format ) {
        case SPH_CUBIC:
		case SPH_UCM:
		case SPH_ISOCUBE:
            res = readcube( &g_fSrcimages[i], &g_Srcinfo, g_Dstinfo, g_cImagelist[i] );
            break;
        case SPH_CUBEVERT:
		case SPH_UCMVERT:
		case SPH_ISOCUBEVERT:
            res = readcubevert( &g_fSrcimages[i], &g_Srcinfo, g_Dstinfo, g_cImagelist[i] );
            break;
        case SPH_PLANE:     
		case SPH_MIRROR:
		case SPH_MIRRORCLOSE:
		case SPH_PROBE:
            res = readplane( &g_fSrcimages[i], &g_Srcinfo, g_Dstinfo, g_cImagelist[i] );
            break;
        case SPH_HEALPIX:   
		case SPH_RHOMBIC:
            res = readhealpix( &g_fSrcimages[i], &g_Srcinfo, g_Dstinfo, g_cImagelist[i] );
            break;
            }
            if ( !res ) return false;
        }
    }
    return true;
}

/////////////////////////////////////////////////////////////////
//  Write target image
//
bool writeimage()
{
    bool res = false;
    switch ( g_Dstinfo.format ) {
    case SPH_CUBIC:
	case SPH_UCM:
	case SPH_ISOCUBE:
        res = writecube( g_fDstimage, g_Srcinfo, g_Dstinfo, "pano" );      
        break;
    case SPH_CUBEVERT:
	case SPH_UCMVERT:
	case SPH_ISOCUBEVERT:
        res = writecubevert( g_fDstimage, g_Srcinfo, g_Dstinfo, "pano" );
        break;
    case SPH_PLANE:     
        res = writeplane( g_fDstimage, g_Srcinfo, g_Dstinfo, "pano" );
        break;
    case SPH_HEALPIX:   
	case SPH_RHOMBIC:
        res = writehealpix( g_fDstimage, g_Srcinfo, g_Dstinfo, "pano" );
        break;
    }
    return res;
}

////////////////////////////////////////////////////////////////
//  
//
// Main function to convert and merge source panorama images
//
bool panomerge()
{
    int i, len;
    bool res;
    // Allocate memory for target image
    if ( g_Dstinfo.type == _TGA )
        g_Dstinfo.ibpp = g_Srcinfo.ibpp;
    else
        g_Dstinfo.ibpp = 3;

    g_Dstinfo.ifacecnt = getfacecnt( g_Dstinfo.format );
    setdstsize( g_Dstinfo.format );
    len = g_Dstinfo.iwidth * g_Dstinfo.iheight * g_Dstinfo.ibpp;
    g_fDstimage = new float *[g_Dstinfo.ifacecnt];  
    if ( g_fDstimage == NULL ) return false;
    for ( i=0; i<g_Dstinfo.ifacecnt; i++ ) {
        g_fDstimage[i] = NULL;
        g_fDstimage[i] = new float [len];
        if ( g_fDstimage[i] == NULL ) return false;
        memset( g_fDstimage[i], 0, sizeof(float)*len );
    }

    // Merge source images
    for ( i=0; i<g_iImagecnt; i++ ) 
    {
        res = panoface( g_fSrcimages[i], g_Srcinfo, g_pImageangle[i], g_Dstinfo,  g_fDstimage);
        if ( !res ) return false;
    }

    return true;
}

////////////////////////////////////////////////////////////////////////
//
// The function "panoface" converts panorama from one format to another
//
bool panoface( float **pfSrcimage, MYIMAGEINFO &Srcinfo, VECTOR3D &Imageangle,
			  MYIMAGEINFO &Dstinfo,  float **pfDstimage)
{
	// size of base faces
	int widthdst, heightdst;
	switch ( Dstinfo.format ) 
	{
	case SPH_CUBIC:
	case SPH_CUBEVERT: 
	case SPH_UCM:
	case SPH_UCMVERT:
	case SPH_ISOCUBE:
	case SPH_ISOCUBEVERT:
	case SPH_HEALPIX: 
	case SPH_RHOMBIC:
		widthdst = heightdst = Dstinfo.isize;
		break;
	case SPH_PLANE:
		widthdst = Dstinfo.iwidth;
		heightdst = Dstinfo.iheight;
		break;
	default:
		break;
	}

	int srcbpp = Srcinfo.ibpp;
	int dstbpp = Dstinfo.ibpp;    

	// for each face, compute (s, t) --> angle (theta, phi)
	// then get the color of the corresponding point
	int win = 2;
	win = (win<1) ? 1 : win;
	double supp = 2*win;
	int win2 = win*win;
	double s, t, ds, dt;
	float *rgb = new float[Srcinfo.ibpp];
	float *pixel = new float [Srcinfo.ibpp]; 
	double theta, phi;
	double u1, v1, w1, u2, v2, w2;

	// rotation matrix, z -> y -> x
	double a11 = cos(Imageangle.y) * cos(Imageangle.z);
	double a12 = -cos(Imageangle.y) * sin(Imageangle.z);
	double a13 = sin(Imageangle.y);
	double a21 = cos(Imageangle.x) * sin(Imageangle.z) + sin(Imageangle.x)*sin(Imageangle.y)*cos(Imageangle.z);
	double a22 = cos(Imageangle.x) * cos(Imageangle.z) - sin(Imageangle.x)*sin(Imageangle.y)*sin(Imageangle.z);
	double a23 = -sin(Imageangle.x) * cos(Imageangle.y) ; 
	double a31 = sin(Imageangle.x) * sin(Imageangle.z) - cos(Imageangle.x) * sin(Imageangle.y) * cos(Imageangle.z);
	double a32 = sin(Imageangle.x) * cos(Imageangle.z) + cos(Imageangle.x) * sin(Imageangle.y) * sin(Imageangle.z);
	double a33 = cos(Imageangle.x) * cos(Imageangle.y);


	for ( int face = 0; face < Dstinfo.ifacecnt; face ++ )
	{
		for ( int y=0; y<heightdst; y++ )
		{
			for (int x=0; x<widthdst; x++)
			{
				// set pixel[3] if any to be zero
				memset(pixel, 0, sizeof(float)*Srcinfo.ibpp);

				for (int k=0; k<win; k++)
				{
					dt = (2*k+1)/supp;
					for (int l=0; l<win; l++)
					{
						ds = (2*l+1)/supp;
						if (Dstinfo.format == SPH_RHOMBIC)
							s = Dstinfo.isize-1-x;
						else
							s = x;
						if ( Dstinfo.format == SPH_HEALPIX || Dstinfo.format == SPH_RHOMBIC)
							t = Dstinfo.isize-1-y;
						else
							t = y;
						s = s + ds;
						t = t + dt;

						// theta -- [0, M_PI], phi -- [0, M_2PI]
						switch ( Dstinfo.format ) 
						{
						case SPH_CUBIC:
						case SPH_CUBEVERT:
							cube_pix2ang(Dstinfo.isize, face, s, t, &theta, &phi);
							break;
						case SPH_HEALPIX:                            
							hp_pix2ang(Dstinfo.isize, face, s, t, &theta, &phi); 
							break;
						case SPH_PLANE:
							plane_pix2ang(Dstinfo.iwidth, Dstinfo.iheight, s, t, &theta, &phi);
							break;
						case SPH_UCM:
						case SPH_UCMVERT:
							ucm_pix2ang(Dstinfo.isize, face, s, t, &theta, &phi);
							break;
						case SPH_ISOCUBE:
						case SPH_ISOCUBEVERT:
							isocube_pix2ang(Dstinfo.isize, face, s, t, &theta, &phi);
							break;
						case SPH_RHOMBIC:
							rd_pix2ang(Dstinfo.isize, face, s, t, &theta, &phi);
							break;
						default:
							break;
						}

						// z-rot --> y rot --> x rot
						u1 = sin(theta) * cos(phi);
						v1 = cos(theta);
						w1 = sin(theta) * sin(phi);          

						u2 = a11*u1 + a12*v1 + a13*w1;
						v2 = a21*u1 + a22*v1 + a23*w1;
						w2 = a31*u1 + a32*v1 + a33*w1;

						theta = acos(v2);
						phi = atan2(w2, u2);
						phi = (phi<0) ? phi + M_2PI : phi;

						// turn to clock wise
						if ( ( (Srcinfo.format!=SPH_PLANE && Srcinfo.format!=SPH_HEALPIX && Srcinfo.format!=SPH_RHOMBIC)
							&& (Dstinfo.format!=SPH_CUBIC) && (Dstinfo.format!=SPH_CUBEVERT) && (Dstinfo.format!=SPH_UCM) && (Dstinfo.format!=SPH_UCMVERT) && Dstinfo.format!=SPH_ISOCUBE && Dstinfo.format!=SPH_ISOCUBEVERT )
							|| ( (Dstinfo.format==SPH_CUBIC || Dstinfo.format==SPH_CUBEVERT || Dstinfo.format==SPH_UCM || Dstinfo.format==SPH_UCMVERT || Dstinfo.format==SPH_ISOCUBE || Dstinfo.format==SPH_ISOCUBEVERT) 
							&& (Srcinfo.format==SPH_PLANE || Srcinfo.format==SPH_HEALPIX || Srcinfo.format==SPH_RHOMBIC ) )
							)
						{
							phi = M_PI_2 - phi;
							phi = (phi<0) ? phi + M_2PI : phi;							
						}	                        

						switch ( Srcinfo.format ) 
						{
						case SPH_CUBIC:
						case SPH_CUBEVERT:
							lookupcube( pfSrcimage, Srcinfo.isize, Srcinfo.ibpp, theta, phi, rgb );
							break;
						case SPH_UCM:
						case SPH_UCMVERT:
							lookupucm( pfSrcimage, Srcinfo.isize, Srcinfo.ibpp, theta, phi, rgb );
							break;
						case SPH_ISOCUBE:
						case SPH_ISOCUBEVERT:
							lookupisocube( pfSrcimage, Srcinfo.isize, Srcinfo.ibpp, theta, phi, rgb );
							break;
						case SPH_MIRROR:
							lookupmirror( pfSrcimage, Srcinfo.iwidth, Srcinfo.iheight, Srcinfo.ibpp, theta, phi, rgb );
							break;
						case SPH_MIRRORCLOSE:
							lookupmirrorcloseup( pfSrcimage, Srcinfo.iwidth, Srcinfo.iheight, Srcinfo.ibpp, theta, phi, rgb );
							break;
						case SPH_PROBE:
							lookupprobe( pfSrcimage, Srcinfo.iwidth, Srcinfo.iheight, Srcinfo.ibpp, theta, phi, rgb );
							break;
						case SPH_PLANE:
							lookupplane( pfSrcimage, Srcinfo.iwidth, Srcinfo.iheight, Srcinfo.ibpp, theta, phi, rgb );
							break;
						case SPH_HEALPIX:
							lookuphealpix( pfSrcimage, Srcinfo.isize, Srcinfo.ibpp, theta, phi, rgb );
							break;
						case SPH_RHOMBIC:
							lookuprhombic( pfSrcimage, Srcinfo.isize, Srcinfo.ibpp, theta, phi, rgb );
							break;
						}

						pixel[0] += rgb[0];
						pixel[1] += rgb[1];
						pixel[2] += rgb[2];
						if ( Srcinfo.ibpp == 4 ) 
						{
							pixel[3] += rgb[3];
						}
					}
				}

				// average the supersampling results
				int pixindex = y * widthdst + x;        
				if ( srcbpp == 3 ) 
				{
					pfDstimage[face][pixindex*dstbpp]   += pixel[0]/win2*float(Imageangle.w);
					pfDstimage[face][pixindex*dstbpp+1] += pixel[1]/win2*float(Imageangle.w);
					pfDstimage[face][pixindex*dstbpp+2] += pixel[2]/win2*float(Imageangle.w);
				}
				else if ( srcbpp == 4 ) 
				{
					pfDstimage[face][pixindex*dstbpp]   += pixel[0]/win2*float(Imageangle.w);
					pfDstimage[face][pixindex*dstbpp+1] += pixel[1]/win2*float(Imageangle.w);
					pfDstimage[face][pixindex*dstbpp+2] += pixel[2]/win2*float(Imageangle.w);
					if ( Dstinfo.ibpp == 4 ) {
						pfDstimage[face][pixindex*dstbpp+3] += pixel[3]/win2*float(Imageangle.w);
					}
				}
				// end average
			}
		}
	}

	delete [] rgb;
	delete [] pixel;
	return true;
}