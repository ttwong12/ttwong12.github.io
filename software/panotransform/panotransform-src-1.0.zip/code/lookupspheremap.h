#ifndef _LOOKUP_SPHEREMAP_H
#define _LOOKUP_SPHEREMAP_H

void lookupcube(float** cubeface, int size, int bpp, double theta, double phi, float *prgb );

void lookupucm(float** cubeface, int size, int bpp, double theta, double phi, float *prgb );

void lookupmirror(float** mirrormap, int width, int height, int bpp, double theta, double phi, float *prgb );

void lookupmirrorcloseup(float** mirrormap, int width, int height, int bpp, double theta, double phi, float *prgb );

void lookupprobe(float** mirrormap, int width, int height, int bpp, double theta, double phi, float *prgb );

void lookupplane(float** planemap, int width, int height, int bpp, double theta, double phi, float *prgb );

void lookuphealpix(float** hpmap, int size, int bpp, double theta, double phi, float *prgb );

void lookupisocube(float** cubeface, int size, int bpp, double theta, double phi, float *prgb );

void lookuprhombic(float** rdmap, int size, int bpp, double theta, double phi, float *prgb );

#endif