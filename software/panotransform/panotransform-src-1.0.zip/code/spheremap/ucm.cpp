/* isocube.cpp */
/*
* This program implements the unicube mapping proposed in our TVCG'10 paper.
* To use this code and the results, please cite the following paper:
*
*    Tze-Yiu Ho, Liang Wan, Ping-Man Lam, Chi-Sing Leung, and Tien-Tsin Wong, 
*    Unicube for Dynamic Environment Mapping, 
*    IEEE Transactions on Visualization and Computer Graphics (TVCG 2010), 
*    to be published. 
*
* Copyright (C) 2010 Liang Wan, The Chinese University of Hong Kong
* 
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
*/

#define _USE_MATH_DEFINES
#include <math.h>

#include "ucm.h"

//////////////////////////////////////////////////////////////////////////
// ucm_pix2ang 
//
// maps the pixel from local coordinates (facenum, ix, iy) in the unicube 
// to spherical coordinates (theta, phi). 
// 
// INPUT:
//   nside  : resolution of one unicube face
//   facenum: the unicube face in which the input pixel is located
//   ix, iy : local coordinates of a given pixel, [0,nside-1]x[0,nside-1]
// 
// OUTPUT:
//   theta : polar angle with a range of [0, pi]
//   phi   : azimuth angle with a range of [0, 2pi]
// 
void ucm_pix2ang(long nside, int facenum, double ix, double iy, double *theta, double *phi)
{
	double radius = nside/2.0;
	double x, y, z, len;

	switch ( facenum ) {
	case 0: // face xp
		x = radius;
		y = radius - iy;
		z = radius - ix;
		break;
	case 1: // face zn
		x = ix - radius;
		y = radius - iy;
		z = radius; 
		break;
	case 2: // face xn
		x = -radius;
		y = radius - iy;
		z = ix - radius;      
		break;
	case 3: // face zp
		x = radius - ix;
		y = radius - iy;
		z = -radius;
		break; 
	case 4: // face yp
		x = radius - ix;
		y = radius;
		z = radius - iy;
		break;
	case 5: // face yn
		x = ix - radius;
		y = -radius;
		z = radius - iy;
		break;
	}

	// perform the inverse unicube mapping
	x /= radius;
	y /= radius;
	z /= radius;

	double tmp;
	tmp = sin(x*M_PI_2/3.0);
	x = tmp / sqrt(0.5-tmp*tmp);
    tmp = sin(y*M_PI_2/3.0);
	y = tmp / sqrt(0.5-tmp*tmp);
	tmp = sin(z*M_PI_2/3.0);
	z = tmp / sqrt(0.5-tmp*tmp);

	// normalize x, y, z
	len = sqrt(x*x + y*y + z*z);
	y /= len;
	*phi = atan2(z, x);
	*phi = (*phi < 0) ? *phi + M_PI*2 : *phi;
	*theta = acos( y );
}

//////////////////////////////////////////////////////////////////////////
// ucm_ang2pix
//
// maps one pixel from spherical coordinates to local coordinates of the 
// unicube map.
//
// Please refer to function ucm_pix2ang() for the description of 
// function variables
//
void ucm_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy)
{
	double radius = nside/2.0;
	double x, y, z;	
	x = sin(theta) * cos(phi);
	y = cos(theta);
	z = sin(theta) * sin(phi);
	double vmax=(abs(x)>abs(y))?abs(x):abs(y);
	vmax = (vmax>abs(z))?vmax:abs(z);
	int axis=0;
	axis = (abs(x)>abs(y))?0:1;
	axis = (vmax>abs(z))?axis:2;
	x /= vmax;
	y /= vmax;
	z /= vmax;

	// perform unicube mapping
	if (axis==0) // |x|=1
	{
		y = 3 * M_2_PI * asin(y / sqrt(2*y*y+2));
		z = 3 * M_2_PI * asin(z / sqrt(2*z*z+2));
	}
	if (axis==1) // |y|=1
	{
		x = 3 * M_2_PI * asin(x / sqrt(2*x*x+2));
		z = 3 * M_2_PI * asin(z / sqrt(2*z*z+2));
	}
	if (axis==2) // |z|=1
	{
		x = 3 * M_2_PI * asin(x / sqrt(2*x*x+2));
		y = 3 * M_2_PI * asin(y / sqrt(2*y*y+2));
	}

	if (x>0 && axis==0)
	{
		// face xp
		*facenum = 0;
		*iy = 1.0 - y;
		*ix = 1.0 - z;
	}
	if (x<0 && axis==0)
	{
		// face xn
		*facenum = 2;
		*iy = 1.0 - y;
		*ix = 1.0 + z;  
	}
	if (z>0 && axis==2)
	{
		// face zn
		*facenum = 1;
		*ix = 1.0 + x;
		*iy = 1.0 - y;
	}
	if (z<0 && axis==2)
	{
		// face zp
		*facenum = 3;
		*ix = 1.0 - x;
		*iy = 1.0 - y;
	}
	if (y>0 && axis==1)
	{
		// face yp
		*facenum = 4;
		*ix = 1.0 + z;
		*iy = 1.0 - x;
	}
	if (y<0 && axis==1)
	{
		// face yn
		*facenum = 5;
		*ix = 1.0 + z;
		*iy = 1.0 + x;
	}
	*ix *= radius;
	*iy *= radius;
}