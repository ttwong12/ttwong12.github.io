/* healpix.cpp */
/*
* This program implements the healpix mapping which is first introduced to
* graphics community in [1] and was proposed in [2].
*
* To use this code and the results, please cite the following papers:
*
*   [1] Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung, 
*       Spherical Q2tree for Sampling Dynamic Environment Sequences, 
*       in Proc. of Eurographics Symposium on Rendering 2005 (EGSR'05), 
*       Konstanz, Germany, June 2005, pp. 21-30.     
* 
*   [2] K.M. G��rski, E. Hivon, A.J. Banday, B.D. Wandelt, F.K. Hansen, 
*       M. Reinecke, and M. Bartelmann, HEALPix: A Framework for High-resolution
*       Discretization and Fast Analysis of Data Distributed on the Sphere, 
*       Ap.J., 622, 759-771, 2005.
*
*
* The file healpix.cpp is a slight modification of the files, ang2pix_nest.c and
* pix2ang_nest.c in the package HEALPix_1.22, available from
* http://omega.jpl.nasa.gov/healpixSoftwareGetHealpix.shtml
*
*
* Copyright (c) 2007-2010, The Chinese University of Hong Kong
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*  * Redistributions of source code must retain the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer.
*  * Redistributions in binary form must reproduce the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer in the documentation and/or other 
*    materials provided with the distribution.
*  * Neither the name of The Chinese University of Hong Kong nor the
*    names of its contributors may be used to endorse or promote products
*    derived from this software without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
* ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
* ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
* POSSIBILITY OF SUCH DAMAGE.
*
*/

#define _USE_MATH_DEFINES
#include <math.h>

#include "healpix.h"

//////////////////////////////////////////////////////////////////////////
// hp_pix2ang 
//
// maps the pixel from local coordinates (facenum, ix, iy) in the healpix map 
// to spherical coordinates (theta, phi). 
// 
// INPUT:
//   nside  : resolution of one healpix map face
//   facenum: the healpix map face where the input pixel locates
//   ix, iy : local coordinates of a given pixel, [0,nside-1]x[0,nside-1]
// 
// OUTPUT:
//   theta : polar angle with a range of [0, pi]
//   phi   : azimuth angle with a range of [0, 2pi]
// 
void hp_pix2ang( long nside, int facenum, double ix, double iy, double *theta, double *phi) 
{
	double jrt, jr, nr, jpt, nl4; 
	double z, fn, fact1, fact2;

	// coordinate of the lowest corner of each face
	static int jrll[12], jpll[12]; 
	jrll[0]=2;	jrll[1]=2;	jrll[2]=2;	jrll[3]=2;
	jrll[4]=3;	jrll[5]=3;	jrll[6]=3;	jrll[7]=3;
	jrll[8]=4;	jrll[9]=4;	jrll[10]=4;	jrll[11]=4;

	jpll[0]=1;	jpll[1]=3;	jpll[2]=5;	jpll[3]=7;
	jpll[4]=0;	jpll[5]=2;	jpll[6]=4;	jpll[7]=6;
	jpll[8]=1;	jpll[9]=3;	jpll[10]=5;	jpll[11]=7;

	fn = 1.*nside;
	fact1 = 1./(3.*fn*fn);
	fact2 = 2./(3.*fn);
	nl4   = 4*nside;
  
    jrt = ix + iy; // 'vertical' in {0,2*(nside-1)}
	jpt = ix - iy; // 'horizontal' in {-nside+1,nside-1}

	// compute z coordinate on the sphere
	jr =  jrll[facenum]*nside - jrt;
	nr = nside;   
	z  = (2*nside-jr)*fact2;
	if( jr<nside ) 
	{ // north pole region
		nr = jr;
		z = 1. - nr*nr*fact1;	 
	}
	else if ( jr>3*nside ) 
	{ // south pole region
	   nr = nl4 - jr;
	   z = - 1. + nr*nr*fact1;
	}

	*theta = acos(z);
    *phi = (jpll[facenum]*nr + jpt)/2.0 * (M_PI_2 / nr);
	*phi = (*phi < 0) ? *phi + M_PI*2 : *phi;
}

//////////////////////////////////////////////////////////////////////////
// hp_ang2pix
//
// maps one pixel from spherical coordinates to local coordinates of the 
// healpix map.
//
// Please refer to function hp_pix2ang() for the description of 
// function variables
//
void hp_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy)
{
	double  fn, u, v, iu, iv, z;
	double  t, tt, tn, tf;
	double  za, tmp, south, fsign;
	
	// Compute z coordinate
	t = phi * M_2_PI; 	 
	z = cos(theta);

	// Check if it falls into equatorial or polar zone,  
	za = 3.0 * abs(z);
	tf = modf(t, &tn);
	
	if ( za < 2.0) 
	{  
		// Equatorial zone 
		tt = t + 0.5;            
		tmp= z * 0.75;           // 3z/4
		u  = modf(tt + tmp, &iu);
		v  = modf(tt - tmp, &iv); // u,v are the local coordinates within a base face
		fn = (iu > iv) ? iv : iu; // min(iu, iv)
		tmp = (iv-iu);
		if ( tmp>0 ) fsign=1.0;
		else if ( tmp<0 ) fsign=-1.0;
		else fsign = 0.0;
		fn += 4 + (fsign-floor(fn/4))*4; // base face index
		
		*facenum = int(fn);
		*ix = u*nside;
		*iy = v*nside;
	}
	else 
	{ // Polar zone 
		tmp = sqrt(3.0f - za);   
		south = (z<0);  // check if it is south or north pole 
		tt  = tmp * tf;
		tmp = 1.0 - tmp;
		tf  = tmp * south;
		
		// Compute face index and local coordinates in the polar zone
		*facenum = int(tn + 8 * south);
		*ix = (tmp-tf+tt)*nside;
		*iy = (tf+tt)*nside;
	}	
}