#ifndef _ISOCUBE_H
#define _ISOCUBE_H

void isocube_pix2ang(long nside, int facenum, double ix, double iy, double *theta, double *phi);

void isocube_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy);

#endif 