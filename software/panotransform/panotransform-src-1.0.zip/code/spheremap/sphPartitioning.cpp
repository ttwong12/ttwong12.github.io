/* sphPartitioning.cpp */
/*
* This program implements basic functions for the rhombic dodecahedron mapping
* proposed in our TMM'09 paper.
* To use this code and the results, please cite the following paper:
*
*    Chi-Wing Fu, Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung, 
*    The Rhombic Dodecahedron Map: An Efficient Scheme for Encoding Panoramic
*    Video, IEEE Transactions on Multimedia (TMM), 
*    Vol. 11, No. 4, pp. 634-644, June 2009. 
*
* Copyright (c) 2007-2010, The Chinese University of Hong Kong
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*  * Redistributions of source code must retain the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer.
*  * Redistributions in binary form must reproduce the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer in the documentation and/or other 
*    materials provided with the distribution.
*  * Neither the name of The Chinese University of Hong Kong nor the
*    names of its contributors may be used to endorse or promote products
*    derived from this software without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
* ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
* ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
* POSSIBILITY OF SUCH DAMAGE.
*
*/

#define _USE_MATH_DEFINES
#include <math.h>

#include "sphPartitioning.h"

///////////////////////////////////////////////////////////////
// Basic Vector Operations
///////////////////////////////////////////////////////////////

/*** length of a 3D vector */
double length3D(const double *pt1)
{
	// no assertion in math3D.c to keep the program efficiency
#ifdef _DEBUG
	assert(pt1);
#endif

	return (sqrt(pt1[0]*pt1[0]+pt1[1]*pt1[1]+pt1[2]*pt1[2]));
}

/*** two vectors' sum is another vector ***/
void add3D(const double *vect1, const double *vect2, double *vect3)
{
	// no assertion in math3D.c to keep the program efficiency
#ifdef _DEBUG
	assert(vect1);
	assert(vect2);
	assert(vect3);
#endif

	vect3[0] = vect1[0] + vect2[0];
	vect3[1] = vect1[1] + vect2[1];
	vect3[2] = vect1[2] + vect2[2];
}


/*** two vectors' difference is another vector ***/
void minus3D(const double *vect1, const double *vect2, double *vect3)
{	
#ifdef _DEBUG
	assert(vect1);
	assert(vect2);
	assert(vect3);
#endif

	vect3[0] = vect1[0] - vect2[0];
	vect3[1] = vect1[1] - vect2[1];
	vect3[2] = vect1[2] - vect2[2];
}

/*** add and multiply ***/
void
add_mul_3D(const double *vect1, const double t, const double *vect2, double *v1_add_t_mul_v2)
{	
#ifdef _DEBUG
	assert(vect1);
	assert(vect2);
#endif

	v1_add_t_mul_v2[0] = vect1[0] + t * vect2[0];
	v1_add_t_mul_v2[1] = vect1[1] + t * vect2[1];
	v1_add_t_mul_v2[2] = vect1[2] + t * vect2[2];
}

/*** calculate the dot product of two vectors ***/
double dot3D(const double *vect1, const double *vect2)
{	
#ifdef _DEBUG
	assert(vect1);
	assert(vect2);
#endif

	return (vect1[0]*vect2[0] + vect1[1]*vect2[1] + vect1[2]*vect2[2]);
}

/*** calculate the plane cross product : v cross w = r ***/
void cross3D(const double *v, const double *w, double *r)
{
#ifdef _DEBUG
	assert(v);
	assert(w);
	assert(r);
#endif

	r[0] = v[1]*w[2] - v[2]*w[1];
	r[1] = v[2]*w[0] - v[0]*w[2];
	r[2] = v[0]*w[1] - v[1]*w[0];
}

/*** copy vect1 from vect2 ***/
void copy3D(double *vect1, const double *vect2)
{	
#ifdef _DEBUG
	assert(vect1);
	assert(vect2);
#endif

	vect1[0] = vect2[0];
	vect1[1] = vect2[1];
	vect1[2] = vect2[2];
}

/*** multiply a vector by a factor***/
void mult3D(double *vect, const double scale)
{	
#ifdef _DEBUG
	assert(vect);
#endif

	vect[0] = vect[0]*scale;
	vect[1] = vect[1]*scale;
	vect[2] = vect[2]*scale;
}

/*** unify a vector ***/
int unify3D(double *vect)
{
	double length;
	
#ifdef _DEBUG
	assert(vect);
#endif

	length = sqrt(vect[0]*vect[0]+vect[1]*vect[1]+vect[2]*vect[2]);

	if (length == 0.0)
		return 0;

	vect[0] = vect[0] / length;
	vect[1] = vect[1] / length;
	vect[2] = vect[2] / length;

	return 1;
}

///////////////////////////////////////////////////////////////
// Data structure
///////////////////////////////////////////////////////////////

	/////////////////////////////////////////////
	// Rhombic Dodecahedron
	//     - created by adding six points on the face centers of a cube

    // Variables:
    //  <shape_name>_basePt   [][3] = { { ... } , { ... } , { ... } , ... }
    //  <shape_name>_baseIndex[][X] = { { ... } , { ... } , { ... } , ... }    X = 3 or 4
    //  <shape_name>_numBaseTri or <shape_name>_numBaseQuad  depends on X = 3 or 4
    //  <shape_name>_numBaseVertex
    

    static double sin45        = 1.0 / sqrt ( 2.0 ) ;
    static double rhom_dodec_x = 1.0 / sqrt ( 3.0 ) ;
    static double rhom_dodec_y = sqrt ( 2.0 / 3.0 ) ;
	static double rhom_dodec_z = 1.0 / sqrt ( 2.0 * 3.0 ) ;	// 0.408248

    static double rhom_dodec_basePt[][3] =
    {      

	  {  0.0 , sin45 , sin45 } ,				// 0: tip

      { -rhom_dodec_x ,           0.0 , rhom_dodec_y } ,	// 1
      {  rhom_dodec_x ,           0.0 , rhom_dodec_y } ,	// 2
      {  rhom_dodec_x ,  rhom_dodec_y ,          0.0 } ,	// 3
      { -rhom_dodec_x ,  rhom_dodec_y ,          0.0 } ,	// 4

      {  0.0 , -sin45 ,  sin45 } ,				// 5
      {  1.0 ,    0.0 ,    0.0 } ,				// 6
      {  0.0 ,  sin45 , -sin45 } ,				// 7
      { -1.0 ,    0.0 ,    0.0 } ,				// 8

      { -rhom_dodec_x , -rhom_dodec_y ,           0.0 } ,	// 9
      {  rhom_dodec_x , -rhom_dodec_y ,           0.0 } ,	// 10
      {  rhom_dodec_x ,           0.0 , -rhom_dodec_y } ,	// 11
      { -rhom_dodec_x ,           0.0 , -rhom_dodec_y } ,	// 12

      {  0.0 , - sin45 , -sin45 } ,				// 13

    } ;


    static int rhom_dodec_baseIndex[][4] =
    {
      {  1 ,  5 ,  2 ,  0 } ,
      {  2 ,  6 ,  3 ,  0 } ,
      {  3 ,  7 ,  4 ,  0 } ,
      {  4 ,  8 ,  1 ,  0 } ,
      
      {  8 ,  9 ,  5 ,  1 } ,
      {  5 , 10 ,  6 ,  2 } ,      
      {  6 , 11 ,  7 ,  3 } ,
      {  7 , 12 ,  8 ,  4 } ,

      {  9 , 13 , 10 ,  5 } ,
      { 10 , 13 , 11 ,  6 } ,
      { 11 , 13 , 12 ,  7 } ,
      { 12 , 13 ,  9 ,  8 } ,
    } ;

    static int rhom_dodec_numBaseQuad   = 12 ;
    static int rhom_dodec_numBaseVertex = 14 ;


	static double G_greatCircle_set[][3] = 
	{
		{  rhom_dodec_x , -rhom_dodec_z ,  rhom_dodec_z },
		{ -rhom_dodec_x , -rhom_dodec_z ,  rhom_dodec_z },
		{  rhom_dodec_x ,  rhom_dodec_z ,  rhom_dodec_z },
		{ -rhom_dodec_x ,  rhom_dodec_z ,  rhom_dodec_z },
		{  0.0          ,  0.0          ,  rhom_dodec_y },
		{  0.0          ,  rhom_dodec_y ,  0.0 },
	};

#define pos 1.0
#define neg 0.0
#define both 0.5

	// G_face_indexing_vector_set[i][j] represent for a vector v in 
	// face i, the dot product result of v and the great circle j
	//   - pos means that the vectors within the quad face i will be on the side of the great circle j
	//   - neg means that the vectors within the quad face i will be on the opposite side of the great circle j
	//   - both means that part of the vectors within the quad face i will be on the side of the great circle j
	//     and part of the vectors within the quad face i will be on the opposite side of the great circle j
	// remark: the normal of the great circle is defined by variable "rhom_dodec_greatCircle_normal" 
	static float G_face_indexing_vector_set[][6] = 
	{
		{ pos  ,  pos  ,  pos  ,  pos  ,  pos  , both },
		{ pos  ,  neg  ,  pos  , both  ,  pos  ,  pos },
		{ neg  ,  neg  ,  pos  ,  pos  , both  ,  pos },
		{ neg  ,  pos  , both  ,  pos  ,  pos  ,  pos },
		{both  ,  pos  ,  neg  ,  pos  ,  pos  ,  neg },
		{ pos  , both  ,  pos  ,  neg  ,  pos  ,  neg },
		{both  ,  neg  ,  pos  ,  neg  ,  neg  ,  pos },
		{ neg  , both  ,  neg  ,  pos  ,  neg  ,  pos },
		{ pos  ,  pos  ,  neg  ,  neg  , both  ,  neg },
		{ pos  ,  neg  , both  ,  neg  ,  neg  ,  neg },
		{ neg  ,  neg  ,  neg  ,  neg  ,  neg  , both },
		{ neg  ,  pos  ,  neg  , both  ,  neg  ,  neg }
	};

    /////////////////////////////////////////////
    // Dodecahedron

//  Basic Functions for retrieval of current solidType related variable
int getBasePolygonParam ( double ** obj_basePt , int ** obj_baseIndex , int * obj_numPoly , int * obj_numVertices )
{
    *obj_basePt      = ( double * ) rhom_dodec_basePt        ;
    *obj_baseIndex   = ( int    * ) rhom_dodec_baseIndex     ;
    *obj_numPoly     =              rhom_dodec_numBaseQuad   ;
    *obj_numVertices =              rhom_dodec_numBaseVertex ;
    return 1 ;
}

void getBaseGreatCircleSet (double ** greatCircle_set)
{
	*greatCircle_set = (double *) G_greatCircle_set;
}

int getFaceIndex(int code)
{
	static int facenum_lookup_table[64];
	static int firstime=0;

	if (firstime == 0)
	{
		for (int i = 0 ; i < 64; i++)    
			facenum_lookup_table[i] = -1;     

		/////////////////////////////////////////////////////////////////
		// make the facenum lookup table
		// a 6 bit binary index vector can be formed by setting
		// 1 as the entry if the greatcircle[i] dot vector q is positive
		// 0 as the entry if the greatcircle[i] dot vector q is negative
		// each rhombic face has two corresponding 6 bit binary index vector 
		// fill into the facenum_lookup_table for the two value corresponding to 
		// these two 6 bit binary index 
		for ( i = 0 ; i < 12 ; i++ )
		{        
			float indexnum1 = 0;
			float indexnum2 = 0;
			for (int j = 0 ; j < 6; j++)
			{
				if( fabs(G_face_indexing_vector_set[i][j] - both) < 1e-7)
				{
					indexnum1 = indexnum1 + 0 * int(pow(2,6-1-j));
					indexnum2 = indexnum2 + 1 * int(pow(2,6-1-j)); 
				}
				else
				{
					indexnum1 = indexnum1 + G_face_indexing_vector_set[i][j] * int(pow(2,6-1-j));
					indexnum2 = indexnum2 + G_face_indexing_vector_set[i][j] * int(pow(2,6-1-j)); 
				}
			}        
			facenum_lookup_table[int(indexnum1)] = i;
			facenum_lookup_table[int(indexnum2)] = i;
		}
	}

	int faceind = facenum_lookup_table[code];
	return faceind;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Functions for Small Circle Subdivision 
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// analyzeSC
//
// Small gadget for findSC_Vertex_Set
//
//  Input:
//    points: n1, nmid, n2 that form a small circle on sphere
//    (Assume unit vectors)
//
//  Output:
//    axis  - central axis of the small circle
//    hvec  - vector h is the shortest vector from the sphere center to the 
//            plane of small circle, i.e., it is along the central axis
//    v1    - by decompositing n1 along hvec: n1 = v1 + hvec
//    v2    - v2 is a vector on small circle plane such that
//            |v1| = |v2|, v1 = "axis" cross "v1",
//            and v2 is on the same side as n2 relative to the plane subtended by axis and v1
//    theta - angle between v1 and the projection of n2 on the small circle plane
//
//  Therefore, using v1,v2,theta, we can have
//             v = cos(t) v1 + sin(t) v2 such that 0 <= t <= theta
//  and we can produce any normal, n = v + hvec
//
void
analyzeSC ( const double * n1 , const double * nmid , const double * n2 , 
            double   axis[3] ,
            double   hvec[3] ,
            double   v1  [3] ,
            double   v2  [3] ,
            double * theta   )
{
    double tmp1[3] , tmp2[3] , vlen ;


    /////////////////////////////////////////////
    // Find the Central axis of the small circle

    minus3D ( nmid , n1   , tmp1 ) ;
    minus3D ( n2   , nmid , tmp2 ) ;
    cross3D ( tmp1 , tmp2 , axis ) ; unify3D ( axis ) ;


    /////////////////////////////////////////////
    // Find vector h: hvec
    // axis is vector of unit length which is the normal vector of   
    // the small circle, while hvec is axis but with shorter length such that
    // it only touch the small circle doest pass through
    copy3D ( hvec , axis ) ;
    mult3D ( hvec , dot3D ( axis , n1 ) ) ;


    /////////////////////////////////////////////
    // Decompose n1 into hvec + v1
    //           n2 into hvec + v2
    minus3D ( n1 , hvec , v1 ) ;
    minus3D ( n2 , hvec , v2 ) ;


    /////////////////////////////////////////////
    // Find theta

    // Note: |v1| = |v2|
    vlen = length3D ( v1 ) ;

    * theta = acos ( dot3D ( v1 , v2 ) / vlen / vlen ) ;


    /////////////////////////////////////////////
    // Find v2

    cross3D ( axis , v1 , v2 ) ;
    unify3D ( v2 ) ;

    mult3D ( v2 , vlen ) ;
}

// sc_interp
//
// Use for small circle subdivision scheme, Tune nv_mid around by "t"
// Note: assume unit vector input
//   If t = 0.0, nv_mid takes the current value
//   If t = 1.0, nv_mid will be on the "midpt" along the geodesic between n1-v2
//               i.e., small circle becomes a great circle
//
//   vec1 -- vec4
//    |        |
//   vec2 -- vec3
// 
// INPUT: 
//   n1:     normal of the plane formed by vec1 and vec2 OR normal of the plane formed by vec1 and vec4
//   n2:     normal of the plane formed by vec4 and vec3 OR normal of the plane formed by vec2 and vec3
//   nv_mid: vector calculated by cross product of midpt of (plane formed by vec1 and vec4) and 
//           midpt of (plane formed by vec2 and vec3) 
//           OR vector calculated by cross product of midpt of (plane formed by vec1 and vec2) and 
//           midpt of (plane formed by vec4 and vec3) 
//   t:      value range [0,1], controls the interpolation between nv_mid and midpt
//
// OUTPUT:
//   nv_mid: the tuned nv_mid according to the value of t 
//
void
sc_interp ( const double n1[3] , double nv_mid[3] , const double n2[3] , const double t )
{
    double midpt[3] , theta , cost , sint , tmp_vec[3] , aux_vec[3] ;

    // mid point between n1 and n2 along the geodesic
    add3D ( n1 , n2 , midpt ) ;
    unify3D ( midpt ) ;
    static count=0;


    // angle between mv_mid and midpt *times* t      
    //when the two vector are very close, the value could be larger than 1.0 and acos return -inf
    if( dot3D ( midpt , nv_mid ) >= (1.000 - 1e-15))
    {
      theta = 0.0;          
    }
    else      
      theta = acos ( dot3D ( midpt , nv_mid ) ) * t ;          
      
    cost  = cos ( theta ) ;
    sint  = sin ( theta ) ;

    // find the unit vector on the plane subtended by midpt and nv_mid
    cross3D ( midpt  , nv_mid  , tmp_vec ) ;
    cross3D ( nv_mid , tmp_vec , aux_vec ) ;
    unify3D ( aux_vec ) ;

    // find the result by interpolation
    nv_mid[0] = cost * nv_mid[0] + sint * aux_vec[0] ;
    nv_mid[1] = cost * nv_mid[1] + sint * aux_vec[1] ;
    nv_mid[2] = cost * nv_mid[2] + sint * aux_vec[2] ;

    unify3D ( nv_mid ) ;
}

//
// findSC_calNormalParameter
//
// find the parameter Small Circle Subdivision use to calculate the normal of plane subdividing 
// the quad in vert and hori direction 
// nv1, nv_mid, nv2 form a small circle on the sphere, the normal of plane subdividing the quad 
// in vert direction is calculated by the interpolation between nv1 and nv2 on the arc formed by
// nv1, nv_mid, nv2. The same for horizontal direction
//
//   vec1 -- vec4
//    |        |
//   vec2 -- vec3
//
// INPUT: 
//   vec1: vertex of the quad in (x,y,z) format
//   vec2: vertex of the quad in (x,y,z) format
//   vec3: vertex of the quad in (x,y,z) format
//   vec4: vertex of the quad in (x,y,z) format
//   small_circle_param: a floating point value between [0,1] which controls
//                       how the small circle subdivision algorithm subdivide the quad
//     
// OUTPUT:
//   vert_axis, vert_hvec, vert_v1, vert_v2, vert_theta,
//   hori_axis, hori_hvec, hori_v1, hori_v2, hori_theta.
//   Please refer to the function analyzeSC for the description of the above variable
//
void findSC_calNormalParameter( double *vert_axis, double *vert_hvec,
                                double *vert_v1  , double *vert_v2  , double &vert_theta,
                                double *hori_axis, double *hori_hvec,
                                double *hori_v1  , double *hori_v2  , double &hori_theta,
                                const double * vec1 ,
                                const double * vec2 ,
                                const double * vec3 ,
                                const double * vec4 ,
                                float small_circle_param
                               )
{

    double nv1[3] , nv2[3] , nh1[3] , nh2[3] ;

    /////////////////////////////////////////////
    // Normals for the four edge planes
    //
    //   vec1 -- vec4
    //    |        |
    //   vec2 -- vec3

    cross3D ( vec1 , vec2 , nv1 ) ; unify3D ( nv1 ) ;
    cross3D ( vec4 , vec3 , nv2 ) ; unify3D ( nv2 ) ;
    cross3D ( vec4 , vec1 , nh1 ) ; unify3D ( nh1 ) ;
    cross3D ( vec3 , vec2 , nh2 ) ; unify3D ( nh2 ) ;


    /////////////////////////////////////////////
    // Find two more normals in between nv1-nv2 and nh1-nh2

    double mid0[3] , mid1[3] , nv_mid[3] , nh_mid[3] ;

    // one more cross3D: mid14 X mid23 -> nv_mid
    add3D   ( vec1 , vec4 , mid0  ) ;
    add3D   ( vec2 , vec3 , mid1  ) ;
    cross3D ( mid0 , mid1 , nv_mid ) ; unify3D ( nv_mid ) ;

    // one more cross3D: mid43 X mid12 -> nh_mid
    add3D   ( vec4 , vec3 , mid0   ) ;
    add3D   ( vec1 , vec2 , mid1   ) ;
    cross3D ( mid0 , mid1 , nh_mid ) ; unify3D ( nh_mid ) ;


    /////////////////////////////////////////////
    //
    // - Tune nv_mid and nh_mid according to "small_circle_param"
    //   If small_circle_param = 0.0, they take the current value
    //   If small_circle_param = 1.0, they will be on the geodesic between nv1-nv2 and nh1-nh2
    //                                i.e., small circle becomes a great circle

    if ( fabs ( small_circle_param ) > 1e-7 )
    {
        //printf("       nv_mid: %f %f %f\n",nv_mid[0],nv_mid[1],nv_mid[2]);
        sc_interp ( nv1 , nv_mid , nv2 , small_circle_param ) ;
        //printf("            -> %f %f %f\n",nv_mid[0],nv_mid[1],nv_mid[2]);

        //printf("       nh_mid: %f %f %f\n",nh_mid[0],nh_mid[1],nh_mid[2]);
        sc_interp ( nh1 , nh_mid , nh2 , small_circle_param ) ;
        //printf("            -> %f %f %f\n",nh_mid[0],nh_mid[1],nh_mid[2]);
    }

    /////////////////////////////////////////////
    // find the normal set along small circle: nv1 -> nv_mid -> nv2
    // -> normal_set_V (vertical set)

    analyzeSC ( nv1    ,   // Input: nv1 -> nv_mid -> nv2
                nv_mid ,
                nv2    ,
                vert_axis   ,   // The five outputs
                vert_hvec   ,
                vert_v1     ,
                vert_v2     ,
              & vert_theta  ) ;


    /////////////////////////////////////////////
    // find the normal set along small circle: nh1 -> nh_mid -> nh2
    // -> normal_set_H (horizontal set)

    analyzeSC ( nh1    ,   // Input: nh1 -> nh_mid -> nh2
                nh_mid ,
                nh2    ,
                hori_axis   ,   // The five outputs
                hori_hvec   ,
                hori_v1     ,
                hori_v2     ,
              & hori_theta  ) ;


}

// findSC_interpolate_normal
//
// find the normal vector of the plane subdividing the quad using Small Circle subdivision method
// it is calculated by ptrV = cos(t) v1 + sin(t) v2 such that 0 <= t <= theta
// then ptrV = ptrV*vlen + hvec
//
// INPUT:
//   v1:        vector in (x,y,z) format, v1 generate in analyzeSC()
//   v2:        vector in (x,y,z) format, v1 generate in analyzeSC()
//   hvec:      vector in (x,y,z) format, hvec generate in analyzeSC()
//   ratio:     ratio to do interpolation between v1 and v2
//   theta:     theta between v1 and v2
//   vlen:      length of v1
//
// OUPUT:
//   ptrV:      the result interpolated vector in (x,y,z) format
void findSC_interpolate_normal(double *ptrV, double ratio, double *hvec, double *v1, double *v2, double theta, double vlen)
{
    double t, sint , cost ;

    t    = ratio * theta ;
    cost = cos ( t ) ;
    sint = sin ( t ) ;

    // Interpolate between v1 and v2 using theta (Get the unit direction)
    ptrV[0] = cost * v1[0] + sint * v2[0] ;
    ptrV[1] = cost * v1[1] + sint * v2[1] ;
    ptrV[2] = cost * v1[2] + sint * v2[2] ;
    unify3D ( ptrV ) ;

    // Add ptrV = ptrV*vlen + hvec
    add_mul_3D ( hvec , vlen , ptrV , ptrV ) ;
    unify3D    ( ptrV ) ;
}


//*************************************************************************************
//
// data querying coding
//
//*************************************************************************************
//given the vector "dir", and the quad with vertices vec1,vec2,vec3,vec4 
//(assume the dir contains in the quad), find the location of the subdivided 
//area where vector "dir" locates, vert_t is the location in the vertical
//partitioning set and hort_t is the location in the horizontal partitioning set
//range of vert_t an hori_t is [0,nsegment]
void indexing_GCSC(double *dir, double *vec1, double *vec2, double *vec3, double *vec4, 
                   float small_circle_param, int new_base_solid_flag,
                   double &vert_t, double &hori_t )
{
    static double nv1[3] , nv2[3] , nh1[3] , nh2[3] ;
    static double vert_axis[3] , vert_hvec[3] , vert_v1[3] , vert_v2[3] , vert_theta; 
    static double hori_axis[3] , hori_hvec[3] , hori_v1[3] , hori_v2[3] , hori_theta; 
    static double temp_vec[3];
    double vert_phi , hori_phi;
    double A , B , C;
    double vert_tmp_t, hori_tmp_t;
    

    unify3D(dir);        

    if(new_base_solid_flag == 1)
    {
          /////////////////////////////////////////////
          // Normals for the four edge planes
          //
          //   vec1 -- vec4
          //    |        |
          //   vec2 -- vec3

          cross3D ( vec1 , vec2 , nv1 ) ; unify3D ( nv1 ) ;
          cross3D ( vec4 , vec3 , nv2 ) ; unify3D ( nv2 ) ;
          cross3D ( vec4 , vec1 , nh1 ) ; unify3D ( nh1 ) ;
          cross3D ( vec3 , vec2 , nh2 ) ; unify3D ( nh2 ) ;


          /////////////////////////////////////////////
          // Find two more normals in between nv1-nv2 and nh1-nh2
          double mid0[3] , mid1[3] , nv_mid[3] , nh_mid[3] ;

          // one more cross3D: mid14 X mid23 -> nv_mid
          add3D   ( vec1 , vec4 , mid0  ) ;
          add3D   ( vec2 , vec3 , mid1  ) ;
          cross3D ( mid0 , mid1 , nv_mid ) ; unify3D ( nv_mid ) ;

          // one more cross3D: mid43 X mid12 -> nh_mid
          add3D   ( vec4 , vec3 , mid0   ) ;
          add3D   ( vec1 , vec2 , mid1   ) ;
          cross3D ( mid0 , mid1 , nh_mid ) ; unify3D ( nh_mid ) ;


          /////////////////////////////////////////////
          // 
          // - Tune nv_mid and nh_mid according to "small_circle_param"
          //   If small_circle_param = 0.0, they take the current value
          //   If small_circle_param = 1.0, they will be on the geodesic between nv1-nv2 and nh1-nh2
          //                                i.e., small circle becomes a great circle
          if ( fabs ( small_circle_param ) > 1e-7 )
          {	
            sc_interp ( nv1 , nv_mid , nv2 , small_circle_param ) ;
            //printf("            -> %f %f %f\n",nv_mid[0],nv_mid[1],nv_mid[2]);
            sc_interp ( nh1 , nh_mid , nh2 , small_circle_param ) ;
            //printf("            -> %f %f %f\n",nh_mid[0],nh_mid[1],nh_mid[2]);
          }


          //==============================================================================
          // Vertical set
          // - The following is to find the hvec, axis, v1, v2, theta
            analyzeSC ( nv1    ,   // Input: nv1 -> nv_mid -> nv2
                        nv_mid ,
                        nv2    ,
                        vert_axis   ,   // The five outputs
                        vert_hvec   ,
                        vert_v1     ,
                        vert_v2     ,
                        & vert_theta  ) ;

            /////////////////////////////////////////////
            // Decompose n1 into hvec + v1
            //           n2 into hvec + v2
            minus3D ( nv1 , vert_hvec , vert_v1 ) ;
            minus3D ( nv2 , vert_hvec , vert_v2 ) ;


          //==============================================================================
          // Horizontal set
          // - The following is to find the hvec, axis, v1, v2, theta
            analyzeSC ( nh1    ,   // Input: nh1 -> nh_mid -> nh2
                        nh_mid ,
                        nh2    ,
                        hori_axis   ,   // The five outputs
                        hori_hvec   ,
                        hori_v1     ,
                        hori_v2     ,
                        & hori_theta  ) ;

            /////////////////////////////////////////////
            // Decompose n1 into hvec + v1
            //           n2 into hvec + v2
            minus3D ( nh1 , hori_hvec , hori_v1 ) ;
            minus3D ( nh2 , hori_hvec , hori_v2 ) ;

    }// if(new_base_solid == 1)

    //==============================================================================
    // Vertical set
    A = dot3D ( dir , vert_v2 ) - ( dot3D ( dir , vert_v1 ) * cos ( vert_theta ) );
    B = dot3D ( dir , vert_v1 ) * sin ( vert_theta );
    C = dot3D ( dir , vert_hvec) * sin ( vert_theta );
    vert_phi = atan2 ( B , A );

    double tmptan;        
    tmptan = atan2(-C , -1 * sqrt( pow(A,2) + (pow(B,2) - pow(C,2)) ) );

    vert_tmp_t = tmptan - vert_phi;

    if(vert_tmp_t < 0)
       vert_tmp_t += 2 * M_PI; 
    if(vert_tmp_t >= 2 * M_PI)
      vert_tmp_t = vert_tmp_t-2*M_PI;

    vert_tmp_t = vert_tmp_t / vert_theta;
    
    vert_t = vert_tmp_t;

    //==============================================================================
    // Horizontal set
    A = dot3D ( dir , hori_v2 ) - ( dot3D ( dir , hori_v1 ) * cos ( hori_theta ) );
    B = dot3D ( dir , hori_v1 ) * sin ( hori_theta );
    C = dot3D ( dir , hori_hvec) * sin ( hori_theta );
    hori_phi = atan2 ( B , A );
 

    tmptan = atan2(-C , -1 * sqrt( pow(A,2) + (pow(B,2) - pow(C,2)) ) );
    hori_tmp_t = tmptan - hori_phi;

    if(hori_tmp_t < 0)
      hori_tmp_t += 2 * M_PI; 
    if(hori_tmp_t >= 2 * M_PI)
      hori_tmp_t = hori_tmp_t-2*M_PI;

    hori_tmp_t = hori_tmp_t / hori_theta;

    hori_t = hori_tmp_t;
}
