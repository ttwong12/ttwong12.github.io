#ifndef _UCM_H
#define _UCM_H

void ucm_pix2ang(long nside, int facenum, double ix, double iy, double *theta, double *phi);

void ucm_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy);

#endif 