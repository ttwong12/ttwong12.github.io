/* rhombic.cpp */
/*
* This program implements the rhombic dodecahedron mapping proposed in 
* our TMM'09 paper.
* To use this code and the results, please cite the following paper:
*
*    Chi-Wing Fu, Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung, 
*    The Rhombic Dodecahedron Map: An Efficient Scheme for Encoding Panoramic
*    Video, IEEE Transactions on Multimedia (TMM), 
*    Vol. 11, No. 4, pp. 634-644, June 2009. 
*
* Copyright (c) 2007-2010, The Chinese University of Hong Kong
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*  * Redistributions of source code must retain the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer.
*  * Redistributions in binary form must reproduce the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer in the documentation and/or other 
*    materials provided with the distribution.
*  * Neither the name of The Chinese University of Hong Kong nor the
*    names of its contributors may be used to endorse or promote products
*    derived from this software without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
* ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
* ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
* POSSIBILITY OF SUCH DAMAGE.
*
*/

#define _USE_MATH_DEFINES
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rhombic.h"
#include "sphPartitioning.h"

float           optimal_small_circle_param_area = 0.20835f;
float           optimal_small_circle_param_discrepancy = 0.121369f; //for nsegment = 128
//float           optimal_small_circle_param_discrepancy = 0.121287f; //for nsegment = 256


//////////////////////////////////////////////////////////////////////////
// rd_pix2ang 
//
// maps the pixel from local coordinates (facenum, ix, iy) in the rhombic 
// dodecahedron map to spherical coordinates (theta, phi). 
// 
// INPUT:
//   nside  : resolution of one RD-map face
//   facenum: the RD-map face where the input pixel locates
//   ix, iy : local coordinates of a given pixel, [0,nside-1]x[0,nside-1]
// 
// OUTPUT:
//   theta : polar angle with a range of [0, pi]
//   phi   : azimuth angle with a range of [0, 2pi]
// 
void rd_pix2ang(long nside, int facenum, double ix, double iy, double *theta, double *phi)
{
	float  small_circle_param = optimal_small_circle_param_discrepancy;		// a magic number from experiment (inside draw_frame() subroutine)

	double * obj_basePt    ;
	int    * obj_baseIndex ;
	int    obj_numPoly   ;
	int    obj_numVertex ;
	int    indx ;
	const double * vec1 , * vec2 , * vec3 , * vec4;
	
	// Get base polygon parameters
	getBasePolygonParam ( & obj_basePt , & obj_baseIndex , & obj_numPoly , & obj_numVertex );
	
	indx = facenum * 4;
	
	vec1 = (const double *)( obj_basePt + 3 * obj_baseIndex[indx  ] );
	vec2 = (const double *)( obj_basePt + 3 * obj_baseIndex[indx+1] );
	vec3 = (const double *)( obj_basePt + 3 * obj_baseIndex[indx+2] );
	vec4 = (const double *)( obj_basePt + 3 * obj_baseIndex[indx+3] );
	
	double ptrH[3], ptrV[3], ptrVertex[3];
	double vlen ;
	double ratio;

	double vert_axis[3], vert_hvec[3], vert_v1[3], vert_v2[3], vert_theta;
	double hori_axis[3], hori_hvec[3], hori_v1[3], hori_v2[3], hori_theta;

	// Prepare normal parameters for a base face
	findSC_calNormalParameter(vert_axis, vert_hvec, vert_v1, vert_v2, vert_theta, 
		hori_axis, hori_hvec, hori_v1, hori_v2, hori_theta,
		vec1, vec2, vec3, vec4, small_circle_param);

	// Interpolate normal of the vertical subdivision plane
	vlen = length3D ( vert_v1 );
	ratio = iy / ( (double) nside );
	findSC_interpolate_normal(ptrV, ratio, vert_hvec, vert_v1, vert_v2, vert_theta, vlen);      
	
	// Interpolate normal of the horizontal subdivision plane
	vlen = length3D ( hori_v1 ) ;
	ratio = ix / ( (double) nside );
	findSC_interpolate_normal(ptrH, ratio, hori_hvec, hori_v1, hori_v2, hori_theta, vlen);
	
	// Find the vertex given the horizontal and vertical subdivision plane's normal
	cross3D ( ptrH , ptrV , ptrVertex ) ;
	unify3D ( ptrVertex ) ;

	*theta = acos(ptrVertex[1]);
	*phi = atan2(ptrVertex[2], ptrVertex[0]);
	*phi = (*phi <= 0) ? *phi + M_PI*2 : *phi;
}


//////////////////////////////////////////////////////////////////////////
// rd_ang2pix
//
// maps one pixel from spherical coordinates to local coordinates of the 
// rhombic dodecahedron map.
//
// Please refer to function rd_pix2ang() for the description of 
// function variables
//
void rd_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy)
{
	float  small_circle_param = optimal_small_circle_param_discrepancy;	
	double * obj_basePt, * greatCircle_set   ;
	int    * obj_baseIndex ;
	int    obj_numPoly   ;
	int    obj_numVertex ;
	int    indx ;
	double * vec1 , * vec2 , * vec3 , * vec4;
	
	double dir[3];
	dir[0] = sin(theta)*cos(phi);
	dir[1] = cos(theta);
	dir[2] = sin(theta)*sin(phi);

	// Get base polygon parameters
	getBasePolygonParam ( & obj_basePt , & obj_baseIndex , & obj_numPoly , & obj_numVertex );
	
	// Step 1: find the base face where the vector locates
	getBaseGreatCircleSet( &greatCircle_set );

	int ind1 = dot3D(dir, greatCircle_set)   >= 0 ? 1 : 0 ;
	int ind2 = dot3D(dir, greatCircle_set+3) >= 0 ? 1 : 0 ;
	int ind3 = dot3D(dir, greatCircle_set+6) >= 0 ? 1 : 0 ;
	int ind4 = dot3D(dir, greatCircle_set+9) >= 0 ? 1 : 0 ;
	int ind5 = dot3D(dir, greatCircle_set+12)>= 0 ? 1 : 0 ;
	int ind6 = dot3D(dir, greatCircle_set+15)>= 0 ? 1 : 0 ;

	*facenum = getFaceIndex(ind1*32+ind2*16+ind3*8+ind4*4+ind5*2+ind6);
	
	indx = (*facenum) * 4;

	vec1 = (double *)( obj_basePt + 3 * obj_baseIndex[indx  ] );
	vec2 = (double *)( obj_basePt + 3 * obj_baseIndex[indx+1] );
	vec3 = (double *)( obj_basePt + 3 * obj_baseIndex[indx+2] );
	vec4 = (double *)( obj_basePt + 3 * obj_baseIndex[indx+3] );

	// Step 2: find the local coordinates of the vector
	indexing_GCSC(dir, vec1, vec2, vec3, vec4, small_circle_param, 1, *iy, *ix );
	*ix = nside - *ix * nside ;
	*iy = nside - *iy * nside ;
}