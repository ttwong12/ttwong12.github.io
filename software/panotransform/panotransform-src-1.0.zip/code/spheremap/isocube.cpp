/* isocube.cpp */
/*
* This program implements the isocube mapping proposed in our TVCG'07 paper.
* To use this code and the results, please cite the following paper:
*
*    Liang Wan, Tien-Tsin Wong, and Chi-Sing Leung, 
*    Isocube: Exploiting the Cubemap Hardware, 
*    IEEE Transactions on Visualization and Computer Graphics (TVCG), 
*    Vol. 13, No. 4, pp. 720-731, 2007.
*
* Copyright (c) 2007-2010, The Chinese University of Hong Kong
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*  * Redistributions of source code must retain the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer.
*  * Redistributions in binary form must reproduce the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer in the documentation and/or other 
*    materials provided with the distribution.
*  * Neither the name of The Chinese University of Hong Kong nor the
*    names of its contributors may be used to endorse or promote products
*    derived from this software without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
* ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
* ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
* POSSIBILITY OF SUCH DAMAGE.
*
*/

#define _USE_MATH_DEFINES
#include <math.h>

#include "isocube.h"


//////////////////////////////////////////////////////////////////////////
// isocube_pix2ang 
//
// maps the pixel from local coordinates (facenum, ix, iy) in the isocube map 
// to spherical coordinates (theta, phi). 
// 
// INPUT:
//   nside  : resolution of one isocube face
//   facenum: the isocube face where the input pixel locates
//   ix, iy : local coordinates of a given pixel, [0,nside-1]x[0,nside-1]
// 
// OUTPUT:
//   theta : polar angle with a range of [0, pi]
//   phi   : azimuth angle with a range of [0, 2pi]
// 
void isocube_pix2ang(long nside, int facenum, double ix, double iy, double *theta, double *phi)
{
	double x = 0.5-ix/nside;
	double y = 0.5-iy/nside;

	if (facenum < 4) // Equatorial region
	{
		*phi = (facenum + x) * M_PI_2;
		*theta = acos(y*4./3.);
	}
	else // ! Polar region
	{
		double ncap = 9 - 2*facenum;
		y = y * ncap;		
		double ring, offset;
		if (x + y >0) 
		{
			if (x >= y) 
			{
				ring = x * 2;
				offset = y;
			}
			else 
			{
				ring = y * 2; 
				offset = 2 * y - x;
			}      
		}
		else 
		{
			if (x < y) 
			{
				ring = - x * 2;
				offset = -4 * x - y;
			}
			else 
			{
				ring = - y * 2;
				offset = x - 6 * y;
			}
		}    
		*phi = M_PI * (ncap<0) + offset / ring * M_PI_2;
		*theta = acos( ncap * (1 - ring*ring/3.) );
	}
	*phi = (*phi < 0) ? *phi + M_PI*2 : *phi;
}

//////////////////////////////////////////////////////////////////////////
// isocube_ang2pix
//
// maps one pixel from spherical coordinates to local coordinates of the 
// isocube map.
//
// Please refer to function isocube_pix2ang() for the description of 
// function variables
//
void isocube_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy)
{
	double t = phi * M_2_PI;  // [0,4]
	t = 3. - t; // [-1,3]
	t = (t<-0.5)?t+4:t;  //[-0.5:3.5]
	int ntt = int( floor(t+0.5) );

	double z = cos(theta)*0.75;
	double za = abs(z)*2;
	
	if (za<=1.0)
	{
		*ix = 0.5+(t-ntt);
		*iy = 0.5-z;
		*facenum = 3-ntt;
	}
	else
	{
		double ring = sqrt(3. - 2.*za);		
		double offset = t*ring;
		double x, y;

		if (ntt==0) 
		{
			x = 0.5;
			y = t;
		}
		if (ntt==1)
		{
			x = 1 - t;
			y = 0.5;
		}
		if (ntt==2)
		{
			x = -0.5;
			y = 2 - t;
		}
		if (ntt==3)
		{
			x = -3 + t;
			y = -0.5;
		}
		y = (z>0) ? -y : y;
		*ix = 0.5 -x * ring;
		*iy = 0.5 -y * ring;	
		*facenum = 4 + (z<0); 
	}
	*ix *= nside;
	*iy *= nside;
	
}