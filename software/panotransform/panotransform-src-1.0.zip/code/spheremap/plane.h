#ifndef _PLANE_H
#define _PLANE_H

void plane_pix2ang(long width, long height, double ix, double iy, double *theta, double *phi);

void plane_ang2pix(long width, long height, double theta, double phi, double *ix, double *iy);

#endif 