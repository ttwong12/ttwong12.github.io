#ifndef _CUBIC_H
#define _CUBIC_H

void cube_pix2ang(long nside, int facenum, double ix, double iy, double *theta, double *phi);

void cube_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy);

#endif 