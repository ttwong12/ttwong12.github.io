#ifndef _RHOMBIC_H_
#define _RHOMBIC_H_

void rd_pix2ang(long nside, int facenum, double ix, double iy, double *theta, double *phi);

void rd_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy);


#endif