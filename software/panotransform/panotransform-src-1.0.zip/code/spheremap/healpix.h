#ifndef _HEALPIX_H
#define _HEALPIX_H

void hp_pix2ang( long nside, int facenum, double ix, double iy, double *theta, double *phi);

void hp_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy);

#endif