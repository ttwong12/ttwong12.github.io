/* plane.cpp */
/*
* This program converts spherical coordinates to/from local coordinates
* of the longitude-latitude map. 
*
* Copyright (c) 2007-2010, The Chinese University of Hong Kong
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*  * Redistributions of source code must retain the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer.
*  * Redistributions in binary form must reproduce the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer in the documentation and/or other 
*    materials provided with the distribution.
*  * Neither the name of The Chinese University of Hong Kong nor the
*    names of its contributors may be used to endorse or promote products
*    derived from this software without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
* ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
* ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
* POSSIBILITY OF SUCH DAMAGE.
*
*/

#define _USE_MATH_DEFINES
#include <math.h>

#include "plane.h"

//////////////////////////////////////////////////////////////////////////
// plane_pix2ang 
//
// maps the pixel from local coordinates (ix, iy) in the longitude-latitude
// map to spherical coordinates (theta, phi). 
// 
// INPUT:
//   width : width of the longitude-latitude map
//   height: height of the longitude-latitude map
//   ix, iy: local coordinates of a given pixel
// 
// OUTPUT:
//   theta : polar angle with a range of [0, pi]
//   phi   : azimuth angle with a range of [0, 2pi]
// 
void plane_pix2ang(long width, long height, double ix, double iy, double *theta, double *phi)
{
	*phi = ( ix/width ) * M_PI * 2;
	*theta = ( iy/height ) * M_PI;	
}

//////////////////////////////////////////////////////////////////////////
// plane_ang2pix
//
// maps one pixel from spherical coordinates to local coordinates of the 
// longitude-latitude spherical map.
//
// Please refer to function plane_pix2ang() for the description of 
// function variables
//
void plane_ang2pix(long width, long height, double theta, double phi, double *ix, double *iy)
{
	*ix = ( phi/M_PI/2 ) * width;
	*iy = ( theta/M_PI ) * height;
}