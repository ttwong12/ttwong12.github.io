#ifndef _SPHPARTITIONING_H_
#define _SPHPARTITIONING_H_


//-----------------------------------------------------------------------------------------------
// Basic Vector Operations
double length3D (const double *pt1);

void   add3D (const double *vect1, const double *vect2, double *vect3);
void   minus3D (const double *vect1, const double *vect2, double *vect3);
void   add_mul_3D (const double *vect1, const double t, const double *vect2, double *v1_add_t_mul_v2);

double dot3D (const double *vect1, const double *vect2);
void   cross3D (const double *v, const double *w, double *r);
void   copy3D (double *vect1, const double *vect2);
void   mult3D (double *vect, const double scale);

int    unify3D (double *vect);

//-----------------------------------------------------------------------------------------------
// Basic Functions
int  getBasePolygonParam( double ** obj_basePt , int ** obj_baseIndex , int * obj_numPoly , int * obj_numVertices );

void getBaseGreatCircleSet (double ** greatCircle_set);

int  getFaceIndex(int code);

//-----------------------------------------------------------------------------------------------
//small circle subdivision related functions

void sc_interp (const double n1[3] , double nv_mid[3] , const double n2[3] , const double t);

void analyzeSC (const double *n1, const double *nmid, const double *n2, double axis[3], 
                double hvec[3], double v1[3], double v2[3], double *theta);

void findSC_calNormalParameter(double * vert_axis, double *vert_hvec, double *vert_v1, double *vert_v2, double &vert_theta, 
                               double * hori_axis, double *hori_hvec, double *hori_v1, double *hori_v2, double &hori_theta,
                               const double *vec1, const double *vec2, const double *vec3, const double *vec4, 
                               float small_circle_param);

void findSC_interpolate_normal(double *ptrV, double ratio, double *hvec, double *v1, double *v2, double theta, double vlen);

void indexing_GCSC(double *dir, double *vec1, double *vec2, double *vec3, double *vec4, 
				   float small_circle_param, int new_base_solid_flag, double &vert_t, double &hori_t );
//-----------------------------------------------------------------------------------------------
#endif