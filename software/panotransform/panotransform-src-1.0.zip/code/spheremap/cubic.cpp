/* cubic.cpp */
/*
*
* This program converts spherical coordinates to/from local coordinates
* of the cubemap. 
*
* Copyright (c) 2007-2010, The Chinese University of Hong Kong
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*  * Redistributions of source code must retain the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer.
*  * Redistributions in binary form must reproduce the above copyright
*    notice and publication information, this list of conditions and 
*    the following disclaimer in the documentation and/or other 
*    materials provided with the distribution.
*  * Neither the name of The Chinese University of Hong Kong nor the
*    names of its contributors may be used to endorse or promote products
*    derived from this software without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE CHINESE UNIVERSITY OF HONG KONG
* ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* CHINESE UNIVERSITY OF HONG KONG BE LIABLE FOR ANY DIRECT, INDIRECT, 
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
* ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
* POSSIBILITY OF SUCH DAMAGE.
*
*/

#define _USE_MATH_DEFINES
#include <math.h>

#include "cubic.h"
#include "stdio.h"

//////////////////////////////////////////////////////////////////////////
// cube_pix2ang 
//
// maps the pixel from local coordinates (facenum, ix, iy) in the cubemap 
// to spherical coordinates (theta, phi). 
// 
// INPUT:
//   nside  : resolution of one cubemap face
//   facenum: the cubemap face where the input pixel locates
//   ix, iy : local coordinates of a given pixel, [0,nside-1]x[0,nside-1]
// 
// OUTPUT:
//   theta : polar angle with a range of [0, pi]
//   phi   : azimuth angle with a range of [0, 2pi]
// 

void cube_pix2ang(long nside, int facenum, double ix, double iy, double *theta, double *phi)
{
  double radius = nside/2.0;
  double x, y, z, len;
   
  switch ( facenum ) {
    case 0: // face xp
      x = radius;
      y = radius - iy;
      z = radius - ix;
      break;
    case 1: // face zn
      x = ix - radius;
      y = radius - iy;
      z = radius; 
      break;
    case 2: // face xn
      x = -radius;
      y = radius - iy;
      z = ix - radius;      
      break;
    case 3: // face zp
      x = radius - ix;
      y = radius - iy;
      z = -radius;
      break; 
    case 4: // face yp
      x = radius - ix;
      y = radius;
      z = radius - iy;
      break;
    case 5: // face yn
      x = ix - radius;
      y = -radius;
      z = radius - iy;
      break;
  }
  
  len = sqrt(x*x + y*y + z*z);  
  y /= len;
  *phi = atan2(z, x);
  *phi = (*phi <= 0) ? *phi + M_PI*2 : *phi;
  *theta = acos( y );  
}

//////////////////////////////////////////////////////////////////////////
// cube_ang2pix
//
// maps one pixel from spherical coordinates to local coordinates of the 
// cubemap.
//
// Please refer to function cube_pix2ang() for the description of 
// function variables
//
void cube_ang2pix(long nside, double theta, double phi, int *facenum, double *ix, double *iy)
{
	double radius = nside/2.0;
	double x, y, z;	
	x = sin(theta) * cos(phi);
	y = cos(theta);
	z = sin(theta) * sin(phi);

	double vmax= (abs(x)>abs(y))?abs(x):abs(y);
	vmax = (vmax>abs(z))?vmax:abs(z);	
    int axis=0;
	axis = (abs(x)>abs(y))?0:1;
	axis = (vmax>abs(z))?axis:2;
	x /= vmax; 	
	y /= vmax;	
	z /= vmax;
	
	if (x>0 && axis==0)
	{
		// face xp
		*facenum = 0;
		*iy = 1.0 - y;
		*ix = 1.0 - z;
	}
	if (x<0 && axis==0)
	{
		// face xn
		*facenum = 2;
		*iy = 1.0 - y;
		*ix = z + 1.0;  
	}
	if (z>0 && axis==2)
	{
		// face zn
		*facenum = 1;
		*ix = x + 1.0;
		*iy = 1.0 - y;
	}
	if (z<0 && axis==2)
	{
		// face zp
		*facenum = 3;
		*ix = 1.0 - x;
		*iy = 1.0 - y;
	}
	if (y>0 && axis==1)
	{
		// face yp
		*facenum = 4;
		*ix = 1.0 + z;
		*iy = 1.0 - x;
	}
	if (y<0 && axis==1)
	{
		// face yn
		*facenum = 5;
		*ix = 1.0 + z;
		*iy = 1.0 + x;
	}

	*ix *= radius;
	*iy *= radius;
}