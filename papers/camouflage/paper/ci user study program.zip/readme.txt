Description:
This is standalone version of user study program.
It is for demonstration purpose only.

Installation:
Double click "CIUserStudy_setup.exe" to install two user study programs.

Note:
Only support windows OS

Thanks