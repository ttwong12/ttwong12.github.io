usage:

 BVCP.exe sample1.bmp sample2.bmp [-s Sampe_rate] [-l Highest_Lum] [-d Display_Resolution] [-r Ratio]


Optional parameters:

Sampe_rate:default is 2, will be automatically rounded to window size if input is very large
Highest_Lum:default is 160(cd/m^2), should be highest luminance of current display setting
Display_Resolution:default is 1280
Ratio:default is 1.0, should be viewing distance divided by display width


Environment:
Software: NVIDIA CUDA 2.3 or later
Hardware: GPU supported by CUDA